const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const WORKER_UID = "worker_raju_123";
const EMPLOYER_UID = "employer_sai_456";
const OTHER_UID = "other_user_789";
const ADMIN_UID = "admin_root_001";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function ts(context) {
  return context.firestore().FieldValue ? undefined : new Date();
}

function makeUserPayload(uid, role = "WORKER") {
  return {
    uid,
    name: role === "WORKER" ? "Raju Naidu" : "Sri Sai Builders",
    phone: "9848011111",
    role,
    city: "Warangal",
    area: "Chowrasta",
    latitude: 17.9689,
    longitude: 79.5941,
    primarySkill: "MASON",
    experienceYears: 5,
    expectedDailyWage: 900,
    isAvailable: true,
    isVerified: false,
    isSuspended: false,
    rating: 4.8,
    completedJobs: 0,
    createdAt: new Date(Date.now() - 5000),
  };
}

function makeJobPayload(employerId) {
  return {
    employerId,
    employerName: "Sri Sai Builders",
    employerPhone: "9848022222",
    title: "Brick Wall Plastering",
    category: "MASON",
    description: "Need experienced mason",
    city: "Warangal",
    area: "Chowrasta",
    latitude: 17.9689,
    longitude: 79.5941,
    dailyWage: 950,
    workersNeeded: 2,
    workDurationDays: 3,
    shiftTiming: "8:30 AM - 5:30 PM",
    includesMeals: true,
    status: "OPEN",
    createdAt: new Date(Date.now() - 5000),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("jobs").where("status", "==", "OPEN").get());
  await assertFails(unauthDb.collection("users").doc(WORKER_UID).get());
  await assertFails(unauthDb.collection("applications").where("workerId", "==", WORKER_UID).get());
  await assertFails(unauthDb.collection("notifications").where("userId", "==", WORKER_UID).get());
  await assertFails(unauthDb.collection("app_config").doc("service_areas").get());
});

test("User registration prevents self-assigning ADMIN or isVerified", async () => {
  const workerDb = testEnv.authenticatedContext(WORKER_UID).firestore();
  const validPayload = makeUserPayload(WORKER_UID, "WORKER");
  await assertSucceeds(workerDb.collection("users").doc(WORKER_UID).set(validPayload));

  // Self-escalation attempts must fail
  await assertFails(
    workerDb.collection("users").doc(OTHER_UID).set({
      ...makeUserPayload(OTHER_UID, "WORKER"),
      isVerified: true,
    })
  );
  await assertFails(
    workerDb.collection("users").doc(OTHER_UID).set({
      ...makeUserPayload(OTHER_UID, "ADMIN"),
    })
  );
});

test("Cross-user PII isolation on /users/{userId}", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(WORKER_UID).set(makeUserPayload(WORKER_UID, "WORKER"));
  });

  const otherDb = testEnv.authenticatedContext(OTHER_UID).firestore();
  await assertFails(otherDb.collection("users").doc(WORKER_UID).get());
  await assertFails(otherDb.collection("users").get());
});

test("Only EMPLOYER can create jobs; WORKER cannot create jobs", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(WORKER_UID).set(makeUserPayload(WORKER_UID, "WORKER"));
    await db.collection("users").doc(EMPLOYER_UID).set(makeUserPayload(EMPLOYER_UID, "EMPLOYER"));
  });

  const workerDb = testEnv.authenticatedContext(WORKER_UID).firestore();
  await assertFails(workerDb.collection("jobs").doc("job_1").set(makeJobPayload(WORKER_UID)));

  const employerDb = testEnv.authenticatedContext(EMPLOYER_UID).firestore();
  await assertSucceeds(employerDb.collection("jobs").doc("job_1").set(makeJobPayload(EMPLOYER_UID)));
  // Cannot spoof another employerId
  await assertFails(employerDb.collection("jobs").doc("job_2").set(makeJobPayload(OTHER_UID)));
});

test("Worker can query OPEN jobs and apply; Employer can accept and complete", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("users").doc(WORKER_UID).set(makeUserPayload(WORKER_UID, "WORKER"));
    await db.collection("users").doc(EMPLOYER_UID).set(makeUserPayload(EMPLOYER_UID, "EMPLOYER"));
    await db.collection("jobs").doc("job_1").set(makeJobPayload(EMPLOYER_UID));
  });

  const workerDb = testEnv.authenticatedContext(WORKER_UID).firestore();
  await assertSucceeds(workerDb.collection("jobs").where("status", "==", "OPEN").get());
  // Unfiltered jobs list without status/employerId filter must fail
  await assertFails(workerDb.collection("jobs").get());

  const appDoc = {
    jobId: "job_1",
    jobTitle: "Brick Wall Plastering",
    dailyWage: 950,
    employerId: EMPLOYER_UID,
    employerName: "Sri Sai Builders",
    employerPhone: "9848022222",
    jobCity: "Warangal",
    jobArea: "Chowrasta",
    workerId: WORKER_UID,
    workerName: "Raju Naidu",
    workerPhone: "9848011111",
    workerSkill: "MASON",
    workerArea: "Chowrasta, Warangal",
    status: "PENDING",
    note: "Ready tomorrow",
    appliedAt: new Date(Date.now() - 5000),
  };
  await assertSucceeds(workerDb.collection("applications").doc("job_1_worker").set(appDoc));

  // Worker cannot self-accept their own application
  await assertFails(
    workerDb.collection("applications").doc("job_1_worker").update({ status: "ACCEPTED" })
  );

  // Employer can accept then complete
  const employerDb = testEnv.authenticatedContext(EMPLOYER_UID).firestore();
  await assertSucceeds(
    employerDb.collection("applications").doc("job_1_worker").update({
      status: "ACCEPTED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(
    employerDb.collection("applications").doc("job_1_worker").update({
      status: "COMPLETED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  // Terminal state lock: cannot modify COMPLETED without admin
  await assertFails(
    employerDb.collection("applications").doc("job_1_worker").update({ status: "REJECTED" })
  );
});

test("Admin can verify users, list all users, and send broadcasts", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("admins").doc(ADMIN_UID).set({ uid: ADMIN_UID, createdAt: new Date(Date.now() - 5000) });
    await db.collection("users").doc(WORKER_UID).set(makeUserPayload(WORKER_UID, "WORKER"));
  });

  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
  await assertSucceeds(adminDb.collection("users").get());
  await assertSucceeds(adminDb.collection("users").doc(WORKER_UID).update({ isVerified: true }));
  await assertSucceeds(
    adminDb.collection("notifications").doc("notif_1").set({
      userId: "BROADCAST",
      senderId: ADMIN_UID,
      targetRole: "ALL",
      title: "Safety Advisory",
      message: "Confirm daily wages before starting.",
      type: "ADMIN_ALERT",
      isRead: false,
      createdAt: new Date(Date.now() - 2000),
    })
  );

  // Worker cannot send global ADMIN_ALERT broadcast
  const workerDb = testEnv.authenticatedContext(WORKER_UID).firestore();
  await assertFails(
    workerDb.collection("notifications").doc("notif_spam").set({
      userId: "BROADCAST",
      senderId: WORKER_UID,
      targetRole: "ALL",
      title: "Spam",
      message: "Spam",
      type: "ADMIN_ALERT",
      isRead: false,
      createdAt: new Date(Date.now() - 2000),
    })
  );
});

test("Worker registration supports Kazipet, multi-skills, spoken languages, gender, availability and photo", async () => {
  const workerDb = testEnv.authenticatedContext(WORKER_UID).firestore();
  const richWorker = {
    ...makeUserPayload(WORKER_UID, "WORKER"),
    city: "Kazipet",
    area: "Kazipet Junction",
    latitude: 17.9736,
    longitude: 79.5061,
    primarySkill: "MASON",
    skills: ["MASON", "PAINTER", "HELPER"],
    spokenLanguages: ["Telugu", "Hindi"],
    gender: "MALE",
    availabilityStatus: "AVAILABLE_THIS_WEEK",
    profilePhotoBase64: "dGVzdF9waG90bw==",
  };
  await assertSucceeds(workerDb.collection("users").doc(WORKER_UID).set(richWorker));

  const dirPayload = { ...richWorker };
  delete dirPayload.role;
  await assertSucceeds(workerDb.collection("worker_directory").doc(WORKER_UID).set(dirPayload));

  // Reject invalid gender, oversized photo, or empty skills list
  await assertFails(
    workerDb.collection("users").doc(WORKER_UID).update({ gender: "INVALID_GENDER" })
  );
  await assertFails(
    workerDb.collection("users").doc(WORKER_UID).update({ availabilityStatus: "UNKNOWN_STATUS" })
  );
  await assertFails(
    workerDb.collection("users").doc(WORKER_UID).update({ skills: [] })
  );
  await assertFails(
    workerDb.collection("users").doc(WORKER_UID).update({ profilePhotoBase64: "a".repeat(120001) })
  );
});

test("First launch restricts registration and jobs to Hyderabad, Warangal, Hanamkonda, Kazipet until Admin expands config", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("admins").doc(ADMIN_UID).set({ uid: ADMIN_UID, createdAt: new Date(Date.now() - 5000) });
  });

  const workerDb = testEnv.authenticatedContext(WORKER_UID).firestore();
  const employerDb = testEnv.authenticatedContext(EMPLOYER_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  // Outside cities (Karimnagar, Nizamabad) are blocked on first launch
  await assertFails(
    workerDb.collection("users").doc(WORKER_UID).set({
      ...makeUserPayload(WORKER_UID, "WORKER"),
      city: "Nizamabad",
      area: "Clock Tower",
      latitude: 18.6725,
      longitude: 78.0941,
    })
  );
  await assertFails(
    employerDb.collection("users").doc(EMPLOYER_UID).set({
      ...makeUserPayload(EMPLOYER_UID, "EMPLOYER"),
      city: "Karimnagar",
      area: "Tower Circle",
      latitude: 18.4386,
      longitude: 79.1288,
    })
  );

  // Active 4 launch cities (Hyderabad, Hanamkonda & Warangal) succeed
  await assertSucceeds(
    workerDb.collection("users").doc(WORKER_UID).set({
      ...makeUserPayload(WORKER_UID, "WORKER"),
      city: "Hyderabad",
      area: "Film Nagar",
      latitude: 17.4167,
      longitude: 78.4094,
    })
  );
  await assertSucceeds(
    employerDb.collection("users").doc(EMPLOYER_UID).set({
      ...makeUserPayload(EMPLOYER_UID, "EMPLOYER"),
      city: "Warangal",
      area: "Chowrasta",
    })
  );

  // Employer can post job in Hyderabad on first launch, but cannot post in Karimnagar yet
  await assertSucceeds(
    employerDb.collection("jobs").doc("job_hyd_launch").set({
      ...makeJobPayload(EMPLOYER_UID),
      city: "Hyderabad",
      area: "Madhapur",
      latitude: 17.4483,
      longitude: 78.3915,
    })
  );
  await assertFails(
    employerDb.collection("jobs").doc("job_karimnagar_blocked").set({
      ...makeJobPayload(EMPLOYER_UID),
      city: "Karimnagar",
      area: "Tower Circle",
    })
  );

  // Non-admin cannot modify /app_config/service_areas
  await assertFails(
    workerDb.collection("app_config").doc("service_areas").set({
      enabledCities: ["Hyderabad", "Warangal", "Hanamkonda", "Kazipet", "Karimnagar"],
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Admin expands service areas centrally to include Karimnagar
  await assertSucceeds(
    adminDb.collection("app_config").doc("service_areas").set({
      enabledCities: ["Hyderabad", "Warangal", "Hanamkonda", "Kazipet", "Karimnagar"],
      updatedBy: ADMIN_UID,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Now Karimnagar job posting & registration succeed, while unenabled Nizamabad still fails
  await assertSucceeds(
    employerDb.collection("jobs").doc("job_karimnagar_enabled").set({
      ...makeJobPayload(EMPLOYER_UID),
      city: "Karimnagar",
      area: "Tower Circle",
      latitude: 18.4386,
      longitude: 79.1288,
    })
  );
  await assertSucceeds(
    workerDb.collection("users").doc(WORKER_UID).update({
      city: "Karimnagar",
      area: "Tower Circle",
      latitude: 18.4386,
      longitude: 79.1288,
    })
  );
  await assertFails(
    employerDb.collection("jobs").doc("job_nizamabad_still_blocked").set({
      ...makeJobPayload(EMPLOYER_UID),
      city: "Nizamabad",
      area: "Clock Tower",
    })
  );
});

// --- MODULE 2: FILM DIRECT CONNECT SECURITY RULES TESTS ---

function makeArtistPayload(uid) {
  return {
    uid,
    name: "Ananya Reddy",
    age: 23,
    gender: "FEMALE",
    city: "Hyderabad",
    area: "Film Nagar",
    phone: "9848099111",
    languages: ["Telugu", "Hindi"],
    experienceYears: 2,
    skills: ["JUNIOR_ARTIST", "DANCER"],
    bio: "Short films and background roles.",
    photosBase64: ["cGhvdG9fMQ==", "cGhvdG9fMg=="],
    noBrokerConfirmed: true,
    zeroFeeAcknowledged: true,
    isAvailable: true,
    isSuspended: false,
    createdAt: new Date(Date.now() - 5000),
  };
}

function makeCastingProfilePayload(uid, accountType = "FILM_DIRECTOR") {
  return {
    uid,
    accountType,
    organizationName: "Deccan Frames Studio",
    contactName: "Vikramaditya Rao",
    phone: "9848099222",
    city: "Hyderabad",
    area: "Jubilee Hills",
    projectCredits: "Feature film & ad shoots in Telugu",
    idProofType: "TFPC Member Card",
    idReferenceMasked: "TFPC-XXXX-4421",
    verificationNotes: "Shooting schedule starts Nov",
    noBrokerConfirmed: true,
    zeroFeeConfirmed: true,
    verificationStatus: "PENDING",
    verifiedBy: "",
    rejectionReason: "",
    isSuspended: false,
    createdAt: new Date(Date.now() - 5000),
  };
}

function makeCastingPostPayload(posterId, accountType = "FILM_DIRECTOR") {
  return {
    posterId,
    posterName: "Vikramaditya Rao",
    organizationName: "Deccan Frames Studio",
    posterAccountType: accountType,
    posterVerified: true,
    projectName: "Godavari Echoes",
    roleTitle: "College Crowd & Supporting Friends",
    artistsNeeded: 8,
    minAge: 18,
    maxAge: 28,
    genderPreference: "ANY",
    languages: ["Telugu", "Hindi"],
    shootingDate: "2026-11-30",
    reportingTime: "6:30 AM",
    city: "Hyderabad",
    area: "Film Nagar",
    latitude: 17.4167,
    longitude: 78.4094,
    paymentAmount: 1800,
    paymentUnit: "PER_DAY",
    description: "Meals included on set. Zero fees, direct booking.",
    noBrokerConfirmed: true,
    zeroFeeConfirmed: true,
    status: "OPEN",
    createdAt: new Date(Date.now() - 3000),
  };
}

test("Film Connect rejects broker roles, fee charges, and unverified casting posts; allows post after Admin verify", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("admins").doc(ADMIN_UID).set({ uid: ADMIN_UID, createdAt: new Date(Date.now() - 5000) });
  });

  const castingDb = testEnv.authenticatedContext(EMPLOYER_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  // Reject broker accountType or disabled noBroker/zeroFee attestations
  await assertFails(
    castingDb.collection("casting_profiles").doc(EMPLOYER_UID).set(makeCastingProfilePayload(EMPLOYER_UID, "TALENT_BROKER"))
  );
  await assertFails(
    castingDb.collection("casting_profiles").doc(EMPLOYER_UID).set({
      ...makeCastingProfilePayload(EMPLOYER_UID, "CASTING_DIRECTOR"),
      noBrokerConfirmed: false,
    })
  );
  await assertFails(
    castingDb.collection("casting_profiles").doc(EMPLOYER_UID).set({
      ...makeCastingProfilePayload(EMPLOYER_UID, "CASTING_DIRECTOR"),
      zeroFeeConfirmed: false,
    })
  );
  // Reject outside city Karimnagar on launch
  await assertFails(
    castingDb.collection("casting_profiles").doc(EMPLOYER_UID).set({
      ...makeCastingProfilePayload(EMPLOYER_UID, "FILM_PRODUCER"),
      city: "Karimnagar",
      area: "Tower Circle",
    })
  );

  // Valid PENDING casting verification submission succeeds for allowed account types
  await assertSucceeds(
    castingDb.collection("casting_profiles").doc(EMPLOYER_UID).set(makeCastingProfilePayload(EMPLOYER_UID, "FILM_DIRECTOR"))
  );

  // Unverified casting account CANNOT publish a casting post or self-verify
  await assertFails(
    castingDb.collection("casting_posts").doc("cast_unverified").set(makeCastingPostPayload(EMPLOYER_UID))
  );
  await assertFails(
    castingDb.collection("casting_profiles").doc(EMPLOYER_UID).update({ verificationStatus: "VERIFIED" })
  );

  // Admin verifies casting profile
  await assertSucceeds(
    adminDb.collection("casting_profiles").doc(EMPLOYER_UID).update({
      verificationStatus: "VERIFIED",
      verifiedBy: ADMIN_UID,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Now verified casting account can publish casting post in Hyderabad & Warangal
  await assertSucceeds(
    castingDb.collection("casting_posts").doc("cast_1").set(makeCastingPostPayload(EMPLOYER_UID, "FILM_DIRECTOR"))
  );
  // Cannot spoof mismatched posterAccountType or spoof another posterId
  await assertFails(
    castingDb.collection("casting_posts").doc("cast_spoof_type").set(makeCastingPostPayload(EMPLOYER_UID, "WEB_SERIES_PRODUCER"))
  );
  await assertFails(
    castingDb.collection("casting_posts").doc("cast_spoof_id").set(makeCastingPostPayload(OTHER_UID, "FILM_DIRECTOR"))
  );
});

test("Film Connect Junior Artist privacy, casting application workflow, reporting, and blocking rules", async () => {
  const ARTIST_UID = WORKER_UID;
  const CASTING_UID = EMPLOYER_UID;

  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    await db.collection("admins").doc(ADMIN_UID).set({ uid: ADMIN_UID, createdAt: new Date(Date.now() - 5000) });
    await db.collection("casting_profiles").doc(CASTING_UID).set({
      ...makeCastingProfilePayload(CASTING_UID, "PRODUCTION_HOUSE"),
      verificationStatus: "VERIFIED",
      verifiedBy: ADMIN_UID,
    });
    await db.collection("casting_posts").doc("cast_open_1").set(makeCastingPostPayload(CASTING_UID, "PRODUCTION_HOUSE"));
  });

  const artistDb = testEnv.authenticatedContext(ARTIST_UID).firestore();
  const castingDb = testEnv.authenticatedContext(CASTING_UID).firestore();
  const otherDb = testEnv.authenticatedContext(OTHER_UID).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();

  // Artist registers with photos in Hyderabad
  await assertSucceeds(
    artistDb.collection("artist_profiles").doc(ARTIST_UID).set(makeArtistPayload(ARTIST_UID))
  );
  // Reject >3 photos or unconfirmed zeroFee
  await assertFails(
    artistDb.collection("artist_profiles").doc(ARTIST_UID).update({
      photosBase64: ["a", "b", "c", "d"],
    })
  );

  // Random user CANNOT list or read another artist's PII/photos; verified casting CAN read artist doc
  await assertFails(otherDb.collection("artist_profiles").get());
  await assertFails(otherDb.collection("artist_profiles").doc(ARTIST_UID).get());
  await assertSucceeds(castingDb.collection("artist_profiles").doc(ARTIST_UID).get());

  // Artist applies directly to verified casting call
  const castApp = {
    postId: "cast_open_1",
    projectName: "Godavari Echoes",
    roleTitle: "College Crowd & Supporting Friends",
    castingOwnerId: CASTING_UID,
    organizationName: "Deccan Frames Studio",
    posterAccountType: "PRODUCTION_HOUSE",
    shootingDate: "2026-11-30",
    reportingTime: "6:30 AM",
    shootingCity: "Hyderabad",
    shootingArea: "Film Nagar",
    paymentAmount: 1800,
    paymentUnit: "PER_DAY",
    artistId: ARTIST_UID,
    artistName: "Ananya Reddy",
    artistAge: 23,
    artistCity: "Hyderabad",
    artistArea: "Film Nagar",
    artistPhone: "9848099111",
    artistLanguages: ["Telugu", "Hindi"],
    artistExperienceYears: 2,
    artistSkills: ["JUNIOR_ARTIST", "DANCER"],
    artistBio: "Short films and background roles.",
    artistPhotosBase64: ["cGhvdG9fMQ=="],
    note: "Available 6 AM",
    noFeeAcknowledged: true,
    status: "PENDING",
    appliedAt: new Date(Date.now() - 2000),
  };
  await assertSucceeds(artistDb.collection("casting_applications").doc("cast_open_1_artist").set(castApp));

  // Third-party privacy isolation on casting_applications
  await assertFails(otherDb.collection("casting_applications").doc("cast_open_1_artist").get());
  await assertFails(otherDb.collection("casting_applications").get());

  // Artist cannot self-select
  await assertFails(
    artistDb.collection("casting_applications").doc("cast_open_1_artist").update({ status: "SELECTED" })
  );

  // Casting owner shortlists then selects artist; cannot reset SELECTED -> PENDING
  await assertSucceeds(
    castingDb.collection("casting_applications").doc("cast_open_1_artist").update({
      status: "SHORTLISTED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(
    castingDb.collection("casting_applications").doc("cast_open_1_artist").update({
      status: "SELECTED",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(
    castingDb.collection("casting_applications").doc("cast_open_1_artist").update({ status: "PENDING" })
  );

  // Verified casting owner can send NEW_CASTING broadcast and CASTING_SELECTED direct alert
  await assertSucceeds(
    castingDb.collection("notifications").doc("notif_cast_alert").set({
      userId: ARTIST_UID,
      senderId: CASTING_UID,
      targetRole: "ARTIST",
      title: "Selected for Shoot!",
      message: "Report at 6:30 AM Film Nagar",
      type: "CASTING_SELECTED",
      isRead: false,
      createdAt: new Date(Date.now() - 500),
    })
  );

  // Artist can submit a safety report & block an account, isolated from others
  await assertSucceeds(
    artistDb.collection("content_reports").doc("rep_1").set({
      reporterId: ARTIST_UID,
      reporterName: "Ananya Reddy",
      targetId: "cast_open_1",
      targetType: "CASTING_POST",
      targetOwnerId: CASTING_UID,
      targetLabel: "College Crowd",
      reason: "BROKER_OR_AGENT",
      details: "Suspected broker middleman",
      status: "OPEN",
      adminActionNote: "",
      createdAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(otherDb.collection("content_reports").doc("rep_1").get());
  await assertSucceeds(
    adminDb.collection("content_reports").doc("rep_1").update({
      status: "RESOLVED",
      adminActionNote: "Closed post",
      updatedAt: new Date(Date.now() - 100),
    })
  );

  await assertSucceeds(
    artistDb.collection("users").doc(ARTIST_UID).collection("blocked_entities").doc(CASTING_UID).set({
      targetId: CASTING_UID,
      targetType: "CASTING_PROFILE",
      targetLabel: "Deccan Frames Studio",
      createdAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(
    otherDb.collection("users").doc(ARTIST_UID).collection("blocked_entities").doc(CASTING_UID).get()
  );
});



