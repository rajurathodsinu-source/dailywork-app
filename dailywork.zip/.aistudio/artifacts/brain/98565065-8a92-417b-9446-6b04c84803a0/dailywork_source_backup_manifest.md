# DailyWork Android App — Verified Source-Code Backup & Export Guide

## Backup Status
- **Application Name:** DailyWork (`com.aistudio.dailywork.vkpqrx`)
- **Codebase Modification Status:** **Unmodified** — all existing Module 1 (Daily Labour Jobs), Module 2 (Film Direct Connect), Admin Moderation & Service Areas, EN/TE/HI localization, and Firebase configurations are preserved intact.
- **Compilation Check (`compile_applet`):** Passed
- **Firestore Security Rules (`deploy_firebase`):** Deployed (`firestore.rules` + `firebase.json` + `firebase-blueprint.json`)
- **Automated Test Suites Verified:**
  - `firestore.test.js`: 10 / 10 passed
  - `DailyWorkRepositoryRuleTest`: 6 / 6 passed
  - `ButtonInteractionsRobolectricTest`: 20 / 20 passed
  - `ExampleRobolectricTest`: 3 / 3 passed
  - `ExampleUnitTest`: 1 / 1 passed

---

## How to Export and Download the Entire Project as a ZIP File

1. **Open the AI Studio Settings / Project Actions Menu:**
   - Look at the top-right toolbar of the Google AI Studio Build interface (above the code editor / preview panel) and open the **Settings / Download / Share menu** (gear or export icon).
2. **Download / Export as ZIP:**
   - Select **Export as ZIP** (or **Download Project**) from the menu.
   - AI Studio packages the complete Android project directory—including Gradle build files, `app/src/`, resources, assets, `google-services.json`, `firebase_applet_config.xml`, and `firestore.rules`—into a single `.zip` archive directly to your computer.
3. **Optional Additional Backups from the Same Menu:**
   - **Push to GitHub:** Connect a GitHub repository from the menu to keep versioned commits and remote source-code backups.
   - **Generate APK / AAB:** Use the **Build / Generate APK or AAB** option in the settings menu to save an installable Android package or Google Play bundle alongside your source backup.

> **Security Tip:** Keep your exported ZIP private because it includes your Firebase configuration (`app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml`). Store any future third-party secrets in the **Secrets panel** in AI Studio rather than hardcoding them in source files.

---

## Complete Project Inventory Included in the Export

### 1. Root & Build Configuration
- `build.gradle.kts` — Top-level Gradle configuration
- `settings.gradle.kts` — Project modules and repository settings
- `gradle.properties` — Gradle JVM & AndroidX flags
- `gradle/libs.versions.toml` & `gradle/wrapper/gradle-wrapper.properties` — Version catalog & Gradle wrapper
- `.gitignore` & `app/.gitignore` — Git ignore rules
- `.env.example` — Environment template placeholder
- `metadata.json` — AI Studio platform metadata
- `debug.keystore.base64` — Signing keystore configuration

### 2. Firebase Configuration & Security Rules
- `firebase.json` — Named Firestore database configuration & emulator settings
- `firebase-blueprint.json` — Data model & schema blueprint
- `firestore.rules` — Verified & deployed zero-trust Firestore rules for Module 1 & Module 2
- `firestore.test.js` — Node security rules test suite
- `app/google-services.json` — Firebase Android app config
- `app/src/main/res/values/firebase_applet_config.xml` — Named Firestore database resource config

### 3. Android App Source (`app/src/main/java/com/example/`)
- `MainActivity.kt` — App entry point, edge-to-edge setup, Credential Manager Google Sign-In, dual-module navigation
- **Data Layer (`data/`):**
  - `Models.kt`, `FirestoreModels.kt`
  - `FirestoreRepository.kt`, `FirestoreErrorHandler.kt`
  - `DailyWorkDatabase.kt`, `DailyWorkRepository.kt`, `Daos.kt`, `Entities.kt`
  - `SessionPreferences.kt`
- **Localization (`i18n/`):**
  - `AppStrings.kt` (English, Telugu, Hindi for Daily Labour & core UI)
  - `FilmStrings.kt` (English, Telugu, Hindi for Film Direct Connect & safety policies)
- **ViewModel (`ui/viewmodel/`):**
  - `DailyWorkViewModel.kt`
- **Screens & Components (`ui/screens/`, `ui/components/`, `ui/theme/`):**
  - `AuthScreen.kt`, `SharedScreens.kt`, `WorkerScreens.kt`, `EmployerScreens.kt`
  - `FilmArtistScreens.kt`, `FilmCastingScreens.kt`, `AdminScreen.kt`
  - `CommonComponents.kt`, `Color.kt`, `Theme.kt`, `Type.kt`
- **Utilities (`util/`):**
  - `GoogleAuthHelper.kt`, `PlatformHelpers.kt`

### 4. Android Manifest, Resources & Assets (`app/src/main/`)
- `AndroidManifest.xml`
- `res/values/` (`strings.xml`, `colors.xml`, `themes.xml`, `firebase_applet_config.xml`)
- `res/drawable/` (`img_dailywork_icon.png`, `img_worker_hero.jpg`, `img_employer_hero.jpg`, `img_film_connect_hero.jpg`, launcher vector XMLs)
- `res/font/`, `res/mipmap-*`, `res/xml/`

### 5. Automated Tests (`app/src/test/java/com/example/`)
- `ButtonInteractionsRobolectricTest.kt`
- `DailyWorkRepositoryRuleTest.kt`
- `FirestoreEmulatorTestBase.kt`
- `ExampleRobolectricTest.kt`
- `ExampleUnitTest.kt`
