package com.example.data

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

class DailyWorkRepositoryRuleTest : FirestoreEmulatorTestBase() {

    private suspend fun resetServiceAreasToLaunchDefault() = withContext(Dispatchers.IO) {
        val deleteUrl = URL(
            "http://127.0.0.1:8085/v1/projects/demo-no-project/databases/$databaseId/documents/app_config/service_areas"
        )
        val conn = (deleteUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "DELETE"
            setRequestProperty("Authorization", "Bearer owner")
            connectTimeout = 5000
            readTimeout = 10000
        }
        conn.responseCode
        conn.disconnect()
    }

    private suspend fun seedAdminDocument(adminUid: String) = withContext(Dispatchers.IO) {
        val adminUrl = URL(
            "http://127.0.0.1:8085/v1/projects/demo-no-project/databases/$databaseId/documents/admins?documentId=$adminUid"
        )
        val body = """{"fields":{"uid":{"stringValue":"$adminUid"},"createdAt":{"timestampValue":"2026-01-01T00:00:00Z"}}}"""
        val conn = (adminUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Authorization", "Bearer owner")
            setRequestProperty("Content-Type", "application/json")
            connectTimeout = 5000
            readTimeout = 10000
        }
        conn.outputStream.use { it.write(body.toByteArray()) }
        val code = conn.responseCode
        conn.disconnect()
        check(code in 200..299) { "Failed to seed admin doc in emulator: HTTP $code" }
    }

    @Test
    fun unauthenticated_observeOpenJobs_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repo = FirestoreRepository(firestore, auth)

        val thrown = try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repo.observeOpenJobs().first()
            }
            null
        } catch (e: Exception) {
            e
        }

        checkNotNull(thrown) { "Expected exception when unauthenticated" }
        val fsEx = thrown.unwrapFirestoreException()
        assertTrue(thrown is IllegalStateException || fsEx?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED)
    }

    @Test
    fun workerAndEmployer_endToEndFirestoreFlow_succeedsAndEnforcesRoles() = runBlocking {
        resetServiceAreasToLaunchDefault()
        val runSuffix = UUID.randomUUID().toString().take(8)
        val employerEmail = "employer_$runSuffix@test.com"
        val workerEmail = "worker_$runSuffix@test.com"

        // 1. Device 1: Sign in as Employer and register profile in Warangal
        val employerUid = signInTestUser(employerEmail)
        val employerRepo = FirestoreRepository(firestore, auth)
        val employerProfile = withTimeout(OP_TIMEOUT_MS) {
            employerRepo.registerProfile(
                name = "Sri Sai Builders",
                phone = "9848022222",
                role = UserRole.EMPLOYER,
                city = "Warangal",
                area = "Chowrasta",
                skill = WorkCategory.MASON,
                experienceYears = 5,
                expectedDailyWage = 900
            )
        }
        assertEquals(employerUid, employerProfile.uid)

        // 2. Employer posts a job in Hanamkonda (requires both city & locality)
        val jobId = withTimeout(OP_TIMEOUT_MS) {
            employerRepo.postJob(
                employer = employerProfile,
                title = "Brick Wall Plastering $runSuffix",
                category = WorkCategory.MASON,
                description = "Daily wage mason work",
                city = "Hanamkonda",
                area = "Subedari",
                dailyWage = 950,
                workersNeeded = 2,
                durationDays = 3,
                shiftTiming = "8:30 AM - 5:30 PM",
                includesMeals = true
            )
        }
        assertTrue(jobId.isNotBlank())

        // 3. Device 2: Sign in as Worker and register profile in Hanamkonda
        val workerUid = signInTestUser(workerEmail)
        val workerRepo = FirestoreRepository(firestore, auth)
        val workerProfile = withTimeout(OP_TIMEOUT_MS) {
            workerRepo.registerProfile(
                name = "Raju Naidu",
                phone = "9848011111",
                role = UserRole.WORKER,
                city = "Hanamkonda",
                area = "Nakkalagutta",
                skill = WorkCategory.MASON,
                experienceYears = 6,
                expectedDailyWage = 900
            )
        }
        assertEquals(workerUid, workerProfile.uid)

        // 4. Worker cannot post a job (role enforcement)
        val postDenied = try {
            withTimeout(OP_TIMEOUT_MS) {
                workerRepo.postJob(
                    employer = workerProfile,
                    title = "Unauthorized Job",
                    category = WorkCategory.HELPER,
                    description = "Should fail",
                    city = "Warangal",
                    area = "Chowrasta",
                    dailyWage = 600,
                    workersNeeded = 1,
                    durationDays = 1,
                    shiftTiming = "9-5",
                    includesMeals = false
                )
            }
            null
        } catch (e: FirebaseFirestoreException) {
            e
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, postDenied?.code)

        // 5. Worker observes open jobs & applies
        val openJobs = withTimeout(FLOW_TIMEOUT_MS) {
            workerRepo.observeOpenJobs().first { list -> list.any { it.id == jobId } }
        }
        val targetJob = openJobs.first { it.id == jobId }
        val applied = withTimeout(OP_TIMEOUT_MS) {
            workerRepo.applyForJob(workerProfile, targetJob, "Ready tomorrow")
        }
        assertTrue(applied)

        // Duplicate apply returns false
        val appliedAgain = withTimeout(OP_TIMEOUT_MS) {
            workerRepo.applyForJob(workerProfile, targetJob, "Duplicate")
        }
        assertFalse(appliedAgain)

        // 6. Cross-user PII protection: Worker cannot read Employer's /users/{employerUid}
        val piiDenied = try {
            withTimeout(OP_TIMEOUT_MS) {
                workerRepo.getUserProfile(employerUid)
            }
            null
        } catch (e: FirebaseFirestoreException) {
            e
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, piiDenied?.code)

        // 7. Employer observes application and accepts it
        signInTestUser(employerEmail)
        val empApps = withTimeout(FLOW_TIMEOUT_MS) {
            employerRepo.observeEmployerApplications(employerUid).first { list ->
                list.any { it.jobId == jobId && it.workerId == workerUid }
            }
        }
        val app = empApps.first { it.jobId == jobId && it.workerId == workerUid }
        withTimeout(OP_TIMEOUT_MS) {
            employerRepo.updateApplicationStatus(app, ApplicationStatus.ACCEPTED)
        }

        // 8. Worker sees ACCEPTED status and notification in real time
        signInTestUser(workerEmail)
        val workerApps = withTimeout(FLOW_TIMEOUT_MS) {
            workerRepo.observeWorkerApplications(workerUid).first { list ->
                list.any { it.id == app.id && it.statusEnum() == ApplicationStatus.ACCEPTED }
            }
        }
        assertTrue(workerApps.isNotEmpty())

        val workerNotifs = withTimeout(FLOW_TIMEOUT_MS) {
            workerRepo.observeNotifications(workerUid).first { list ->
                list.any { it.userId == workerUid && it.typeEnum() == NotificationType.APPLICATION_ACCEPTED }
            }
        }
        assertTrue(workerNotifs.isNotEmpty())
    }

    @Test
    fun workerRegistration_withKazipetAndRichProfile_persistsToUsersAndDirectory() = runBlocking {
        resetServiceAreasToLaunchDefault()
        val runSuffix = UUID.randomUUID().toString().take(8)
        val workerUid = signInTestUser("kazipet_worker_$runSuffix@test.com")
        val repo = FirestoreRepository(firestore, auth)

        val registered = withTimeout(OP_TIMEOUT_MS) {
            repo.registerProfile(
                name = "Kavitha Goud",
                phone = "9848055555",
                role = UserRole.WORKER,
                city = "Kazipet",
                area = "Kazipet Junction",
                skill = WorkCategory.ELECTRICIAN,
                experienceYears = 4,
                expectedDailyWage = 1000,
                skills = listOf(WorkCategory.ELECTRICIAN, WorkCategory.PLUMBER),
                spokenLanguages = listOf("Telugu", "Hindi"),
                gender = WorkerGender.FEMALE,
                availabilityStatus = WorkAvailability.AVAILABLE_THIS_WEEK,
                profilePhotoBase64 = "dGVzdF9waG90bw=="
            )
        }

        assertEquals(workerUid, registered.uid)
        assertEquals("Kazipet", registered.city)
        assertEquals("Kazipet Junction", registered.area)
        assertEquals(listOf(WorkCategory.ELECTRICIAN, WorkCategory.PLUMBER), registered.skillsEnumList())
        assertEquals(listOf("Telugu", "Hindi"), registered.spokenLanguagesList())
        assertEquals(WorkerGender.FEMALE, registered.genderEnum())
        assertEquals(WorkAvailability.AVAILABLE_THIS_WEEK, registered.availabilityEnum())
        assertEquals("dGVzdF9waG90bw==", registered.profilePhotoBase64)

        val dirEntry = withTimeout(FLOW_TIMEOUT_MS) {
            repo.observeWorkerDirectory().first { list -> list.any { it.uid == workerUid } }
                .first { it.uid == workerUid }
        }
        assertEquals("Kavitha Goud", dirEntry.name)
        assertEquals(listOf(WorkCategory.ELECTRICIAN, WorkCategory.PLUMBER), dirEntry.skillsEnumList())
        assertEquals(listOf("Telugu", "Hindi"), dirEntry.spokenLanguagesList())
        assertEquals(WorkerGender.FEMALE, dirEntry.genderEnum())
        assertEquals(WorkAvailability.AVAILABLE_THIS_WEEK, dirEntry.availabilityEnum())
        assertEquals("dGVzdF9waG90bw==", dirEntry.profilePhotoBase64)
    }

    @Test
    fun firstLaunch_serviceAreaRestrictsOutsideCitiesAndMissingLocality(): Unit = runBlocking {
        resetServiceAreasToLaunchDefault()
        val runSuffix = UUID.randomUUID().toString().take(8)
        val empEmail = "area_emp_$runSuffix@test.com"
        val empUid = signInTestUser(empEmail)
        val repo = FirestoreRepository(firestore, auth)

        // Registration outside launch cities (Karimnagar, Nizamabad) must fail
        val outsideRegError = try {
            withTimeout(OP_TIMEOUT_MS) {
                repo.registerProfile(
                    name = "Karimnagar Contractor",
                    phone = "9848033333",
                    role = UserRole.EMPLOYER,
                    city = "Karimnagar",
                    area = "Tower Circle",
                    skill = WorkCategory.MASON,
                    experienceYears = 5,
                    expectedDailyWage = 900
                )
            }
            null
        } catch (e: IllegalArgumentException) {
            e
        }
        checkNotNull(outsideRegError)

        // Register valid Hyderabad employer (now included on launch alongside tri-city)
        val validEmp = withTimeout(OP_TIMEOUT_MS) {
            repo.registerProfile(
                name = "Film Nagar Builders",
                phone = "9848033333",
                role = UserRole.EMPLOYER,
                city = "Hyderabad",
                area = "Film Nagar",
                skill = WorkCategory.MASON,
                experienceYears = 5,
                expectedDailyWage = 900
            )
        }
        assertEquals(empUid, validEmp.uid)

        // Posting a job with missing locality (blank area) must fail validation
        val blankAreaErr = try {
            withTimeout(OP_TIMEOUT_MS) {
                repo.postJob(
                    employer = validEmp,
                    title = "Missing Locality Job",
                    category = WorkCategory.HELPER,
                    description = "Should require locality",
                    city = "Warangal",
                    area = "",
                    dailyWage = 650,
                    workersNeeded = 1,
                    durationDays = 1,
                    shiftTiming = "9-5",
                    includesMeals = false
                )
            }
            null
        } catch (e: IllegalArgumentException) {
            e
        }
        checkNotNull(blankAreaErr)

        // Posting a job in Karimnagar before admin expansion must fail client validation AND rules
        val outsideJobErr = try {
            withTimeout(OP_TIMEOUT_MS) {
                repo.postJob(
                    employer = validEmp,
                    title = "Karimnagar Blocked Job",
                    category = WorkCategory.MASON,
                    description = "Blocked on first launch",
                    city = "Karimnagar",
                    area = "Tower Circle",
                    dailyWage = 850,
                    workersNeeded = 2,
                    durationDays = 2,
                    shiftTiming = "9-5",
                    includesMeals = true
                )
            }
            null
        } catch (e: IllegalArgumentException) {
            e
        }
        checkNotNull(outsideJobErr)
    }

    @Test
    fun adminCentralServiceAreaExpansion_enablesNewCityAndLocalityAcrossWorkerAndEmployerDevices(): Unit = runBlocking {
        resetServiceAreasToLaunchDefault()
        val runSuffix = UUID.randomUUID().toString().take(8)
        val adminEmail = "admin_expand_$runSuffix@test.com"
        val employerEmail = "emp_expand_$runSuffix@test.com"
        val workerEmail = "wrk_expand_$runSuffix@test.com"

        try {
            // 1. Seed Admin account and sign in as Admin
            val adminUid = signInTestUser(adminEmail)
            seedAdminDocument(adminUid)
            val adminRepo = FirestoreRepository(firestore, auth)

            // 2. Admin enables Karimnagar and adds custom city/locality Siddipet / Komati Cheruvu
            val launchConfig = withTimeout(OP_TIMEOUT_MS) { adminRepo.getActiveServiceAreasConfig() }
            assertEquals(listOf("Hyderabad", "Warangal", "Hanamkonda", "Kazipet"), launchConfig.activeCityNames())

            val withKarimnagar = withTimeout(OP_TIMEOUT_MS) {
                adminRepo.toggleServiceAreaCity(launchConfig, "Karimnagar", enable = true)
            }
            val withSiddipet = withTimeout(OP_TIMEOUT_MS) {
                adminRepo.addCustomServiceArea(
                    current = withKarimnagar,
                    cityName = "Siddipet",
                    state = "Telangana",
                    localityName = "Komati Cheruvu"
                )
            }
            assertTrue(withSiddipet.isCityEnabled("Karimnagar"))
            assertTrue(withSiddipet.isCityEnabled("Siddipet"))

            // 3. Employer Device reads updated config and registers + posts job in Siddipet & Karimnagar
            signInTestUser(employerEmail)
            val empRepo = FirestoreRepository(firestore, auth)
            val observedConfigEmp = withTimeout(FLOW_TIMEOUT_MS) {
                empRepo.observeServiceAreasConfig().first { cfg ->
                    cfg.isCityEnabled("Karimnagar") && cfg.isCityEnabled("Siddipet")
                }
            }
            val empProfile = withTimeout(OP_TIMEOUT_MS) {
                empRepo.registerProfile(
                    name = "Karimnagar Infra",
                    phone = "9848077777",
                    role = UserRole.EMPLOYER,
                    city = "Karimnagar",
                    area = "Tower Circle",
                    skill = WorkCategory.MASON,
                    experienceYears = 7,
                    expectedDailyWage = 950,
                    activeLocations = observedConfigEmp.toIndianLocations()
                )
            }
            val siddipetJobId = withTimeout(OP_TIMEOUT_MS) {
                empRepo.postJob(
                    employer = empProfile,
                    title = "Siddipet Park Masons $runSuffix",
                    category = WorkCategory.MASON,
                    description = "Urgent work",
                    city = "Siddipet",
                    area = "Komati Cheruvu",
                    dailyWage = 950,
                    workersNeeded = 2,
                    durationDays = 4,
                    shiftTiming = "8:30 AM - 5:30 PM",
                    includesMeals = true,
                    activeLocations = observedConfigEmp.toIndianLocations()
                )
            }

            // 4. Worker Device registers in Siddipet, discovers Siddipet job, and applies
            val workerUid = signInTestUser(workerEmail)
            val wrkRepo = FirestoreRepository(firestore, auth)
            val observedConfigWrk = withTimeout(FLOW_TIMEOUT_MS) {
                wrkRepo.observeServiceAreasConfig().first { cfg -> cfg.isCityEnabled("Siddipet") }
            }
            val wrkProfile = withTimeout(OP_TIMEOUT_MS) {
                wrkRepo.registerProfile(
                    name = "Mallesh Siddipet",
                    phone = "9848088888",
                    role = UserRole.WORKER,
                    city = "Siddipet",
                    area = "Komati Cheruvu",
                    skill = WorkCategory.MASON,
                    experienceYears = 4,
                    expectedDailyWage = 900,
                    activeLocations = observedConfigWrk.toIndianLocations()
                )
            }
            assertEquals("Siddipet", wrkProfile.city)

            val jobs = withTimeout(FLOW_TIMEOUT_MS) {
                wrkRepo.observeOpenJobs().first { list -> list.any { it.id == siddipetJobId } }
            }
            val targetJob = jobs.first { it.id == siddipetJobId }
            assertEquals("Siddipet", targetJob.city)
            assertEquals("Komati Cheruvu", targetJob.area)
            assertTrue(withTimeout(OP_TIMEOUT_MS) { wrkRepo.applyForJob(wrkProfile, targetJob, "Available today") })
            assertTrue(workerUid.isNotBlank())
        } finally {
            resetServiceAreasToLaunchDefault()
        }
    }

    @Test
    fun filmDirectConnect_verificationGatePostingApplyingAndModeration_succeedsEndToEnd(): Unit = runBlocking {
        var currentStep = "reset"
        try {
            resetServiceAreasToLaunchDefault()
            val runSuffix = UUID.randomUUID().toString().take(8)
            val adminEmail = "film_admin_$runSuffix@test.com"
            val castingEmail = "film_casting_$runSuffix@test.com"
            val artistEmail = "film_artist_$runSuffix@test.com"

            currentStep = "1.seedAdmin"
            val adminUid = signInTestUser(adminEmail)
            seedAdminDocument(adminUid)

            currentStep = "2.submitCastingVerification"
            val castingUid = signInTestUser(castingEmail)
            val castingRepo = FirestoreRepository(firestore, auth)
            val pendingCasting = withTimeout(OP_TIMEOUT_MS) {
                castingRepo.submitCastingVerification(
                    existing = null,
                    accountType = CastingAccountType.CASTING_DIRECTOR,
                    organizationName = "Tollywood Casting Studio $runSuffix",
                    contactName = "Sandeep Reddy",
                    phone = "9848044444",
                    city = "Hyderabad",
                    area = "Film Nagar",
                    projectCredits = "Telugu feature films and ad shoots",
                    idProofType = "Film Chamber Card",
                    idReferenceMasked = "TFCC-8891",
                    verificationNotes = "Feature casting in Film Nagar",
                    noBrokerConfirmed = true,
                    zeroFeeConfirmed = true
                )
            }
            assertEquals(CastingVerificationStatus.PENDING, pendingCasting.verificationStatusEnum())

            currentStep = "3.unverifiedPostBlocked"
            val unverifiedErr = try {
                withTimeout(OP_TIMEOUT_MS) {
                    castingRepo.postCastingRequirement(
                        castingProfile = pendingCasting,
                        projectName = "Should Fail",
                        roleTitle = "Junior Artist",
                        artistsNeeded = 5,
                        minAge = 18,
                        maxAge = 35,
                        genderPreference = GenderPreference.ANY,
                        languages = listOf("Telugu"),
                        shootingDate = "2026-12-01",
                        reportingTime = "6:30 AM",
                        city = "Hyderabad",
                        area = "Film Nagar",
                        paymentAmount = 1500,
                        paymentUnit = PaymentUnit.PER_DAY,
                        description = "Blocked while pending",
                        noBrokerConfirmed = true,
                        zeroFeeConfirmed = true
                    )
                }
                null
            } catch (e: IllegalArgumentException) {
                e
            }
            checkNotNull(unverifiedErr)

            currentStep = "4.adminVerifyCasting"
            signInTestUser(adminEmail)
            val adminRepo = FirestoreRepository(firestore, auth)
            withTimeout(OP_TIMEOUT_MS) {
                adminRepo.adminVerifyCastingProfile(pendingCasting, approve = true)
            }

            currentStep = "5.verifiedPostCasting"
            signInTestUser(castingEmail)
            val verifiedCasting = withTimeout(FLOW_TIMEOUT_MS) {
                castingRepo.observeCastingProfile(castingUid).first { it?.verificationStatusEnum() == CastingVerificationStatus.VERIFIED }
            }!!
            val postId = withTimeout(OP_TIMEOUT_MS) {
                castingRepo.postCastingRequirement(
                    castingProfile = verifiedCasting,
                    projectName = "Nizamabad Streets $runSuffix",
                    roleTitle = "Supporting College Friends",
                    artistsNeeded = 10,
                    minAge = 18,
                    maxAge = 30,
                    genderPreference = GenderPreference.ANY,
                    languages = listOf("Telugu", "Hindi"),
                    shootingDate = "2026-12-05",
                    reportingTime = "6:30 AM",
                    city = "Hyderabad",
                    area = "Jubilee Hills",
                    paymentAmount = 2000,
                    paymentUnit = PaymentUnit.PER_DAY,
                    description = "Meals provided on set, direct shoot pay.",
                    noBrokerConfirmed = true,
                    zeroFeeConfirmed = true
                )
            }
            assertTrue(postId.isNotBlank())

            currentStep = "6a.saveArtistProfile"
            val artistUid = signInTestUser(artistEmail)
            val artistRepo = FirestoreRepository(firestore, auth)
            val artistProfile = withTimeout(OP_TIMEOUT_MS) {
                artistRepo.saveArtistProfile(
                    existing = null,
                    name = "Keerthi Sharma",
                    age = 22,
                    gender = WorkerGender.FEMALE,
                    city = "Warangal",
                    area = "Chowrasta",
                    phone = "9848066666",
                    languages = listOf("Telugu", "English"),
                    experienceYears = 1,
                    skills = listOf(ArtistSkill.JUNIOR_ARTIST, ArtistSkill.SUPPORTING_ROLE),
                    bio = "Theater and short film artist.",
                    photosBase64 = listOf("dGVzdF9hcnRpc3RfcGhvdG8="),
                    noBrokerConfirmed = true,
                    zeroFeeAcknowledged = true
                )
            }
            assertEquals(artistUid, artistProfile.uid)

            currentStep = "6b.observeOpenCastingAndApply"
            val openPosts = withTimeout(FLOW_TIMEOUT_MS) {
                artistRepo.observeOpenCastingPosts().first { list -> list.any { it.id == postId } }
            }
            val targetPost = openPosts.first { it.id == postId }
            assertTrue(withTimeout(OP_TIMEOUT_MS) { artistRepo.applyToCastingPost(artistProfile, targetPost, "Ready at 6:30 AM") })
            assertFalse(withTimeout(OP_TIMEOUT_MS) { artistRepo.applyToCastingPost(artistProfile, targetPost, "Duplicate") })

            currentStep = "7.castingShortlistAndSelect"
            signInTestUser(castingEmail)
            val ownerApps = withTimeout(FLOW_TIMEOUT_MS) {
                castingRepo.observeCastingOwnerApplications(castingUid).first { list ->
                    list.any { it.postId == postId && it.artistId == artistUid }
                }
            }
            val castApp = ownerApps.first { it.postId == postId && it.artistId == artistUid }
            withTimeout(OP_TIMEOUT_MS) {
                castingRepo.updateCastingApplicationStatus(castApp, CastingApplicationStatus.SHORTLISTED)
            }
            withTimeout(OP_TIMEOUT_MS) {
                castingRepo.updateCastingApplicationStatus(castApp, CastingApplicationStatus.SELECTED)
            }

            currentStep = "8a.artistObservesSelectedAndNotif"
            signInTestUser(artistEmail)
            val artistApps = withTimeout(FLOW_TIMEOUT_MS) {
                artistRepo.observeArtistCastingApplications(artistUid).first { list ->
                    list.any { it.id == castApp.id && it.statusEnum() == CastingApplicationStatus.SELECTED }
                }
            }
            assertTrue(artistApps.isNotEmpty())

            val artistNotifs = withTimeout(FLOW_TIMEOUT_MS) {
                artistRepo.observeNotifications(artistUid).first { list ->
                    list.any { it.userId == artistUid && it.typeEnum() == NotificationType.CASTING_SELECTED }
                }
            }
            assertTrue(artistNotifs.isNotEmpty())

            currentStep = "8b.submitReport"
            withTimeout(OP_TIMEOUT_MS) {
                artistRepo.submitContentReport(
                    reporterName = artistProfile.name,
                    targetId = postId,
                    targetType = ReportTargetType.CASTING_POST,
                    targetOwnerId = castingUid,
                    targetLabel = targetPost.roleTitle,
                    reason = ReportReason.FAKE_CASTING,
                    details = "Automated rule test report"
                )
            }
            currentStep = "8c.blockEntity"
            withTimeout(OP_TIMEOUT_MS) {
                artistRepo.blockEntity(castingUid, ReportTargetType.CASTING_PROFILE, targetPost.organizationName)
            }
            val blocked = withTimeout(FLOW_TIMEOUT_MS) {
                artistRepo.observeBlockedEntities(artistUid).first { list -> list.any { it.targetId == castingUid } }
            }
            assertTrue(blocked.isNotEmpty())

            currentStep = "9.adminResolveReport"
            signInTestUser(adminEmail)
            val reports = withTimeout(FLOW_TIMEOUT_MS) {
                adminRepo.observeAllReportsAdmin().first { list -> list.any { it.targetId == postId } }
            }
            val reportDoc = reports.first { it.targetId == postId }
            withTimeout(OP_TIMEOUT_MS) {
                adminRepo.adminResolveReport(
                    report = reportDoc,
                    newStatus = ReportStatus.RESOLVED,
                    actionNote = "Verified test cleanup",
                    removeReportedPost = true,
                    suspendReportedOwner = false
                )
            }
        } catch (t: Throwable) {
            throw AssertionError("Failed at step [$currentStep]: ${t::class.simpleName}: ${t.message}", t)
        }
    }

    private companion object {
        const val OP_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 5000L
    }
}


