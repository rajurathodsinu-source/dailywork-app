package com.example

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppLanguage
import com.example.data.ApplicationStatus
import com.example.data.ArtistSkill
import com.example.data.CastingAccountType
import com.example.data.CastingApplicationStatus
import com.example.data.CastingVerificationStatus
import com.example.data.FirestoreApplication
import com.example.data.FirestoreArtistProfile
import com.example.data.FirestoreBlockedEntity
import com.example.data.FirestoreCastingApplication
import com.example.data.FirestoreCastingPost
import com.example.data.FirestoreCastingProfile
import com.example.data.FirestoreContentReport
import com.example.data.FirestoreJob
import com.example.data.FirestoreNotification
import com.example.data.FirestoreServiceAreasConfig
import com.example.data.FirestoreUser
import com.example.data.GenderPreference
import com.example.data.IndianLocations
import com.example.data.IndianMobileValidator
import com.example.data.JobStatus
import com.example.data.NotificationType
import com.example.data.PaymentUnit
import com.example.data.ReportReason
import com.example.data.ReportStatus
import com.example.data.ReportTargetType
import com.example.data.UserRole
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.data.WorkerGender
import com.example.i18n.AppStrings
import com.example.i18n.FilmStrings
import com.example.ui.components.CityAreaPicker
import com.example.ui.screens.AdminFilmModerationScreen
import com.example.ui.screens.AdminJobsAndBroadcastScreen
import com.example.ui.screens.AdminServiceAreasScreen
import com.example.ui.screens.AdminUsersScreen
import com.example.ui.screens.ArtistProfileAndAppsScreen
import com.example.ui.screens.CastingApplicantsScreen
import com.example.ui.screens.CastingStudioScreen
import com.example.ui.screens.EmployerApplicationsScreen
import com.example.ui.screens.EmployerHomeScreen
import com.example.ui.screens.FilmShootingCallsScreen
import com.example.ui.screens.GoogleSignInScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RoleOnboardingScreen
import com.example.ui.screens.WorkerJobsScreen
import com.example.ui.theme.DailyWorkTheme
import com.example.ui.viewmodel.JobWithDistance
import com.example.ui.viewmodel.LocalMigrationPreview
import com.example.util.GpsDetectionResult
import com.example.util.LocationHelper
import com.example.util.VoiceAssistant
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ButtonInteractionsRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `google sign in screen language role listen and sign in buttons all respond to clicks`() {
        val clickedLanguages = mutableListOf<AppLanguage>()
        val selectedRoles = mutableListOf<UserRole>()
        val spokenTexts = mutableListOf<String>()
        var signInClicks = 0
        var errorClears = 0

        composeTestRule.setContent {
            DailyWorkTheme {
                var language by remember { mutableStateOf(AppLanguage.ENGLISH) }
                var role by remember { mutableStateOf(UserRole.WORKER) }
                val strings = AppStrings.get(language)
                GoogleSignInScreen(
                    language = language,
                    strings = strings,
                    selectedRole = role,
                    isSigningIn = false,
                    authError = null,
                    onLanguageSelected = {
                        language = it
                        clickedLanguages.add(it)
                    },
                    onRoleSelected = {
                        role = it
                        selectedRoles.add(it)
                    },
                    onClearError = { errorClears++ },
                    onSpeak = { spokenTexts.add(it) },
                    onGoogleSignInClick = { signInClicks++ }
                )
            }
        }

        composeTestRule.waitForIdle()

        // 1. Language buttons: English -> Telugu -> Hindi -> English
        composeTestRule.onNodeWithTag("lang_btn_te").assertIsEnabled().performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf(AppLanguage.TELUGU), clickedLanguages)
        composeTestRule.onNodeWithTag("google_sign_in_button")
            .assertTextContains(AppStrings.get(AppLanguage.TELUGU).signInWithGoogle)

        composeTestRule.onNodeWithTag("lang_btn_hi").assertIsEnabled().performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf(AppLanguage.TELUGU, AppLanguage.HINDI), clickedLanguages)
        composeTestRule.onNodeWithTag("google_sign_in_button")
            .assertTextContains(AppStrings.get(AppLanguage.HINDI).signInWithGoogle)

        composeTestRule.onNodeWithTag("lang_btn_en").assertIsEnabled().performClick()
        composeTestRule.waitForIdle()
        assertEquals(listOf(AppLanguage.TELUGU, AppLanguage.HINDI, AppLanguage.ENGLISH), clickedLanguages)

        // 2. Listen button
        composeTestRule.onNodeWithTag("listen_button").assertIsEnabled().performClick()
        composeTestRule.waitForIdle()
        assertEquals(1, spokenTexts.size)
        assertTrue(spokenTexts.first().contains("DailyWork"))

        // 3. "I Want Workers" and "I Want Work" role buttons
        composeTestRule.onNodeWithTag("signin_role_employer_btn")
            .performScrollTo()
            .assertIsEnabled()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals(UserRole.EMPLOYER, selectedRoles.last())

        composeTestRule.onNodeWithTag("signin_role_worker_btn")
            .performScrollTo()
            .assertIsEnabled()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals(UserRole.WORKER, selectedRoles.last())

        // 4. Sign in with Google button
        composeTestRule.onNodeWithTag("google_sign_in_button")
            .performScrollTo()
            .assertIsEnabled()
            .performClick()
        composeTestRule.waitForIdle()
        assertEquals(1, signInClicks)
        assertTrue(errorClears >= 3)
    }

    @Test
    fun `role onboarding screen respects initial preferred role and all interactive controls respond`() {
        var submittedName = ""
        var submittedPhone = ""
        var submittedRole: UserRole? = null
        var submittedSkill: WorkCategory? = null
        var submittedSkills: List<WorkCategory> = emptyList()
        var signOutClicks = 0
        var spoken = ""
        var selectedLang = AppLanguage.ENGLISH

        composeTestRule.setContent {
            DailyWorkTheme {
                var lang by remember { mutableStateOf(AppLanguage.ENGLISH) }
                RoleOnboardingScreen(
                    firebaseDisplayName = "Srinivas",
                    firebaseEmail = "srinivas@example.com",
                    localMigrationPreview = LocalMigrationPreview(),
                    isAdminUser = false,
                    language = lang,
                    strings = AppStrings.get(lang),
                    authError = null,
                    onLanguageSelected = {
                        lang = it
                        selectedLang = it
                    },
                    onClearError = {},
                    onSpeak = { spoken = it },
                    onOpenAdminDashboard = {},
                    onRegisterProfile = { name, phone, role, _, _, skill, _, _, skills, _, _, _, _ ->
                        submittedName = name
                        submittedPhone = phone
                        submittedRole = role
                        submittedSkill = skill
                        submittedSkills = skills
                    },
                    onSignOut = { signOutClicks++ },
                    initialPreferredRole = UserRole.EMPLOYER
                )
            }
        }

        composeTestRule.waitForIdle()

        // Started in Employer mode because initialPreferredRole == EMPLOYER -> skill grid hidden
        composeTestRule.onNodeWithTag("multi_skill_ELECTRICIAN").assertDoesNotExist()

        // Tap Listen button
        composeTestRule.onNodeWithTag("listen_button").performClick()
        composeTestRule.waitForIdle()
        assertTrue(spoken.isNotBlank())

        // Tap Hindi language button
        composeTestRule.onNodeWithTag("lang_btn_hi").performClick()
        composeTestRule.waitForIdle()
        assertEquals(AppLanguage.HINDI, selectedLang)

        // Switch back to Worker ("I Want Work")
        composeTestRule.onNodeWithTag("role_worker_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Multi-skill grid is now visible; add Electrician alongside default Mason
        composeTestRule.onNodeWithTag("multi_skill_ELECTRICIAN").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Enter own full name and valid Indian mobile number, then submit
        composeTestRule.onNodeWithTag("reg_name_input").performScrollTo().performTextInput("Srinivas Rao")
        composeTestRule.onNodeWithTag("reg_phone_input").performScrollTo().performTextInput("9876543210")
        composeTestRule.onNodeWithTag("reg_submit_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertEquals("Srinivas Rao", submittedName)
        assertEquals("9876543210", submittedPhone)
        assertEquals(UserRole.WORKER, submittedRole)
        assertEquals(WorkCategory.MASON, submittedSkill)
        assertTrue(submittedSkills.contains(WorkCategory.ELECTRICIAN))

        // Tap Sign Out
        composeTestRule.onNodeWithTag("onboarding_sign_out_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(1, signOutClicks)
    }

    @Test
    fun `worker onboarding never autofills google email validates indian mobile and saves telangana profile`() {
        var submittedName = ""
        var submittedPhone = ""
        var submittedCity = ""
        var submittedArea = ""
        var submittedSkills: List<WorkCategory> = emptyList()
        var submittedLanguages: List<String> = emptyList()
        var submittedGender: WorkerGender? = null
        var submittedAvailability: WorkAvailability? = null

        composeTestRule.setContent {
            DailyWorkTheme {
                RoleOnboardingScreen(
                    firebaseDisplayName = "raju.worker@gmail.com",
                    firebaseEmail = "raju.worker@gmail.com",
                    localMigrationPreview = LocalMigrationPreview(),
                    isAdminUser = false,
                    language = AppLanguage.ENGLISH,
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    authError = null,
                    onLanguageSelected = {},
                    onClearError = {},
                    onSpeak = {},
                    onOpenAdminDashboard = {},
                    onRegisterProfile = { name, phone, _, city, area, _, _, _, skills, langs, gender, avail, _ ->
                        submittedName = name
                        submittedPhone = phone
                        submittedCity = city
                        submittedArea = area
                        submittedSkills = skills
                        submittedLanguages = langs
                        submittedGender = gender
                        submittedAvailability = avail
                    },
                    onSignOut = {},
                    initialPreferredRole = UserRole.WORKER
                )
            }
        }

        composeTestRule.waitForIdle()

        // Must NOT auto-fill email into name input and must not show email chip
        composeTestRule.onNodeWithTag("use_google_name_chip").assertDoesNotExist()

        // Invalid Indian mobile starting with 1 shows inline error
        composeTestRule.onNodeWithTag("reg_phone_input").performScrollTo().performTextInput("1234567890")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("reg_phone_error", useUnmergedTree = true)
            .performScrollTo()
            .assertIsDisplayed()

        // Replace with valid Indian mobile with +91 prefix -> sanitized cleanly and error disappears
        composeTestRule.onNodeWithTag("reg_phone_input").performScrollTo().performTextReplacement("+919848012345")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("reg_phone_error", useUnmergedTree = true).assertDoesNotExist()

        // Enter worker full name
        composeTestRule.onNodeWithTag("reg_name_input").performScrollTo().performTextInput("Raju Goud")

        // Search Telangana city/locality (Warangal)
        composeTestRule.onNodeWithTag("city_area_search_input").performScrollTo().performTextInput("Warangal")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("loc_match_Warangal_Chowrasta").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Select multiple skills, gender, spoken language, availability
        composeTestRule.onNodeWithTag("multi_skill_PAINTER").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("gender_MALE").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("spoken_lang_Hindi").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("availability_AVAILABLE_THIS_WEEK").performScrollTo().performClick()

        composeTestRule.onNodeWithTag("reg_submit_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertEquals("Raju Goud", submittedName)
        assertEquals("9848012345", submittedPhone)
        assertEquals("Warangal", submittedCity)
        assertEquals("Chowrasta", submittedArea)
        assertTrue(submittedSkills.contains(WorkCategory.MASON))
        assertTrue(submittedSkills.contains(WorkCategory.PAINTER))
        assertTrue(submittedLanguages.contains("Hindi"))
        assertEquals(WorkerGender.MALE, submittedGender)
        assertEquals(WorkAvailability.AVAILABLE_THIS_WEEK, submittedAvailability)
    }

    @Test
    fun `first launch supports hyderabad warangal hanamkonda and kazipet and restricts outside cities`() {
        val cities = IndianLocations.cities
        assertEquals(listOf("Hyderabad", "Warangal", "Hanamkonda", "Kazipet"), cities)
        assertTrue(cities.contains("Hyderabad"))
        assertFalse(cities.contains("Karimnagar"))
        assertFalse(cities.contains("Nizamabad"))

        val hydMatches = IndianLocations.searchLocations("film nagar")
        assertTrue(hydMatches.any { it.city == "Hyderabad" && it.area == "Film Nagar" })

        val kazipetMatches = IndianLocations.searchLocations("kazipet")
        assertTrue(kazipetMatches.any { it.city == "Kazipet" && it.area == "Kazipet Junction" })

        val hanamkondaMatches = IndianLocations.searchLocations("subedari")
        assertTrue(hanamkondaMatches.any { it.city == "Hanamkonda" })

        // Outside cities resolve via outside-catalog helper so Coming Soon banner can be shown
        assertEquals("Karimnagar", IndianLocations.findOutsideCatalogMatch("Karimnagar")?.city)
        assertEquals("Nizamabad", IndianLocations.findOutsideCatalogMatch("Nizamabad")?.city)

        // Blank locality or inactive city is strictly rejected
        assertNull(IndianLocations.findActiveLocation("Warangal", ""))
        assertNull(IndianLocations.findActiveLocation("Karimnagar", "Tower Circle"))

        // GPS coordinate evaluation
        val insideKazipet = LocationHelper.evaluateCoordinates(17.9736, 79.5061)
        assertTrue(insideKazipet is GpsDetectionResult.InsideServiceArea)
        assertEquals("Kazipet", (insideKazipet as GpsDetectionResult.InsideServiceArea).location.city)

        val insideHyd = LocationHelper.evaluateCoordinates(17.4167, 78.4094)
        assertTrue(insideHyd is GpsDetectionResult.InsideServiceArea)
        assertEquals("Hyderabad", (insideHyd as GpsDetectionResult.InsideServiceArea).location.city)

        val outsideGps = LocationHelper.evaluateCoordinates(18.4386, 79.1288)
        assertTrue(outsideGps is GpsDetectionResult.OutsideServiceArea)
        assertEquals("Karimnagar", (outsideGps as GpsDetectionResult.OutsideServiceArea).nearestKnownLabel)

        assertTrue(IndianMobileValidator.isValid("9848012345"))
        assertTrue(IndianMobileValidator.isValid("+91 6300112233"))
        assertFalse(IndianMobileValidator.isValid("5123456789"))
        assertFalse(IndianMobileValidator.isValid("1234567890"))
        assertFalse(IndianMobileValidator.isValid("984801234"))
    }

    @Test
    fun `worker jobs screen buttons switch location sheet apply and listen respond to clicks`() {
        var toggledAvailability = false
        var pickedLocation: Pair<String, String>? = null
        var appliedJobId = ""
        var appliedNote = ""
        var spokenJob = ""

        val sampleWorker = FirestoreUser(
            uid = "worker-1",
            name = "Raju",
            phone = "9848011111",
            role = UserRole.WORKER.name,
            city = "Warangal",
            area = "Chowrasta",
            primarySkill = WorkCategory.MASON.name,
            isAvailable = true
        )
        val sampleJob = FirestoreJob(
            id = "job-101",
            employerId = "emp-1",
            employerName = "Sri Sai Builders",
            employerPhone = "9848022222",
            title = "Brick Wall Masonry",
            category = WorkCategory.MASON.name,
            description = "Need 2 masons",
            city = "Warangal",
            area = "Hunter Road",
            dailyWage = 900L,
            workersNeeded = 2L,
            workDurationDays = 3L,
            status = JobStatus.OPEN.name
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                WorkerJobsScreen(
                    worker = sampleWorker,
                    selectedLocation = "Warangal" to "Chowrasta",
                    locationQuery = "",
                    categoryFilter = null,
                    minWageFilter = 0,
                    jobs = listOf(JobWithDistance(sampleJob, 3.2, null)),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onToggleAvailability = { toggledAvailability = true },
                    onLocationQueryChange = {},
                    onLocationPicked = { c, a -> pickedLocation = c to a },
                    onCategoryFilterChange = {},
                    onMinWageFilterChange = {},
                    onApplyJob = { job, note ->
                        appliedJobId = job.id
                        appliedNote = note
                    },
                    onSpeak = { spokenJob = it },
                    onShowMessage = {}
                )
            }
        }

        composeTestRule.waitForIdle()

        // Toggle availability switch
        composeTestRule.onNodeWithTag("worker_availability_switch").performClick()
        composeTestRule.waitForIdle()
        assertTrue(toggledAvailability)

        // Scroll to job card and click Listen inside job card
        composeTestRule.onNodeWithTag("worker_jobs_list")
            .performScrollToNode(hasTestTag("listen_button"))
        composeTestRule.onNodeWithTag("listen_button").performClick()
        composeTestRule.waitForIdle()
        assertTrue(spokenJob.contains("Brick Wall Masonry"))

        // Click Quick Apply button
        composeTestRule.onNodeWithTag("worker_jobs_list")
            .performScrollToNode(hasTestTag("apply_btn_job-101"))
        composeTestRule.onNodeWithTag("apply_btn_job-101").performClick()
        composeTestRule.waitForIdle()
        assertEquals("job-101", appliedJobId)
        assertEquals("", appliedNote)

        // Scroll back to City Picker button and select Kazipet
        composeTestRule.onNodeWithTag("worker_jobs_list")
            .performScrollToNode(hasTestTag("pick_city_btn"))
        composeTestRule.onNodeWithTag("pick_city_btn").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("city_chip_Kazipet").performScrollTo().assertIsDisplayed().performClick()
        composeTestRule.waitForIdle()
        assertEquals("Kazipet", pickedLocation?.first)
    }

    @Test
    fun `employer home post job button requires valid active city and locality and submits job`() {
        var postedJobTitle = ""
        var postedCity = ""
        var postedArea = ""
        // Start with an employer whose stored city is outside launch areas to verify inline enforcement
        val employerOutside = FirestoreUser(
            uid = "emp-1",
            name = "Kiran Contractors",
            phone = "9848022222",
            role = UserRole.EMPLOYER.name,
            city = "Karimnagar",
            area = "Tower Circle"
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                EmployerHomeScreen(
                    employer = employerOutside,
                    postedJobs = emptyList(),
                    applicationsCount = 1,
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onPostJob = { title, _, _, c, a, _, _, _, _, _ ->
                        postedJobTitle = title
                        postedCity = c
                        postedArea = a
                    },
                    onToggleJobStatus = { _, _ -> },
                    onDeleteJob = {}
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("open_post_job_btn").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_job_title_input").performTextInput("Plastering Site")

        // Submitting before picking an active city + locality shows inline location error and blocks submit
        composeTestRule.onNodeWithTag("publish_job_submit_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_job_location_error").performScrollTo().assertIsDisplayed()
        assertEquals("", postedJobTitle)

        // Pick Hanamkonda -> Subedari and submit successfully
        composeTestRule.onNodeWithTag("city_chip_Hanamkonda").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("area_chip_Subedari").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("publish_job_submit_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals("Plastering Site", postedJobTitle)
        assertEquals("Hanamkonda", postedCity)
        assertEquals("Subedari", postedArea)
    }

    @Test
    fun `worker jobs screen shows coming soon outside active service areas and resets`() {
        var dismissedOutside = false
        var queryValue = "Karimnagar"
        val sampleWorker = FirestoreUser(
            uid = "worker-1",
            name = "Raju",
            phone = "9848011111",
            role = UserRole.WORKER.name,
            city = "Warangal",
            area = "Chowrasta",
            primarySkill = WorkCategory.MASON.name,
            isAvailable = true
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                var query by remember { mutableStateOf("Karimnagar") }
                WorkerJobsScreen(
                    worker = sampleWorker,
                    selectedLocation = "Warangal" to "Chowrasta",
                    locationQuery = query,
                    categoryFilter = null,
                    minWageFilter = 0,
                    jobs = emptyList(),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onToggleAvailability = {},
                    onLocationQueryChange = {
                        query = it
                        queryValue = it
                    },
                    onLocationPicked = { _, _ -> },
                    onCategoryFilterChange = {},
                    onMinWageFilterChange = {},
                    onApplyJob = { _, _ -> },
                    onSpeak = {},
                    onShowMessage = {},
                    outsideAreaNotice = null,
                    onDismissOutsideNotice = { dismissedOutside = true }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("worker_jobs_list")
            .performScrollToNode(hasTestTag("worker_coming_soon_card"))
        composeTestRule.onNodeWithTag("worker_coming_soon_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("worker_jobs_list")
            .performScrollToNode(hasTestTag("coming_soon_reset_btn"))
        composeTestRule.onNodeWithTag("coming_soon_reset_btn").performClick()
        composeTestRule.waitForIdle()
        assertTrue(dismissedOutside)
        assertEquals("", queryValue)
    }

    @Test
    fun `city picker shows coming soon banner for karimnagar on launch`() {
        composeTestRule.setContent {
            DailyWorkTheme {
                Column(modifier = androidx.compose.ui.Modifier.verticalScroll(rememberScrollState())) {
                    CityAreaPicker(
                        selectedCity = "Warangal",
                        selectedArea = "Chowrasta",
                        onLocationSelected = { _, _ -> },
                        strings = AppStrings.get(AppLanguage.ENGLISH)
                    )
                }
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("city_area_search_input").performTextInput("Karimnagar")
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("city_picker_coming_soon").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("custom_area_chip").assertDoesNotExist()
    }

    @Test
    fun `admin service areas screen toggles expansion cities and adds custom city locality`() {
        var toggledCity: Pair<String, Boolean>? = null
        var addedCustom: Triple<String, String, String>? = null

        composeTestRule.setContent {
            DailyWorkTheme {
                AdminServiceAreasScreen(
                    config = FirestoreServiceAreasConfig.defaultLaunchConfig(),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onToggleCity = { city, enable -> toggledCity = city to enable },
                    onAddCustomArea = { c, s, l -> addedCustom = Triple(c, s, l) }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("admin_service_areas_list")
            .performScrollToNode(hasTestTag("toggle_city_Karimnagar"))
        composeTestRule.onNodeWithTag("toggle_city_Karimnagar").performClick()
        composeTestRule.waitForIdle()
        assertEquals("Karimnagar" to true, toggledCity)

        composeTestRule.onNodeWithTag("admin_service_areas_list")
            .performScrollToNode(hasTestTag("custom_city_input"))
        composeTestRule.onNodeWithTag("custom_city_input").performTextInput("Siddipet")
        composeTestRule.onNodeWithTag("custom_locality_input").performTextInput("Komati Cheruvu")
        composeTestRule.onNodeWithTag("admin_service_areas_list")
            .performScrollToNode(hasTestTag("add_service_area_btn"))
        composeTestRule.onNodeWithTag("add_service_area_btn").performClick()
        composeTestRule.waitForIdle()
        assertEquals(Triple("Siddipet", "Telangana", "Komati Cheruvu"), addedCustom)
    }

    @Test
    fun `employer applications accept button triggers status update`() {
        var updatedAppStatus: ApplicationStatus? = null
        val pendingApp = FirestoreApplication(
            id = "app-1",
            jobId = "job-1",
            jobTitle = "Site Helper",
            workerId = "worker-1",
            workerName = "Mahesh",
            workerPhone = "9848011111",
            workerArea = "Madhapur",
            employerId = "emp-1",
            status = ApplicationStatus.PENDING.name
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                EmployerApplicationsScreen(
                    applications = listOf(pendingApp),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onUpdateApplicationStatus = { _, st -> updatedAppStatus = st }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("accept_app_app-1").performClick()
        composeTestRule.waitForIdle()
        assertEquals(ApplicationStatus.ACCEPTED, updatedAppStatus)
    }

    @Test
    fun `notifications screen mark all read card tap and listen respond`() {
        var markedAllRead = false
        var markedSingleRead = false
        var spokenNotif = ""
        val unreadNotif = FirestoreNotification(
            id = "notif-1",
            userId = "emp-1",
            title = "New Applicant",
            message = "Mahesh applied",
            type = NotificationType.APPLICATION_RECEIVED.name,
            isRead = false
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                NotificationsScreen(
                    notifications = listOf(unreadNotif),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onMarkRead = { markedSingleRead = true },
                    onMarkAllRead = { markedAllRead = true },
                    onSpeak = { spokenNotif = it }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("mark_all_read_btn").performClick()
        composeTestRule.onNodeWithTag("listen_button").performClick()
        composeTestRule.onNodeWithTag("notification_card_notif-1").performClick()
        composeTestRule.waitForIdle()
        assertTrue(markedAllRead)
        assertTrue(markedSingleRead)
        assertTrue(spokenNotif.contains("New Applicant"))
    }

    @Test
    fun `profile screen language save and logout buttons respond`() {
        var savedProfileName = ""
        var logoutClicks = 0
        var selectedLang = AppLanguage.ENGLISH
        val employer = FirestoreUser(
            uid = "emp-1",
            name = "Kiran Contractors",
            phone = "9848022222",
            role = UserRole.EMPLOYER.name,
            city = "Hyderabad",
            area = "Madhapur"
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                var lang by remember { mutableStateOf(AppLanguage.ENGLISH) }
                ProfileScreen(
                    user = employer,
                    userEmail = "kiran@example.com",
                    isAdminUser = false,
                    adminModeEnabled = false,
                    language = lang,
                    strings = AppStrings.get(lang),
                    onLanguageSelected = {
                        lang = it
                        selectedLang = it
                    },
                    onToggleAvailability = {},
                    onToggleAdminMode = {},
                    onSaveProfile = { name, _, _, _, _, _, _, _, _, _, _, _ -> savedProfileName = name },
                    onLogout = { logoutClicks++ }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("lang_btn_te").performClick()
        composeTestRule.onNodeWithTag("save_profile_button").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("logout_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(AppLanguage.TELUGU, selectedLang)
        assertEquals("Kiran Contractors", savedProfileName)
        assertEquals(1, logoutClicks)
    }

    @Test
    fun `admin users verify and suspend buttons respond`() {
        var verifiedUser = false
        var suspendedUser = false
        val worker = FirestoreUser(
            id = "worker-1",
            uid = "worker-1",
            name = "Mahesh",
            phone = "9848011111",
            role = UserRole.WORKER.name,
            city = "Hyderabad",
            area = "Madhapur",
            isVerified = false,
            isSuspended = false
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                AdminUsersScreen(
                    users = listOf(worker),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onToggleVerify = { verifiedUser = true },
                    onToggleSuspend = { suspendedUser = true }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("verify_user_worker-1").performClick()
        composeTestRule.onNodeWithTag("suspend_user_worker-1").performClick()
        composeTestRule.waitForIdle()
        assertTrue(verifiedUser)
        assertTrue(suspendedUser)
    }

    @Test
    fun `admin broadcast send button responds`() {
        var broadcastTitle = ""
        composeTestRule.setContent {
            DailyWorkTheme {
                AdminJobsAndBroadcastScreen(
                    jobs = emptyList(),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    onToggleJobStatus = { _, _ -> },
                    onDeleteJob = {},
                    onSendBroadcast = { t, _, _ -> broadcastTitle = t }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("broadcast_title_input").performTextInput("Wage Alert")
        composeTestRule.onNodeWithTag("broadcast_msg_input").performTextInput("Minimum wage ₹600")
        composeTestRule.onNodeWithTag("send_broadcast_btn").assertIsEnabled().performClick()
        composeTestRule.waitForIdle()
        assertEquals("Wage Alert", broadcastTitle)
    }

    @Test
    fun `voice assistant always triggers fallback feedback when tts is unready`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val fallbackMessages = mutableListOf<String>()
        val assistant = VoiceAssistant(context) { text ->
            fallbackMessages.add(text)
        }
        assistant.speak("DailyWork. Find Work. Hire Workers.", AppLanguage.ENGLISH)
        assertFalse(fallbackMessages.isEmpty())
        assertTrue(fallbackMessages.first().contains("DailyWork"))
        assistant.shutdown()
    }

    // --- MODULE 2: FILM DIRECT CONNECT UI INTERACTION TESTS ---

    @Test
    fun `film shooting calls screen filters applies reports and blocks responsively`() {
        var roleFilterValue = ""
        var dateFilterValue = ""
        var cityFilterValue = ""
        var appliedPostId = ""
        var appliedNote = ""
        var reportedReason: ReportReason? = null
        var blockedTargetId = ""

        val artist = FirestoreArtistProfile(
            uid = "artist-1",
            name = "Ananya Reddy",
            age = 23L,
            city = "Hyderabad",
            area = "Film Nagar",
            phone = "9848099111"
        )
        val post = FirestoreCastingPost(
            id = "cast-101",
            posterId = "dir-1",
            posterName = "Vikram",
            organizationName = "Deccan Frames",
            posterAccountType = CastingAccountType.FILM_DIRECTOR.name,
            posterVerified = true,
            projectName = "Godavari Echoes",
            roleTitle = "College Crowd",
            artistsNeeded = 6L,
            minAge = 18L,
            maxAge = 28L,
            genderPreference = GenderPreference.ANY.name,
            languages = listOf("Telugu"),
            shootingDate = "2026-12-02",
            reportingTime = "6:30 AM",
            city = "Hyderabad",
            area = "Film Nagar",
            paymentAmount = 1800L,
            paymentUnit = PaymentUnit.PER_DAY.name,
            description = "Meals provided",
            status = JobStatus.OPEN.name
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                var r by remember { mutableStateOf("") }
                var d by remember { mutableStateOf("") }
                var c by remember { mutableStateOf("") }
                FilmShootingCallsScreen(
                    artistProfile = artist,
                    posts = listOf(post),
                    myApplications = emptyList(),
                    cityFilter = c,
                    dateFilter = d,
                    roleQuery = r,
                    activeCities = IndianLocations.launchCities,
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    filmStrings = FilmStrings.get(AppLanguage.ENGLISH),
                    onCityFilterChange = { c = it; cityFilterValue = it },
                    onDateFilterChange = { d = it; dateFilterValue = it },
                    onRoleQueryChange = { r = it; roleFilterValue = it },
                    onOpenArtistProfileTab = {},
                    onApplyPost = { p, note ->
                        appliedPostId = p.id
                        appliedNote = note
                    },
                    onSubmitReport = { _, reason, _ -> reportedReason = reason },
                    onBlockEntity = { id, _, _ -> blockedTargetId = id },
                    onSpeak = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("film_safety_banner").assertIsDisplayed()
        composeTestRule.onNodeWithTag("casting_search_role_input").performScrollTo().performTextInput("College")
        composeTestRule.onNodeWithTag("casting_search_date_input").performScrollTo().performTextInput("2026-12-02")
        composeTestRule.onNodeWithTag("casting_city_filter_Hyderabad").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals("College", roleFilterValue)
        assertEquals("2026-12-02", dateFilterValue)
        assertEquals("Hyderabad", cityFilterValue)

        // Direct apply dialog
        composeTestRule.onNodeWithTag("film_shooting_calls_list")
            .performScrollToNode(hasTestTag("casting_post_card_cast-101"))
        composeTestRule.onNodeWithTag("apply_casting_btn_cast-101").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("casting_apply_note_input").performTextInput("Available at 6 AM")
        composeTestRule.onNodeWithTag("confirm_apply_casting_btn").performClick()
        composeTestRule.waitForIdle()
        assertEquals("cast-101", appliedPostId)
        assertEquals("Available at 6 AM", appliedNote)

        // Report and Block actions
        composeTestRule.onNodeWithTag("report_casting_btn_cast-101").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("report_reason_MONEY_OR_FEE_DEMAND").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("confirm_submit_report_btn").performClick()
        composeTestRule.waitForIdle()
        assertEquals(ReportReason.MONEY_OR_FEE_DEMAND, reportedReason)

        composeTestRule.onNodeWithTag("block_casting_btn_cast-101").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals("dir-1", blockedTargetId)
    }

    @Test
    fun `artist profile screen saves profile skills languages and unblocks entities`() {
        var savedName = ""
        var savedAge = 0
        var savedSkills: List<ArtistSkill> = emptyList()
        var unblockedId = ""

        composeTestRule.setContent {
            DailyWorkTheme {
                ArtistProfileAndAppsScreen(
                    artistProfile = null,
                    myApplications = emptyList(),
                    blockedEntities = listOf(
                        FirestoreBlockedEntity(
                            id = "bad-dir",
                            targetId = "bad-dir",
                            targetType = ReportTargetType.CASTING_PROFILE.name,
                            targetLabel = "Suspicious Broker"
                        )
                    ),
                    activeLocations = IndianLocations.launchPresets,
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    filmStrings = FilmStrings.get(AppLanguage.ENGLISH),
                    onSaveArtistProfile = { name, age, _, _, _, _, _, _, skills, _, _, _, _ ->
                        savedName = name
                        savedAge = age
                        savedSkills = skills
                    },
                    onUnblock = { unblockedId = it }
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("artist_add_photo_btn").assertIsDisplayed()
        composeTestRule.onNodeWithTag("artist_name_input").performScrollTo().performTextInput("Karthik Varma")
        composeTestRule.onNodeWithTag("artist_age_input").performScrollTo().performTextReplacement("25")
        composeTestRule.onNodeWithTag("artist_phone_input").performScrollTo().performTextInput("9848055111")

        composeTestRule.onNodeWithTag("artist_skill_DANCER").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("save_artist_profile_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertEquals("Karthik Varma", savedName)
        assertEquals(25, savedAge)
        assertTrue(savedSkills.contains(ArtistSkill.DANCER))

        composeTestRule.onNodeWithTag("artist_profile_screen")
            .performScrollToNode(hasTestTag("unblock_btn_bad-dir"))
        composeTestRule.onNodeWithTag("unblock_btn_bad-dir").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals("bad-dir", unblockedId)
    }

    @Test
    fun `casting studio gates posting behind admin verification and supports all 9 verified roles`() {
        var submittedType: CastingAccountType? = null
        var submittedOrg = ""
        var postedProject = ""
        var postedRole = ""

        val verifiedProfile = FirestoreCastingProfile(
            uid = "cast-owner-1",
            accountType = CastingAccountType.WEB_SERIES_PRODUCER.name,
            organizationName = "Banjara Web Works",
            contactName = "Kranthi",
            phone = "9848022333",
            city = "Hyderabad",
            area = "Jubilee Hills",
            projectCredits = "Web series Season 1",
            idProofType = "Production Registration",
            idReferenceMasked = "PR-9921",
            noBrokerConfirmed = true,
            zeroFeeConfirmed = true,
            verificationStatus = CastingVerificationStatus.VERIFIED.name
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                var profile by remember { mutableStateOf<FirestoreCastingProfile?>(null) }
                CastingStudioScreen(
                    castingProfile = profile,
                    myPosts = emptyList(),
                    activeLocations = IndianLocations.launchPresets,
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    filmStrings = FilmStrings.get(AppLanguage.ENGLISH),
                    onSubmitVerification = { type, org, _, _, _, _, _, _, _, _, _, _ ->
                        submittedType = type
                        submittedOrg = org
                        profile = verifiedProfile
                    },
                    onPostCasting = { proj, role, _, _, _, _, _, _, _, _, _, _, _, _, _, _ ->
                        postedProject = proj
                        postedRole = role
                    },
                    onTogglePostStatus = { _, _ -> },
                    onDeletePost = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        // Initially unverified: Post button is disabled and all 9 allowed account types render
        composeTestRule.onNodeWithTag("open_post_casting_btn").assertIsNotEnabled()
        composeTestRule.onNodeWithTag("casting_studio_list")
            .performScrollToNode(hasTestTag("casting_verification_form"))
        CastingAccountType.entries.forEach { roleType ->
            composeTestRule.onNodeWithTag("casting_type_${roleType.name}").performScrollTo()
        }
        composeTestRule.onNodeWithTag("casting_type_WEB_SERIES_PRODUCER").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("casting_org_input").performScrollTo().performTextInput("Banjara Web Works")
        composeTestRule.onNodeWithTag("casting_contact_input").performScrollTo().performTextInput("Kranthi")
        composeTestRule.onNodeWithTag("casting_phone_input").performScrollTo().performTextInput("9848022333")
        composeTestRule.onNodeWithTag("casting_credits_input").performScrollTo().performTextInput("Web Series")
        composeTestRule.onNodeWithTag("casting_id_ref_input").performScrollTo().performTextInput("PR-9921")
        composeTestRule.onNodeWithTag("submit_casting_verify_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertEquals(CastingAccountType.WEB_SERIES_PRODUCER, submittedType)
        assertEquals("Banjara Web Works", submittedOrg)

        // Now verified: open bottom sheet & publish casting post
        composeTestRule.onNodeWithTag("casting_studio_list")
            .performScrollToNode(hasTestTag("casting_verification_status_card"))
        composeTestRule.onNodeWithTag("open_post_casting_btn").performScrollTo().assertIsEnabled().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("post_casting_project_input").performTextInput("Metro Tales S2")
        composeTestRule.onNodeWithTag("post_casting_role_input").performTextInput("Cafe Patrons")
        composeTestRule.onNodeWithTag("publish_casting_submit_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertEquals("Metro Tales S2", postedProject)
        assertEquals("Cafe Patrons", postedRole)
    }

    @Test
    fun `casting applicants screen shortlists selects hides pending phone and shows direct contact`() {
        var latestStatus: CastingApplicationStatus? = null
        val pendingApp = FirestoreCastingApplication(
            id = "capp-1",
            postId = "post-1",
            projectName = "Metro Tales",
            roleTitle = "Cafe Patron",
            castingOwnerId = "dir-1",
            organizationName = "Banjara Web Works",
            artistId = "art-1",
            artistName = "Divya",
            artistAge = 24L,
            artistCity = "Warangal",
            artistArea = "Chowrasta",
            artistPhone = "9848077889",
            artistLanguages = listOf("Telugu"),
            status = CastingApplicationStatus.PENDING.name
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                var appState by remember { mutableStateOf(pendingApp) }
                CastingApplicantsScreen(
                    applications = listOf(appState),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    filmStrings = FilmStrings.get(AppLanguage.ENGLISH),
                    onUpdateStatus = { _, st ->
                        latestStatus = st
                        appState = appState.copy(status = st.name)
                    },
                    onSubmitReport = { _, _, _ -> },
                    onBlockArtist = { _, _, _ -> },
                    onShowMessage = {}
                )
            }
        }
        composeTestRule.waitForIdle()

        // Contact buttons hidden while PENDING; shortlist unlocks them
        composeTestRule.onNodeWithTag("contact_selected_artist_call_capp-1").assertDoesNotExist()
        composeTestRule.onNodeWithTag("shortlist_applicant_btn_capp-1").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(CastingApplicationStatus.SHORTLISTED, latestStatus)

        composeTestRule.onNodeWithTag("contact_selected_artist_call_capp-1").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("select_applicant_btn_capp-1").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(CastingApplicationStatus.SELECTED, latestStatus)
    }

    @Test
    fun `admin film moderation verifies casting profile and resolves safety report`() {
        var approvedUid = ""
        var resolvedReportId = ""
        val pendingCasting = FirestoreCastingProfile(
            uid = "cast-pending-1",
            accountType = CastingAccountType.AD_FILM_MAKER.name,
            organizationName = "Charminar Ad Films",
            contactName = "Tariq",
            phone = "9848011223",
            city = "Hyderabad",
            area = "Banjara Hills",
            projectCredits = "TV Commercials",
            idProofType = "GST Cert",
            idReferenceMasked = "GST-9910",
            verificationStatus = CastingVerificationStatus.PENDING.name
        )
        val openReport = FirestoreContentReport(
            id = "rep-101",
            reporterId = "art-1",
            reporterName = "Meera",
            targetId = "post-fake",
            targetType = ReportTargetType.CASTING_POST.name,
            targetOwnerId = "cast-pending-1",
            targetLabel = "Suspicious Fee Call",
            reason = ReportReason.MONEY_OR_FEE_DEMAND.name,
            details = "Asked ₹500 card fee",
            status = ReportStatus.OPEN.name
        )

        composeTestRule.setContent {
            DailyWorkTheme {
                AdminFilmModerationScreen(
                    castingProfiles = listOf(pendingCasting),
                    reports = listOf(openReport),
                    strings = AppStrings.get(AppLanguage.ENGLISH),
                    filmStrings = FilmStrings.get(AppLanguage.ENGLISH),
                    onVerifyCasting = { p, approve, _ -> if (approve) approvedUid = p.uid },
                    onToggleSuspendCasting = {},
                    onResolveReport = { r, _, _, _, _ -> resolvedReportId = r.id }
                )
            }
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("admin_verify_casting_cast-pending-1").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals("cast-pending-1", approvedUid)

        composeTestRule.onNodeWithTag("admin_film_moderation_list")
            .performScrollToNode(hasTestTag("admin_resolve_close_post_rep-101"))
        composeTestRule.onNodeWithTag("admin_resolve_close_post_rep-101").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals("rep-101", resolvedReportId)
    }
}
