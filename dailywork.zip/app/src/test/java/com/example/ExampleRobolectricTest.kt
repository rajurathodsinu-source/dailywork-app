package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppLanguage
import com.example.data.ApplicationStatus
import com.example.data.AuthResult
import com.example.data.DailyWorkDatabase
import com.example.data.DailyWorkRepository
import com.example.data.IndianLocations
import com.example.data.SessionPreferences
import com.example.data.UserRole
import com.example.data.WorkCategory
import com.example.i18n.AppStrings
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: DailyWorkDatabase
    private lateinit var repository: DailyWorkRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, DailyWorkDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = DailyWorkRepository(db, SessionPreferences(context))
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name and multilingual strings load properly`() {
        assertEquals("DailyWork", context.getString(R.string.app_name))
        assertEquals("DailyWork", AppStrings.get(AppLanguage.ENGLISH).appName)
        assertEquals("డైలీవర్క్ (DailyWork)", AppStrings.get(AppLanguage.TELUGU).appName)
        assertEquals("डेलीवर्क (DailyWork)", AppStrings.get(AppLanguage.HINDI).appName)
    }

    @Test
    fun `haversine distance identifies nearby location accurately`() {
        val madhapur = IndianLocations.findLocation("Hyderabad", "Madhapur")
        val gachibowli = IndianLocations.findLocation("Hyderabad", "Gachibowli")
        val delhi = IndianLocations.findLocation("Delhi", "Dwarka")

        val localDist = IndianLocations.haversineKm(
            madhapur.latitude, madhapur.longitude,
            gachibowli.latitude, gachibowli.longitude
        )
        val farDist = IndianLocations.haversineKm(
            madhapur.latitude, madhapur.longitude,
            delhi.latitude, delhi.longitude
        )
        assertTrue(localDist < 10.0)
        assertTrue(farDist > 1000.0)
    }

    @Test
    fun `worker employer and admin end to end workflow works`() = runTest {
        repository.ensureSeedData()
        val seededJobs = repository.allJobsFlow.first()
        assertTrue(seededJobs.isNotEmpty())

        // Register a new employer
        val empRes = repository.registerUser(
            name = "Kaveri Builders",
            phone = "9999988888",
            pin = "4321",
            role = UserRole.EMPLOYER,
            city = "Hyderabad",
            area = "Madhapur",
            skill = WorkCategory.MASON,
            experienceYears = 5,
            expectedDailyWage = 900
        )
        assertTrue(empRes is AuthResult.Success)
        val employer = (empRes as AuthResult.Success).user

        // Post a job
        val jobId = repository.postJob(
            employer = employer,
            title = "Ceiling Wiring",
            category = WorkCategory.ELECTRICIAN,
            description = "Need 2 electricians",
            city = "Hyderabad",
            area = "Madhapur",
            dailyWage = 1050,
            workersNeeded = 2,
            durationDays = 2,
            shiftTiming = "9:00 AM - 6:00 PM",
            includesMeals = true
        )
        assertTrue(jobId > 0L)

        // Register a new worker
        val workerRes = repository.registerUser(
            name = "Ravi Shankar",
            phone = "9999977777",
            pin = "1111",
            role = UserRole.WORKER,
            city = "Hyderabad",
            area = "Kukatpally",
            skill = WorkCategory.ELECTRICIAN,
            experienceYears = 4,
            expectedDailyWage = 1000
        )
        assertTrue(workerRes is AuthResult.Success)
        val worker = (workerRes as AuthResult.Success).user

        val job = repository.allJobsFlow.first().first { it.id == jobId }
        val applied = repository.applyForJob(worker, job, "Ready tomorrow")
        assertTrue(applied)

        val apps = repository.observeEmployerApplications(employer.id).first()
        assertEquals(1, apps.size)
        val app = apps.first()

        // Accept and complete
        repository.updateApplicationStatus(app, ApplicationStatus.ACCEPTED, job.title)
        repository.updateApplicationStatus(app.copy(status = ApplicationStatus.ACCEPTED), ApplicationStatus.COMPLETED, job.title)

        val updatedWorker = repository.observeUser(worker.id).first()!!
        assertEquals(1, updatedWorker.completedJobs)

        // Admin verify & suspend check
        repository.toggleVerifyUser(updatedWorker)
        assertTrue(repository.observeUser(worker.id).first()!!.isVerified)

        repository.toggleSuspendUser(updatedWorker)
        val suspendedLogin = repository.login("9999977777", "1111")
        assertTrue(suspendedLogin is AuthResult.Error)
    }
}
