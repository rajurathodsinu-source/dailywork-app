package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm, dignified, high-contrast sunlight-readable palette for Indian DailyWork
val SaffronPrimary = Color(0xFFD74901)
val SaffronPrimaryDark = Color(0xFFFF8A50)
val SaffronContainer = Color(0xFFFFE6D5)
val OnSaffronContainer = Color(0xFF4A1800)

val TealSecondary = Color(0xFF0F766E)
val TealSecondaryDark = Color(0xFF5EEAD4)
val TealContainer = Color(0xFFCCFBF1)
val OnTealContainer = Color(0xFF042F2E)

val AmberTertiary = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)
val OnAmberContainer = Color(0xFF451A03)

val EmeraldSuccess = Color(0xFF15803D)
val EmeraldContainer = Color(0xFFDCFCE7)
val CrimsonError = Color(0xFFB91C1C)
val CrimsonContainer = Color(0xFFFEE2E2)

val CreamBackground = Color(0xFFFFFBF7)
val WarmSurface = Color(0xFFFFFFFF)
val SandSurfaceVariant = Color(0xFFF5ECE3)
val WarmOutline = Color(0xFFD6C7B8)
val InkPrimary = Color(0xFF1C1917)
val InkSecondary = Color(0xFF57534E)

val DarkBackground = Color(0xFF161210)
val DarkSurface = Color(0xFF211C19)
val DarkSurfaceVariant = Color(0xFF332B26)
val DarkInkPrimary = Color(0xFFF5F0EB)
val DarkInkSecondary = Color(0xFFC8BEB4)
