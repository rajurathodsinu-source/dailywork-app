package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppLanguage
import com.example.data.AppModule
import com.example.data.ApplicationStatus
import com.example.data.ArtistSkill
import com.example.data.CastingAccountType
import com.example.data.CastingApplicationStatus
import com.example.data.DailyWorkDatabase
import com.example.data.FilmSubRole
import com.example.data.FirestoreApplication
import com.example.data.FirestoreArtistProfile
import com.example.data.FirestoreBlockedEntity
import com.example.data.FirestoreCastingApplication
import com.example.data.FirestoreCastingPost
import com.example.data.FirestoreCastingProfile
import com.example.data.FirestoreContentReport
import com.example.data.FirestoreJob
import com.example.data.FirestoreNotification
import com.example.data.FirestoreRepository
import com.example.data.FirestoreServiceAreasConfig
import com.example.data.FirestoreUser
import com.example.data.GenderPreference
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.IndianMobileValidator
import com.example.data.JobEntity
import com.example.data.JobStatus
import com.example.data.PaymentUnit
import com.example.data.ReportReason
import com.example.data.ReportStatus
import com.example.data.ReportTargetType
import com.example.data.SessionPreferences
import com.example.data.UserEntity
import com.example.data.UserRole
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.data.WorkerGender
import com.example.i18n.AppStrings
import com.example.i18n.FilmStrings
import com.example.util.GpsDetectionResult
import com.example.util.LocalNotificationHelper
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class JobWithDistance(
    val job: FirestoreJob,
    val distanceKm: Double,
    val applicationStatus: ApplicationStatus?
)

data class AdminStats(
    val totalWorkers: Int = 0,
    val totalEmployers: Int = 0,
    val openJobs: Int = 0,
    val totalApplications: Int = 0,
    val averageDailyWage: Int = 0,
    val lowWageJobsCount: Int = 0,
    val avgWageByCategory: Map<WorkCategory, Int> = emptyMap()
)

data class LocalMigrationPreview(
    val localUser: UserEntity? = null,
    val localJobs: List<JobEntity> = emptyList()
) {
    val hasData: Boolean get() = localUser != null || localJobs.isNotEmpty()
}

sealed interface ProfileUiState {
    data object Loading : ProfileUiState
    data object NeedsOnboarding : ProfileUiState
    data class Ready(val user: FirestoreUser) : ProfileUiState
    data class Error(val message: String) : ProfileUiState
}

@OptIn(ExperimentalCoroutinesApi::class)
class DailyWorkViewModel(
    private val firestoreRepo: FirestoreRepository,
    private val localDb: DailyWorkDatabase,
    private val prefs: SessionPreferences,
    private val currentUserId: String,
    private val currentUserEmail: String?,
    private val isEmailVerified: Boolean,
    private val appContext: Context
) : ViewModel() {

    private val _locationQuery = MutableStateFlow("")
    private val _categoryFilter = MutableStateFlow<WorkCategory?>(null)
    private val _minWageFilter = MutableStateFlow(0)
    private val _workerSearchQuery = MutableStateFlow("")
    private val _workerSkillFilter = MutableStateFlow<WorkCategory?>(null)
    private val _authError = MutableStateFlow<String?>(null)
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    private val _isAdminUser = MutableStateFlow(
        isEmailVerified && currentUserEmail == "rajurathodsinu@gmail.com"
    )
    private val _localMigrationPreview = MutableStateFlow(LocalMigrationPreview())
    private val _gpsCoordinates = MutableStateFlow<Pair<Double, Double>?>(null)
    private val _gpsOutsideAreaLabel = MutableStateFlow<String?>(null)
    private val _castingCityFilter = MutableStateFlow("")
    private val _castingDateFilter = MutableStateFlow("")
    private val _castingRoleQuery = MutableStateFlow("")

    val locationQuery: StateFlow<String> = _locationQuery.asStateFlow()
    val categoryFilter: StateFlow<WorkCategory?> = _categoryFilter.asStateFlow()
    val minWageFilter: StateFlow<Int> = _minWageFilter.asStateFlow()
    val workerSearchQuery: StateFlow<String> = _workerSearchQuery.asStateFlow()
    val workerSkillFilter: StateFlow<WorkCategory?> = _workerSkillFilter.asStateFlow()
    val castingCityFilter: StateFlow<String> = _castingCityFilter.asStateFlow()
    val castingDateFilter: StateFlow<String> = _castingDateFilter.asStateFlow()
    val castingRoleQuery: StateFlow<String> = _castingRoleQuery.asStateFlow()
    val authError: StateFlow<String?> = _authError.asStateFlow()
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()
    val isAdminUser: StateFlow<Boolean> = _isAdminUser.asStateFlow()
    val localMigrationPreview: StateFlow<LocalMigrationPreview> = _localMigrationPreview.asStateFlow()

    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    val activeModule: StateFlow<AppModule> = prefs.selectedModuleFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AppModule.DAILY_LABOUR)

    val filmSubRole: StateFlow<FilmSubRole> = prefs.filmSubRoleFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), FilmSubRole.ARTIST)

    val serviceAreasConfig: StateFlow<FirestoreServiceAreasConfig> =
        firestoreRepo.observeServiceAreasConfig()
            .stateIn(
                viewModelScope,
                SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
                FirestoreServiceAreasConfig.defaultLaunchConfig()
            )

    val activeLocations: StateFlow<List<IndianLocation>> = serviceAreasConfig
        .map { it.toIndianLocations() }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
            IndianLocations.launchPresets
        )

    val activeCities: StateFlow<List<String>> = serviceAreasConfig
        .map { it.activeCityNames() }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
            IndianLocations.launchCities
        )

    val selectedLocation: StateFlow<Pair<String, String>> = combine(
        prefs.locationFlow,
        activeLocations
    ) { stored, locations ->
        val valid = IndianLocations.findActiveLocation(stored.first, stored.second, locations)
        if (valid != null) {
            valid.city to valid.area
        } else {
            val fallback = locations.firstOrNull() ?: IndianLocations.defaultLocation
            fallback.city to fallback.area
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), "Warangal" to "Chowrasta")

    val adminModeEnabled: StateFlow<Boolean> = prefs.adminModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), false)

    val profileState: StateFlow<ProfileUiState> = firestoreRepo.observeUserProfile(currentUserId)
        .map<FirestoreUser?, ProfileUiState> { profile ->
            if (profile == null) ProfileUiState.NeedsOnboarding else ProfileUiState.Ready(profile)
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing user profile", rootError)
            emit(ProfileUiState.Error(rootError.message ?: "Failed to load profile"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ProfileUiState.Loading)

    val currentUser: StateFlow<FirestoreUser?> = profileState
        .map { (it as? ProfileUiState.Ready)?.user }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val workerApplications: StateFlow<List<FirestoreApplication>> = currentUser
        .flatMapLatest { user ->
            if (user == null || user.roleEnum() != UserRole.WORKER) flowOf(emptyList())
            else firestoreRepo.observeWorkerApplications(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "workerApplications")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val openJobs: StateFlow<List<FirestoreJob>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else firestoreRepo.observeOpenJobs()
                .catch { error ->
                    unwrapAndLog(error, "openJobs")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val nearbyJobs: StateFlow<List<JobWithDistance>> = combine(
        openJobs,
        selectedLocation,
        _locationQuery,
        _categoryFilter,
        _minWageFilter,
        workerApplications,
        activeLocations,
        _gpsCoordinates
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val jobs = values[0] as List<FirestoreJob>
        @Suppress("UNCHECKED_CAST")
        val locPair = values[1] as Pair<String, String>
        val query = values[2] as String
        val catFilter = values[3] as WorkCategory?
        val minWage = values[4] as Int
        @Suppress("UNCHECKED_CAST")
        val myApps = values[5] as List<FirestoreApplication>
        @Suppress("UNCHECKED_CAST")
        val enabledLocs = values[6] as List<IndianLocation>
        @Suppress("UNCHECKED_CAST")
        val gpsCoords = values[7] as Pair<Double, Double>?

        val appStatusMap = myApps.associate { it.jobId to it.statusEnum() }
        val userLoc = IndianLocations.findActiveLocation(locPair.first, locPair.second, enabledLocs)
            ?: enabledLocs.firstOrNull()
            ?: IndianLocations.defaultLocation
        val refLat = gpsCoords?.first ?: userLoc.latitude
        val refLng = gpsCoords?.second ?: userLoc.longitude
        val cleanQuery = query.trim().lowercase()

        // Strictly show jobs ONLY in the worker's selected enabled service area city
        jobs.filter { IndianLocations.isWithinServiceArea(it.city, enabledLocs) }
            .filter { it.city.equals(userLoc.city, ignoreCase = true) }
            .filter { catFilter == null || it.categoryEnum() == catFilter }
            .filter { it.dailyWage.toInt() >= minWage }
            .filter {
                cleanQuery.isEmpty() ||
                    it.area.lowercase().contains(cleanQuery) ||
                    it.city.lowercase().contains(cleanQuery) ||
                    it.title.lowercase().contains(cleanQuery) ||
                    it.employerName.lowercase().contains(cleanQuery)
            }
            .map { job ->
                val dist = IndianLocations.haversineKm(
                    refLat,
                    refLng,
                    job.latitude,
                    job.longitude
                )
                JobWithDistance(
                    job = job,
                    distanceKm = dist,
                    applicationStatus = appStatusMap[job.id]
                )
            }
            .sortedWith(compareBy<JobWithDistance> { it.distanceKm })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val outsideAreaNotice: StateFlow<String?> = combine(
        _locationQuery,
        _gpsOutsideAreaLabel,
        activeLocations,
        nearbyJobs
    ) { query, gpsOutsideLabel, enabledLocs, visibleJobs ->
        val outsideMatch = IndianLocations.findOutsideCatalogMatch(query, enabledLocs)
        when {
            outsideMatch != null -> outsideMatch.city
            gpsOutsideLabel != null && query.isBlank() -> gpsOutsideLabel
            query.trim().length >= 3 &&
                visibleJobs.isEmpty() &&
                IndianLocations.searchLocations(query, enabledLocs).isEmpty() -> query.trim()
            else -> null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val employerJobs: StateFlow<List<FirestoreJob>> = currentUser
        .flatMapLatest { user ->
            if (user == null || user.roleEnum() != UserRole.EMPLOYER) flowOf(emptyList())
            else firestoreRepo.observeEmployerJobs(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "employerJobs")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val employerApplications: StateFlow<List<FirestoreApplication>> = currentUser
        .flatMapLatest { user ->
            if (user == null || user.roleEnum() != UserRole.EMPLOYER) flowOf(emptyList())
            else firestoreRepo.observeEmployerApplications(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "employerApplications")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    private val workerDirectory: StateFlow<List<FirestoreUser>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else firestoreRepo.observeWorkerDirectory()
                .catch { error ->
                    unwrapAndLog(error, "workerDirectory")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val filteredWorkers: StateFlow<List<FirestoreUser>> = combine(
        workerDirectory,
        _workerSearchQuery,
        _workerSkillFilter,
        activeLocations
    ) { workers, query, skill, enabledLocs ->
        val clean = query.trim().lowercase()
        workers.filter { IndianLocations.isWithinServiceArea(it.city, enabledLocs) }
            .filter { skill == null || it.skillsEnumList().contains(skill) }
            .filter { worker ->
                clean.isEmpty() ||
                    worker.name.lowercase().contains(clean) ||
                    worker.city.lowercase().contains(clean) ||
                    worker.area.lowercase().contains(clean) ||
                    worker.spokenLanguagesList().any { lang -> lang.lowercase().contains(clean) }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    // =====================================================================
    // MODULE 2: FILM DIRECT CONNECT STREAMS
    // =====================================================================

    val artistProfile: StateFlow<FirestoreArtistProfile?> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(null)
            else firestoreRepo.observeArtistProfile(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "artistProfile")
                    emit(null)
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val castingProfile: StateFlow<FirestoreCastingProfile?> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(null)
            else firestoreRepo.observeCastingProfile(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "castingProfile")
                    emit(null)
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val blockedEntities: StateFlow<List<FirestoreBlockedEntity>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else firestoreRepo.observeBlockedEntities(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "blockedEntities")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val openCastingPosts: StateFlow<List<FirestoreCastingPost>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else firestoreRepo.observeOpenCastingPosts()
                .catch { error ->
                    unwrapAndLog(error, "openCastingPosts")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val filteredCastingPosts: StateFlow<List<FirestoreCastingPost>> = combine(
        openCastingPosts,
        blockedEntities,
        _castingCityFilter,
        _castingDateFilter,
        _castingRoleQuery,
        activeLocations
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val posts = values[0] as List<FirestoreCastingPost>
        @Suppress("UNCHECKED_CAST")
        val blocked = values[1] as List<FirestoreBlockedEntity>
        val cityFilter = (values[2] as String).trim()
        val dateFilter = (values[3] as String).trim().lowercase()
        val roleQuery = (values[4] as String).trim().lowercase()
        @Suppress("UNCHECKED_CAST")
        val enabledLocs = values[5] as List<IndianLocation>

        val blockedIds = blocked.map { it.targetId }.toSet()
        posts.filter { post ->
            !blockedIds.contains(post.id) && !blockedIds.contains(post.posterId)
        }
            .filter { IndianLocations.isWithinServiceArea(it.city, enabledLocs) }
            .filter { cityFilter.isEmpty() || it.city.equals(cityFilter, ignoreCase = true) }
            .filter { dateFilter.isEmpty() || it.shootingDate.lowercase().contains(dateFilter) }
            .filter { post ->
                roleQuery.isEmpty() ||
                    post.roleTitle.lowercase().contains(roleQuery) ||
                    post.projectName.lowercase().contains(roleQuery) ||
                    post.organizationName.lowercase().contains(roleQuery) ||
                    post.area.lowercase().contains(roleQuery) ||
                    post.city.lowercase().contains(roleQuery) ||
                    post.description.lowercase().contains(roleQuery)
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val myCastingApplications: StateFlow<List<FirestoreCastingApplication>> = artistProfile
        .flatMapLatest { artist ->
            if (artist == null) flowOf(emptyList())
            else firestoreRepo.observeArtistCastingApplications(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "myCastingApplications")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val myCastingPosts: StateFlow<List<FirestoreCastingPost>> = castingProfile
        .flatMapLatest { profile ->
            if (profile == null) flowOf(emptyList())
            else firestoreRepo.observeMyCastingPosts(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "myCastingPosts")
                    emit(emptyList())
                }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val castingOwnerApplications: StateFlow<List<FirestoreCastingApplication>> = combine(
        castingProfile.flatMapLatest { profile ->
            if (profile == null) flowOf(emptyList())
            else firestoreRepo.observeCastingOwnerApplications(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "castingOwnerApplications")
                    emit(emptyList())
                }
        },
        blockedEntities
    ) { apps, blocked ->
        val blockedIds = blocked.map { it.targetId }.toSet()
        apps.filterNot { blockedIds.contains(it.artistId) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val notifications: StateFlow<List<FirestoreNotification>> = combine(
        currentUser.flatMapLatest { user ->
            if (user == null) flowOf(emptyList())
            else firestoreRepo.observeNotifications(currentUserId)
                .catch { error ->
                    unwrapAndLog(error, "notifications")
                    emit(emptyList())
                }
        },
        prefs.readBroadcastIdsFlow,
        currentUser,
        activeModule,
        artistProfile
    ) { list, readBroadcasts, user, module, artist ->
        val roleName = user?.role ?: "ALL"
        val showArtistBroadcasts = artist != null || module == AppModule.FILM_CONNECT
        list.filter { notif ->
            notif.userId == currentUserId ||
                notif.targetRole == "ALL" ||
                notif.targetRole == roleName ||
                (showArtistBroadcasts && notif.targetRole == "ARTIST")
        }.map { notif ->
            if (notif.userId == "BROADCAST" && readBroadcasts.contains(notif.id)) {
                notif.copy(isRead = true)
            } else {
                notif
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val unreadNotificationCount: StateFlow<Int> = notifications
        .map { list -> list.count { !it.isRead } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), 0)

    // Admin streams (active only when adminModeEnabled && isAdminUser)
    val allUsers: StateFlow<List<FirestoreUser>> = combine(isAdminUser, adminModeEnabled) { admin, active ->
        admin && active
    }.flatMapLatest { enabled ->
        if (!enabled) flowOf(emptyList())
        else firestoreRepo.observeAllUsersAdmin()
            .catch { error ->
                unwrapAndLog(error, "adminUsers")
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val allJobs: StateFlow<List<FirestoreJob>> = combine(isAdminUser, adminModeEnabled) { admin, active ->
        admin && active
    }.flatMapLatest { enabled ->
        if (!enabled) flowOf(emptyList())
        else firestoreRepo.observeAllJobsAdmin()
            .catch { error ->
                unwrapAndLog(error, "adminJobs")
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val allApplications: StateFlow<List<FirestoreApplication>> = combine(isAdminUser, adminModeEnabled) { admin, active ->
        admin && active
    }.flatMapLatest { enabled ->
        if (!enabled) flowOf(emptyList())
        else firestoreRepo.observeAllApplicationsAdmin()
            .catch { error ->
                unwrapAndLog(error, "adminApplications")
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val allCastingProfiles: StateFlow<List<FirestoreCastingProfile>> = combine(isAdminUser, adminModeEnabled) { admin, active ->
        admin && active
    }.flatMapLatest { enabled ->
        if (!enabled) flowOf(emptyList())
        else firestoreRepo.observeAllCastingProfilesAdmin()
            .catch { error ->
                unwrapAndLog(error, "adminCastingProfiles")
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val allCastingPosts: StateFlow<List<FirestoreCastingPost>> = combine(isAdminUser, adminModeEnabled) { admin, active ->
        admin && active
    }.flatMapLatest { enabled ->
        if (!enabled) flowOf(emptyList())
        else firestoreRepo.observeAllCastingPostsAdmin()
            .catch { error ->
                unwrapAndLog(error, "adminCastingPosts")
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val allContentReports: StateFlow<List<FirestoreContentReport>> = combine(isAdminUser, adminModeEnabled) { admin, active ->
        admin && active
    }.flatMapLatest { enabled ->
        if (!enabled) flowOf(emptyList())
        else firestoreRepo.observeAllReportsAdmin()
            .catch { error ->
                unwrapAndLog(error, "adminContentReports")
                emit(emptyList())
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val adminStats: StateFlow<AdminStats> = combine(
        allUsers,
        allJobs,
        allApplications
    ) { users, jobs, apps ->
        val workers = users.count { it.roleEnum() == UserRole.WORKER }
        val employers = users.count { it.roleEnum() == UserRole.EMPLOYER }
        val openJobs = jobs.count { it.statusEnum() == JobStatus.OPEN }
        val avgWage = if (jobs.isEmpty()) 0 else jobs.map { it.dailyWage.toInt() }.average().toInt()
        val lowWage = jobs.count { it.dailyWage < 500L }
        val byCat = jobs.groupBy { it.categoryEnum() }
            .mapValues { (_, list) -> list.map { it.dailyWage.toInt() }.average().toInt() }
        AdminStats(
            totalWorkers = workers,
            totalEmployers = employers,
            openJobs = openJobs,
            totalApplications = apps.size,
            averageDailyWage = avgWage,
            lowWageJobsCount = lowWage,
            avgWageByCategory = byCat
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AdminStats())

    init {
        viewModelScope.launch {
            launch {
                prefs.languageFlow.collect { _language.value = it }
            }
            if (!_isAdminUser.value) {
                _isAdminUser.value = firestoreRepo.isUserInAdminsCollection(currentUserId)
            }
            inspectLocalMigrationData()
        }
    }

    private suspend fun inspectLocalMigrationData() {
        val migratedUid = prefs.migratedUidFlow.first()
        if (migratedUid == currentUserId) return

        val savedLocalUserId = prefs.currentUserIdFlow.first()
        val demoPhones = setOf(
            "9848011111", "9848011112", "9848011113", "9848011114", "9848011115",
            "9848011116", "9848022222", "9848022223", "9848022224", "9000099999"
        )
        val localUsers = runCatching { localDb.userDao().observeAllUsers().first() }.getOrDefault(emptyList())
        val candidateUser = (savedLocalUserId?.let { id -> localUsers.firstOrNull { it.id == id } }
            ?: localUsers.firstOrNull { !demoPhones.contains(it.phone) && it.role != UserRole.ADMIN })
            ?.takeIf { !demoPhones.contains(it.phone) && it.role != UserRole.ADMIN }

        val candidateJobs = if (candidateUser != null && candidateUser.role == UserRole.EMPLOYER) {
            runCatching { localDb.jobDao().observeJobsByEmployer(candidateUser.id).first() }
                .getOrDefault(emptyList())
        } else {
            emptyList()
        }

        if (candidateUser != null || candidateJobs.isNotEmpty()) {
            _localMigrationPreview.value = LocalMigrationPreview(candidateUser, candidateJobs)
        }
    }

    private fun unwrapAndLog(error: Throwable, tag: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        Log.w(TAG, "Stream error in $tag", firestoreError ?: error)
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
        viewModelScope.launch { prefs.setLanguage(lang) }
    }

    fun setLocation(city: String, area: String) {
        val valid = IndianLocations.findActiveLocation(city, area, activeLocations.value)
        val strings = AppStrings.get(language.value)
        if (valid == null) {
            _snackbarMessage.value = strings.comingSoonTitle
            return
        }
        _gpsOutsideAreaLabel.value = null
        _gpsCoordinates.value = null
        viewModelScope.launch { prefs.setLocation(valid.city, valid.area) }
    }

    fun onGpsLocationResult(result: GpsDetectionResult) {
        val strings = AppStrings.get(language.value)
        when (result) {
            is GpsDetectionResult.InsideServiceArea -> {
                _gpsOutsideAreaLabel.value = null
                _gpsCoordinates.value = result.gpsLat to result.gpsLng
                _locationQuery.value = ""
                viewModelScope.launch { prefs.setLocation(result.location.city, result.location.area) }
                _snackbarMessage.value = "${strings.gpsUpdated}: ${result.location.displayName}"
            }
            is GpsDetectionResult.OutsideServiceArea -> {
                _gpsCoordinates.value = null
                _gpsOutsideAreaLabel.value = result.nearestKnownLabel
                _snackbarMessage.value = strings.gpsOutsideServiceArea
            }
            GpsDetectionResult.Unavailable -> {
                _snackbarMessage.value = strings.gpsUnavailable
            }
        }
    }

    fun dismissOutsideAreaNotice() {
        _gpsOutsideAreaLabel.value = null
        _locationQuery.value = ""
    }

    fun setLocationSearchQuery(query: String) { _locationQuery.value = query }
    fun setCategoryFilter(category: WorkCategory?) { _categoryFilter.value = category }
    fun setMinWageFilter(minWage: Int) { _minWageFilter.value = minWage }
    fun setWorkerSearchQuery(query: String) { _workerSearchQuery.value = query }
    fun setWorkerSkillFilter(skill: WorkCategory?) { _workerSkillFilter.value = skill }
    fun clearAuthError() { _authError.value = null }
    fun clearSnackbar() { _snackbarMessage.value = null }
    fun showMessage(message: String) { _snackbarMessage.value = message }

    fun toggleAdminMode(enabled: Boolean) {
        viewModelScope.launch { prefs.setAdminMode(enabled) }
    }

    fun registerProfile(
        name: String,
        phone: String,
        role: UserRole,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int,
        skills: List<WorkCategory> = listOf(skill),
        spokenLanguages: List<String> = emptyList(),
        gender: WorkerGender? = null,
        availabilityStatus: WorkAvailability = WorkAvailability.AVAILABLE_TODAY,
        profilePhotoBase64: String = ""
    ) {
        val strings = AppStrings.get(language.value)
        if (name.isBlank()) {
            _authError.value = strings.enterValidName
            return
        }
        val cleanPhone = IndianMobileValidator.sanitizeInput(phone)
        if (!IndianMobileValidator.isValid(cleanPhone)) {
            _authError.value = "${strings.invalidPhone} (${strings.invalidIndianMobileHint})"
            return
        }
        val pool = activeLocations.value
        val validLoc = IndianLocations.findActiveLocation(city, area, pool)
        if (validLoc == null) {
            _authError.value = strings.jobLocationRequiredError
            return
        }
        val cleanSkills = skills.distinct().ifEmpty { listOf(skill) }
        _authError.value = null
        viewModelScope.launch {
            try {
                val created = firestoreRepo.registerProfile(
                    name = name,
                    phone = cleanPhone,
                    role = role,
                    city = validLoc.city,
                    area = validLoc.area,
                    skill = cleanSkills.first(),
                    experienceYears = experienceYears,
                    expectedDailyWage = expectedDailyWage,
                    skills = cleanSkills,
                    spokenLanguages = spokenLanguages,
                    gender = gender,
                    availabilityStatus = availabilityStatus,
                    profilePhotoBase64 = profilePhotoBase64,
                    activeLocations = pool
                )
                prefs.setLocation(created.city, created.area)

                val migration = _localMigrationPreview.value
                if (role == UserRole.EMPLOYER && migration.localJobs.isNotEmpty()) {
                    firestoreRepo.migrateLocalEmployerJobs(created, migration.localJobs)
                }
                prefs.setMigratedUid(currentUserId)
                _localMigrationPreview.value = LocalMigrationPreview()
                _snackbarMessage.value = strings.profileSaved
            } catch (e: Exception) {
                _authError.value = e.localizedMessage ?: "Failed to save profile"
            }
        }
    }

    fun toggleAvailability() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            runCatching { firestoreRepo.toggleWorkerAvailability(user) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun updateProfile(
        name: String,
        phone: String,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int,
        skills: List<WorkCategory> = listOf(skill),
        spokenLanguages: List<String> = emptyList(),
        gender: WorkerGender? = null,
        availabilityStatus: WorkAvailability = WorkAvailability.AVAILABLE_TODAY,
        profilePhotoBase64: String = ""
    ) {
        val user = currentUser.value ?: return
        val strings = AppStrings.get(language.value)
        if (name.isBlank()) {
            _snackbarMessage.value = strings.enterValidName
            return
        }
        val cleanPhone = IndianMobileValidator.sanitizeInput(phone)
        if (!IndianMobileValidator.isValid(cleanPhone)) {
            _snackbarMessage.value = "${strings.invalidPhone} (${strings.invalidIndianMobileHint})"
            return
        }
        val pool = activeLocations.value
        val validLoc = IndianLocations.findActiveLocation(city, area, pool)
        if (validLoc == null) {
            _snackbarMessage.value = strings.jobLocationRequiredError
            return
        }
        val cleanSkills = skills.distinct().ifEmpty { listOf(skill) }
        viewModelScope.launch {
            try {
                firestoreRepo.updateProfile(
                    existing = user,
                    name = name,
                    phone = cleanPhone,
                    city = validLoc.city,
                    area = validLoc.area,
                    skill = cleanSkills.first(),
                    experienceYears = experienceYears,
                    expectedDailyWage = expectedDailyWage,
                    isAvailable = availabilityStatus.isAvailableToday,
                    skills = cleanSkills,
                    spokenLanguages = spokenLanguages,
                    gender = gender,
                    availabilityStatus = availabilityStatus,
                    profilePhotoBase64 = profilePhotoBase64,
                    activeLocations = pool
                )
                prefs.setLocation(validLoc.city, validLoc.area)
                _snackbarMessage.value = strings.profileSaved
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to update profile"
            }
        }
    }

    fun applyForJob(job: FirestoreJob, note: String) {
        val worker = currentUser.value ?: return
        val strings = AppStrings.get(language.value)
        viewModelScope.launch {
            try {
                val ok = firestoreRepo.applyForJob(worker, job, note)
                if (ok) {
                    _snackbarMessage.value = strings.appliedSuccess
                    LocalNotificationHelper.showNotification(
                        appContext,
                        strings.appliedLabel,
                        "${job.title} • ₹${job.dailyWage}${strings.perDay}"
                    )
                }
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to apply"
            }
        }
    }

    fun postJob(
        title: String,
        category: WorkCategory,
        description: String,
        city: String,
        area: String,
        dailyWage: Int,
        workersNeeded: Int,
        durationDays: Int,
        shiftTiming: String,
        includesMeals: Boolean
    ) {
        val employer = currentUser.value ?: return
        val strings = AppStrings.get(language.value)
        val pool = activeLocations.value
        val validLoc = IndianLocations.findActiveLocation(city, area, pool)
        if (validLoc == null) {
            _snackbarMessage.value = strings.jobLocationRequiredError
            return
        }
        val effectiveTitle = title.ifBlank { "${strings.categoryName(category)} Work" }
        viewModelScope.launch {
            try {
                firestoreRepo.postJob(
                    employer = employer,
                    title = effectiveTitle,
                    category = category,
                    description = description.ifBlank { "$effectiveTitle in ${validLoc.area}, ${validLoc.city}. Daily payment." },
                    city = validLoc.city,
                    area = validLoc.area,
                    dailyWage = dailyWage,
                    workersNeeded = workersNeeded,
                    durationDays = durationDays,
                    shiftTiming = shiftTiming,
                    includesMeals = includesMeals,
                    activeLocations = pool
                )
                _snackbarMessage.value = strings.jobPostedSuccess
                LocalNotificationHelper.showNotification(
                    appContext,
                    effectiveTitle,
                    "${validLoc.area}, ${validLoc.city} • ₹$dailyWage${strings.perDay}"
                )
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to post job"
            }
        }
    }

    fun updateJobStatus(job: FirestoreJob, status: JobStatus) {
        viewModelScope.launch {
            runCatching { firestoreRepo.updateJobStatus(job, status) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun deleteJob(job: FirestoreJob) {
        viewModelScope.launch {
            runCatching { firestoreRepo.deleteJob(job.id) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun updateApplicationStatus(application: FirestoreApplication, status: ApplicationStatus) {
        viewModelScope.launch {
            try {
                firestoreRepo.updateApplicationStatus(application, status)
                if (status == ApplicationStatus.ACCEPTED) {
                    LocalNotificationHelper.showNotification(
                        appContext,
                        "Worker Hired: ${application.workerName}",
                        "${application.jobTitle} • ${application.workerPhone}"
                    )
                }
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to update application"
            }
        }
    }

    fun markNotificationRead(notification: FirestoreNotification) {
        viewModelScope.launch {
            if (notification.userId == "BROADCAST") {
                prefs.markBroadcastRead(notification.id)
            } else {
                runCatching { firestoreRepo.markNotificationRead(notification.id) }
            }
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            val list = notifications.value
            val broadcastIds = list.filter { it.userId == "BROADCAST" && !it.isRead }.map { it.id }
            if (broadcastIds.isNotEmpty()) {
                prefs.markBroadcastsRead(broadcastIds)
            }
            list.filter { it.userId == currentUserId && !it.isRead }.forEach { notif ->
                runCatching { firestoreRepo.markNotificationRead(notif.id) }
            }
        }
    }

    fun toggleVerifyUser(user: FirestoreUser) {
        viewModelScope.launch {
            runCatching { firestoreRepo.toggleVerifyUser(user) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun toggleSuspendUser(user: FirestoreUser) {
        viewModelScope.launch {
            runCatching { firestoreRepo.toggleSuspendUser(user) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun sendAdminBroadcast(title: String, message: String, targetRole: String) {
        if (title.isBlank() || message.isBlank()) return
        viewModelScope.launch {
            try {
                firestoreRepo.sendAdminBroadcast(title, message, targetRole)
                _snackbarMessage.value = "Announcement sent!"
                LocalNotificationHelper.showNotification(appContext, title, message)
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to send announcement"
            }
        }
    }

    fun toggleServiceAreaCity(cityName: String, enable: Boolean) {
        val strings = AppStrings.get(language.value)
        viewModelScope.launch {
            try {
                firestoreRepo.toggleServiceAreaCity(serviceAreasConfig.value, cityName, enable)
                _snackbarMessage.value = strings.serviceAreaUpdatedMsg
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to update service areas"
            }
        }
    }

    fun addCustomServiceArea(cityName: String, state: String, localityName: String) {
        val strings = AppStrings.get(language.value)
        viewModelScope.launch {
            try {
                firestoreRepo.addCustomServiceArea(
                    current = serviceAreasConfig.value,
                    cityName = cityName,
                    state = state,
                    localityName = localityName
                )
                _snackbarMessage.value = strings.serviceAreaUpdatedMsg
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to add service area"
            }
        }
    }

    // =====================================================================
    // MODULE 2: FILM DIRECT CONNECT ACTIONS
    // =====================================================================

    fun setActiveModule(module: AppModule) {
        viewModelScope.launch { prefs.setSelectedModule(module) }
    }

    fun setFilmSubRole(subRole: FilmSubRole) {
        viewModelScope.launch { prefs.setFilmSubRole(subRole) }
    }

    fun setCastingCityFilter(city: String) { _castingCityFilter.value = city }
    fun setCastingDateFilter(date: String) { _castingDateFilter.value = date }
    fun setCastingRoleQuery(query: String) { _castingRoleQuery.value = query }

    fun saveArtistProfile(
        name: String,
        age: Int,
        gender: WorkerGender?,
        city: String,
        area: String,
        phone: String,
        languages: List<String>,
        experienceYears: Int,
        skills: List<ArtistSkill>,
        bio: String,
        photosBase64: List<String>,
        noBrokerConfirmed: Boolean,
        zeroFeeAcknowledged: Boolean
    ) {
        val strings = AppStrings.get(language.value)
        val filmStrings = FilmStrings.get(language.value)
        if (name.isBlank()) {
            _snackbarMessage.value = strings.enterValidName
            return
        }
        val cleanPhone = IndianMobileValidator.sanitizeInput(phone)
        if (!IndianMobileValidator.isValid(cleanPhone)) {
            _snackbarMessage.value = "${strings.invalidPhone} (${strings.invalidIndianMobileHint})"
            return
        }
        if (age !in 1..100) {
            _snackbarMessage.value = filmStrings.invalidAgeErrorMsg
            return
        }
        if (!noBrokerConfirmed || !zeroFeeAcknowledged) {
            _snackbarMessage.value = filmStrings.noBrokerErrorMsg
            return
        }
        val pool = activeLocations.value
        val validLoc = IndianLocations.findActiveLocation(city, area, pool)
        if (validLoc == null) {
            _snackbarMessage.value = strings.jobLocationRequiredError
            return
        }
        viewModelScope.launch {
            try {
                firestoreRepo.saveArtistProfile(
                    existing = artistProfile.value,
                    name = name,
                    age = age,
                    gender = gender,
                    city = validLoc.city,
                    area = validLoc.area,
                    phone = cleanPhone,
                    languages = languages,
                    experienceYears = experienceYears,
                    skills = skills,
                    bio = bio,
                    photosBase64 = photosBase64,
                    noBrokerConfirmed = noBrokerConfirmed,
                    zeroFeeAcknowledged = zeroFeeAcknowledged,
                    activeLocations = pool
                )
                _snackbarMessage.value = filmStrings.artistProfileSavedMsg
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to save artist profile"
            }
        }
    }

    fun submitCastingVerification(
        accountType: CastingAccountType,
        organizationName: String,
        contactName: String,
        phone: String,
        city: String,
        area: String,
        projectCredits: String,
        idProofType: String,
        idReferenceMasked: String,
        verificationNotes: String,
        noBrokerConfirmed: Boolean,
        zeroFeeConfirmed: Boolean
    ) {
        val strings = AppStrings.get(language.value)
        val filmStrings = FilmStrings.get(language.value)
        if (organizationName.trim().length < 2 || contactName.trim().length < 2) {
            _snackbarMessage.value = strings.enterValidName
            return
        }
        val cleanPhone = IndianMobileValidator.sanitizeInput(phone)
        if (!IndianMobileValidator.isValid(cleanPhone)) {
            _snackbarMessage.value = "${strings.invalidPhone} (${strings.invalidIndianMobileHint})"
            return
        }
        if (!noBrokerConfirmed || !zeroFeeConfirmed) {
            _snackbarMessage.value = filmStrings.noBrokerErrorMsg
            return
        }
        val pool = activeLocations.value
        val validLoc = IndianLocations.findActiveLocation(city, area, pool)
        if (validLoc == null) {
            _snackbarMessage.value = strings.jobLocationRequiredError
            return
        }
        viewModelScope.launch {
            try {
                firestoreRepo.submitCastingVerification(
                    existing = castingProfile.value,
                    accountType = accountType,
                    organizationName = organizationName,
                    contactName = contactName,
                    phone = cleanPhone,
                    city = validLoc.city,
                    area = validLoc.area,
                    projectCredits = projectCredits,
                    idProofType = idProofType,
                    idReferenceMasked = idReferenceMasked,
                    verificationNotes = verificationNotes,
                    noBrokerConfirmed = noBrokerConfirmed,
                    zeroFeeConfirmed = zeroFeeConfirmed,
                    activeLocations = pool
                )
                _snackbarMessage.value = filmStrings.castingSubmittedMsg
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to submit verification"
            }
        }
    }

    fun postCastingRequirement(
        projectName: String,
        roleTitle: String,
        artistsNeeded: Int,
        minAge: Int,
        maxAge: Int,
        genderPreference: GenderPreference,
        languages: List<String>,
        shootingDate: String,
        reportingTime: String,
        city: String,
        area: String,
        paymentAmount: Int,
        paymentUnit: PaymentUnit,
        description: String,
        noBrokerConfirmed: Boolean,
        zeroFeeConfirmed: Boolean
    ) {
        val profile = castingProfile.value ?: return
        val strings = AppStrings.get(language.value)
        val filmStrings = FilmStrings.get(language.value)
        if (!noBrokerConfirmed || !zeroFeeConfirmed) {
            _snackbarMessage.value = filmStrings.noBrokerErrorMsg
            return
        }
        if (minAge < 1 || maxAge < minAge || maxAge > 100) {
            _snackbarMessage.value = filmStrings.invalidAgeErrorMsg
            return
        }
        val pool = activeLocations.value
        val validLoc = IndianLocations.findActiveLocation(city, area, pool)
        if (validLoc == null) {
            _snackbarMessage.value = strings.jobLocationRequiredError
            return
        }
        viewModelScope.launch {
            try {
                firestoreRepo.postCastingRequirement(
                    castingProfile = profile,
                    projectName = projectName,
                    roleTitle = roleTitle,
                    artistsNeeded = artistsNeeded,
                    minAge = minAge,
                    maxAge = maxAge,
                    genderPreference = genderPreference,
                    languages = languages,
                    shootingDate = shootingDate,
                    reportingTime = reportingTime,
                    city = validLoc.city,
                    area = validLoc.area,
                    paymentAmount = paymentAmount,
                    paymentUnit = paymentUnit,
                    description = description,
                    noBrokerConfirmed = noBrokerConfirmed,
                    zeroFeeConfirmed = zeroFeeConfirmed,
                    activeLocations = pool
                )
                _snackbarMessage.value = filmStrings.castingPostPublishedMsg
                LocalNotificationHelper.showNotification(
                    appContext,
                    "${roleTitle.trim()} (${projectName.trim()})",
                    "${validLoc.area}, ${validLoc.city} • ₹$paymentAmount"
                )
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to publish casting post"
            }
        }
    }

    fun updateCastingPostStatus(post: FirestoreCastingPost, status: JobStatus) {
        viewModelScope.launch {
            runCatching { firestoreRepo.updateCastingPostStatus(post, status) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun deleteCastingPost(post: FirestoreCastingPost) {
        viewModelScope.launch {
            runCatching { firestoreRepo.deleteCastingPost(post.id) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun applyToCastingPost(post: FirestoreCastingPost, note: String) {
        val artist = artistProfile.value
        val filmStrings = FilmStrings.get(language.value)
        if (artist == null) {
            _snackbarMessage.value = filmStrings.createArtistFirstMsg
            return
        }
        viewModelScope.launch {
            try {
                val ok = firestoreRepo.applyToCastingPost(artist, post, note)
                if (ok) {
                    _snackbarMessage.value = filmStrings.artistAppliedSuccessMsg
                    LocalNotificationHelper.showNotification(
                        appContext,
                        post.roleTitle,
                        "${post.projectName} • ${post.shootingDate}"
                    )
                }
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to apply for casting"
            }
        }
    }

    fun updateCastingApplicationStatus(
        application: FirestoreCastingApplication,
        newStatus: CastingApplicationStatus
    ) {
        viewModelScope.launch {
            try {
                firestoreRepo.updateCastingApplicationStatus(application, newStatus)
                if (newStatus == CastingApplicationStatus.SELECTED) {
                    LocalNotificationHelper.showNotification(
                        appContext,
                        "Selected: ${application.artistName}",
                        "${application.roleTitle} • ${application.shootingDate}"
                    )
                }
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to update applicant status"
            }
        }
    }

    fun submitContentReport(
        targetId: String,
        targetType: ReportTargetType,
        targetOwnerId: String,
        targetLabel: String,
        reason: ReportReason,
        details: String
    ) {
        val filmStrings = FilmStrings.get(language.value)
        val reporterName = artistProfile.value?.name
            ?: castingProfile.value?.contactName
            ?: currentUser.value?.name
            ?: "Member"
        viewModelScope.launch {
            try {
                firestoreRepo.submitContentReport(
                    reporterName = reporterName,
                    targetId = targetId,
                    targetType = targetType,
                    targetOwnerId = targetOwnerId,
                    targetLabel = targetLabel,
                    reason = reason,
                    details = details
                )
                _snackbarMessage.value = filmStrings.reportSubmittedMsg
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to submit report"
            }
        }
    }

    fun blockEntity(targetId: String, targetType: ReportTargetType, targetLabel: String) {
        val filmStrings = FilmStrings.get(language.value)
        viewModelScope.launch {
            try {
                firestoreRepo.blockEntity(targetId, targetType, targetLabel)
                _snackbarMessage.value = filmStrings.blockedSuccessMsg
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to block"
            }
        }
    }

    fun unblockEntity(targetId: String) {
        viewModelScope.launch {
            runCatching { firestoreRepo.unblockEntity(targetId) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminVerifyCastingProfile(
        profile: FirestoreCastingProfile,
        approve: Boolean,
        rejectionReason: String = ""
    ) {
        viewModelScope.launch {
            try {
                firestoreRepo.adminVerifyCastingProfile(profile, approve, rejectionReason)
                _snackbarMessage.value = if (approve) {
                    "Verified ${profile.organizationName}"
                } else {
                    "Rejected ${profile.organizationName}"
                }
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to verify casting account"
            }
        }
    }

    fun adminToggleSuspendCastingProfile(profile: FirestoreCastingProfile) {
        viewModelScope.launch {
            runCatching { firestoreRepo.adminToggleSuspendCastingProfile(profile) }
                .onFailure { _snackbarMessage.value = it.localizedMessage }
        }
    }

    fun adminResolveReport(
        report: FirestoreContentReport,
        newStatus: ReportStatus,
        actionNote: String,
        removeReportedPost: Boolean = false,
        suspendReportedOwner: Boolean = false
    ) {
        viewModelScope.launch {
            try {
                firestoreRepo.adminResolveReport(
                    report = report,
                    newStatus = newStatus,
                    actionNote = actionNote,
                    removeReportedPost = removeReportedPost,
                    suspendReportedOwner = suspendReportedOwner
                )
                _snackbarMessage.value = "Report updated"
            } catch (e: Exception) {
                _snackbarMessage.value = e.localizedMessage ?: "Failed to update report"
            }
        }
    }

    private companion object {
        const val TAG = "DailyWorkVM"
        const val STOP_TIMEOUT_MS = 5000L
    }
}
