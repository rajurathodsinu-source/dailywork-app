package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ApplicationStatus
import com.example.data.FirestoreApplication
import com.example.data.FirestoreJob
import com.example.data.FirestoreUser
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.JobStatus
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.data.WorkerGender
import com.example.i18n.LocalizedStrings
import com.example.ui.components.ApplicationStatusPill
import com.example.ui.components.BigActionButton
import com.example.ui.components.CityAreaPicker
import com.example.ui.components.JobStatusPill
import com.example.ui.components.MealsBadge
import com.example.ui.components.ProfileAvatar
import com.example.ui.components.SkillSelectorGrid
import com.example.ui.components.VerifiedChip
import com.example.ui.components.WageBadge
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealSecondary
import com.example.util.ContactHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployerHomeScreen(
    employer: FirestoreUser,
    postedJobs: List<FirestoreJob>,
    applicationsCount: Int,
    strings: LocalizedStrings,
    onPostJob: (
        title: String,
        category: WorkCategory,
        description: String,
        city: String,
        area: String,
        dailyWage: Int,
        workersNeeded: Int,
        durationDays: Int,
        shiftTiming: String,
        includesMeals: Boolean
    ) -> Unit,
    onToggleJobStatus: (FirestoreJob, JobStatus) -> Unit,
    onDeleteJob: (FirestoreJob) -> Unit,
    modifier: Modifier = Modifier,
    activeLocations: List<IndianLocation> = IndianLocations.launchPresets
) {
    var showPostSheet by remember { mutableStateOf(false) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().height(130.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img_employer_hero),
                            contentDescription = employer.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Black.copy(alpha = 0.1f), Color.Black.copy(alpha = 0.72f))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)
                        ) {
                            Text(
                                text = employer.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${employer.area}, ${employer.city} • ${postedJobs.size} ${strings.navJobs} • $applicationsCount ${strings.navApplicants}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }

            item {
                BigActionButton(
                    text = strings.postNewJob,
                    icon = Icons.Filled.AddCircle,
                    containerColor = SaffronPrimary,
                    onClick = { showPostSheet = true },
                    modifier = Modifier.testTag("open_post_job_btn")
                )
            }

            item {
                Text(
                    text = strings.yourPostedJobs,
                    style = MaterialTheme.typography.headlineSmall
                )
            }

            items(postedJobs, key = { it.id }) { job ->
                val status = job.statusEnum()
                val category = job.categoryEnum()
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = job.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${strings.categoryName(category)} • ${job.area}, ${job.city}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            JobStatusPill(status = status, strings = strings)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WageBadge(wage = job.dailyWage.toInt(), perDayText = strings.perDay)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (job.includesMeals) MealsBadge(strings.mealsIncluded)
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "${job.workersNeeded} ${strings.navWorkers}",
                                        style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val next = if (status == JobStatus.OPEN) JobStatus.CLOSED else JobStatus.OPEN
                                    onToggleJobStatus(job, next)
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = if (status == JobStatus.OPEN) strings.closeJob else strings.reopenJob
                                )
                            }
                            TextButton(
                                onClick = { onDeleteJob(job) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = strings.deleteJob, tint = CrimsonError)
                                Spacer(Modifier.width(4.dp))
                                Text(strings.deleteJob, color = CrimsonError)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPostSheet) {
        val defaultJobLoc = remember(employer.city, employer.area, activeLocations) {
            IndianLocations.findActiveLocation(employer.city, employer.area, activeLocations)
        }
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var category by remember { mutableStateOf(WorkCategory.MASON) }
        var city by remember { mutableStateOf(defaultJobLoc?.city ?: "") }
        var area by remember { mutableStateOf(defaultJobLoc?.area ?: "") }
        var dailyWage by remember { mutableIntStateOf(850) }
        var workersNeeded by remember { mutableIntStateOf(2) }
        var durationDays by remember { mutableIntStateOf(3) }
        var includesMeals by remember { mutableStateOf(true) }
        var locationError by remember { mutableStateOf<String?>(null) }

        ModalBottomSheet(onDismissRequest = { showPostSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = strings.postNewJob,
                    style = MaterialTheme.typography.headlineSmall
                )

                Text(text = strings.selectSkill, style = MaterialTheme.typography.labelLarge)
                SkillSelectorGrid(
                    selectedSkill = category,
                    onSkillSelected = {
                        category = it
                        dailyWage = it.defaultDailyWage
                    },
                    strings = strings
                )

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(strings.jobTitleLabel) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("post_job_title_input")
                )

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text(strings.jobDescLabel) },
                    maxLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                CityAreaPicker(
                    selectedCity = city,
                    selectedArea = area,
                    onLocationSelected = { c, a ->
                        city = c
                        area = a
                        locationError = null
                    },
                    strings = strings,
                    activeLocations = activeLocations
                )

                Text(
                    text = "${strings.selectedServiceAreaLabel}: " +
                        if (city.isNotBlank() && area.isNotBlank()) "$area, $city" else "-",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("post_job_selected_location")
                )

                if (locationError != null) {
                    Surface(
                        color = CrimsonContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("post_job_location_error")
                    ) {
                        Text(
                            text = locationError!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = CrimsonError,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // Daily Wage Stepper + Presets
                Text(
                    text = "${strings.dailyWageLabel}: ₹$dailyWage",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { if (dailyWage > 400) dailyWage -= 50 },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = "Decrease wage")
                        Text("₹50")
                    }
                    Surface(
                        modifier = Modifier.weight(1f),
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "₹$dailyWage ${strings.perDay}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                    OutlinedButton(
                        onClick = { dailyWage += 50 },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Increase wage")
                        Text("₹50")
                    }
                }

                // Workers Needed & Duration Steppers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StepperBox(
                        label = strings.workersNeededLabel,
                        value = workersNeeded,
                        onDecrease = { if (workersNeeded > 1) workersNeeded-- },
                        onIncrease = { workersNeeded++ },
                        modifier = Modifier.weight(1f)
                    )
                    StepperBox(
                        label = strings.durationLabel,
                        value = durationDays,
                        onDecrease = { if (durationDays > 1) durationDays-- },
                        onIncrease = { durationDays++ },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.mealsIncluded, style = MaterialTheme.typography.titleMedium)
                    Switch(checked = includesMeals, onCheckedChange = { includesMeals = it })
                }

                BigActionButton(
                    text = strings.publishJobButton,
                    icon = Icons.Filled.Check,
                    onClick = {
                        val valid = IndianLocations.findActiveLocation(city, area, activeLocations)
                        if (valid == null) {
                            locationError = strings.jobLocationRequiredError
                            return@BigActionButton
                        }
                        onPostJob(
                            title,
                            category,
                            desc,
                            valid.city,
                            valid.area,
                            dailyWage,
                            workersNeeded,
                            durationDays,
                            "8:30 AM - 5:30 PM",
                            includesMeals
                        )
                        showPostSheet = false
                    },
                    modifier = Modifier.testTag("publish_job_submit_btn")
                )
                Spacer(Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun StepperBox(
    label: String,
    value: Int,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDecrease, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Filled.Remove, contentDescription = "Decrease")
                }
                Text(
                    text = value.toString(),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onIncrease, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Filled.Add, contentDescription = "Increase")
                }
            }
        }
    }
}

@Composable
fun EmployerWorkersScreen(
    workers: List<FirestoreUser>,
    searchQuery: String,
    skillFilter: WorkCategory?,
    strings: LocalizedStrings,
    onSearchQueryChange: (String) -> Unit,
    onSkillFilterChange: (WorkCategory?) -> Unit,
    modifier: Modifier = Modifier,
    onShowMessage: (String) -> Unit = {}
) {
    val context = LocalContext.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = strings.navWorkers,
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text(strings.searchLocationHint) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().testTag("worker_directory_search")
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = skillFilter == null,
                        onClick = { onSkillFilterChange(null) },
                        label = { Text(strings.allCategories) },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    )
                    WorkCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = skillFilter == cat,
                            onClick = { onSkillFilterChange(if (skillFilter == cat) null else cat) },
                            label = { Text(strings.categoryName(cat)) },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        )
                    }
                }
            }

            if (workers.isEmpty()) {
                item {
                    Text(
                        text = strings.noWorkersFound,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(workers, key = { it.id.ifBlank { it.uid } }) { worker ->
                    val allSkills = worker.skillsEnumList()
                    val skillsLabel = allSkills.joinToString(", ") { strings.categoryName(it) }
                    val genderLabel = when (worker.genderEnum()) {
                        WorkerGender.MALE -> strings.genderMale
                        WorkerGender.FEMALE -> strings.genderFemale
                        WorkerGender.OTHER -> strings.genderOther
                        null -> null
                    }
                    val spoken = worker.spokenLanguagesList()
                    val availLabel = when (worker.availabilityEnum()) {
                        WorkAvailability.AVAILABLE_TODAY -> strings.availableToday
                        WorkAvailability.AVAILABLE_THIS_WEEK -> strings.availThisWeek
                        WorkAvailability.NOT_AVAILABLE -> strings.notAvailable
                    }
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProfileAvatar(
                                    photoBase64 = worker.profilePhotoBase64,
                                    name = worker.name,
                                    size = 52.dp
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = worker.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "$skillsLabel • ${worker.experienceYears} ${strings.yearsExpShort}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                VerifiedChip(verified = worker.isVerified, strings = strings)
                            }

                            if (spoken.isNotEmpty() || genderLabel != null) {
                                val metaParts = buildList {
                                    if (genderLabel != null) add(genderLabel)
                                    if (spoken.isNotEmpty()) add("${strings.spokenLanguagesLabel}: ${spoken.joinToString(", ")}")
                                }
                                Text(
                                    text = metaParts.joinToString(" • "),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("${worker.area}, ${worker.city}", style = MaterialTheme.typography.bodyMedium)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(2.dp))
                                    Text("${worker.rating} (${worker.completedJobs})", style = MaterialTheme.typography.labelLarge)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                WageBadge(wage = worker.expectedDailyWage.toInt(), perDayText = strings.perDay)
                                Surface(
                                    color = if (worker.isAvailable) EmeraldContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = availLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (worker.isAvailable) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    if (!ContactHelper.dialPhone(context, worker.phone)) {
                                        onShowMessage("Phone app unavailable: ${worker.phone}")
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = TealSecondary)
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("${strings.callWorker} (${worker.phone})", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmployerApplicationsScreen(
    applications: List<FirestoreApplication>,
    strings: LocalizedStrings,
    onUpdateApplicationStatus: (FirestoreApplication, ApplicationStatus) -> Unit,
    modifier: Modifier = Modifier,
    onShowMessage: (String) -> Unit = {}
) {
    val context = LocalContext.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            Text(
                text = strings.navApplicants,
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )

            if (applications.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.noApplicationsYet,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(applications, key = { it.id }) { app ->
                        val jobTitle = app.jobTitle.ifBlank { strings.categoryName(app.skillEnum()) }
                        val status = app.statusEnum()
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = app.workerName,
                                            style = MaterialTheme.typography.titleLarge
                                        )
                                        Text(
                                            text = "$jobTitle • ${app.workerArea}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    ApplicationStatusPill(status = status, strings = strings)
                                }

                                if (app.note.isNotBlank()) {
                                    Text(
                                        text = app.note,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = {
                                            if (!ContactHelper.dialPhone(context, app.workerPhone)) {
                                                onShowMessage("Phone app unavailable: ${app.workerPhone}")
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(48.dp),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.callWorker, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }

                                    if (status == ApplicationStatus.PENDING) {
                                        Button(
                                            onClick = {
                                                onUpdateApplicationStatus(app, ApplicationStatus.ACCEPTED)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                            modifier = Modifier.weight(1f).height(48.dp).testTag("accept_app_${app.id}"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(strings.accept, maxLines = 1)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                onUpdateApplicationStatus(app, ApplicationStatus.REJECTED)
                                            },
                                            border = BorderStroke(1.dp, CrimsonError),
                                            modifier = Modifier.weight(1f).height(48.dp).testTag("decline_app_${app.id}"),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Filled.Close, contentDescription = null, tint = CrimsonError, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(strings.decline, color = CrimsonError, maxLines = 1)
                                        }
                                    } else if (status == ApplicationStatus.ACCEPTED) {
                                        Button(
                                            onClick = {
                                                onUpdateApplicationStatus(app, ApplicationStatus.COMPLETED)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = TealSecondary),
                                            modifier = Modifier.weight(1f).height(48.dp),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(Icons.Filled.DoneAll, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(strings.markCompleted, maxLines = 1)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
