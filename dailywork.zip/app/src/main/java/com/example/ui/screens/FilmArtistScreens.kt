package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ArtistSkill
import com.example.data.CastingApplicationStatus
import com.example.data.FirestoreArtistProfile
import com.example.data.FirestoreBlockedEntity
import com.example.data.FirestoreCastingApplication
import com.example.data.FirestoreCastingPost
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.IndianMobileValidator
import com.example.data.ReportReason
import com.example.data.ReportTargetType
import com.example.data.WorkerGender
import com.example.i18n.FilmLocalizedStrings
import com.example.i18n.LocalizedStrings
import com.example.ui.components.BigActionButton
import com.example.ui.components.CityAreaPicker
import com.example.ui.components.GenderSelector
import com.example.ui.components.ListenButton
import com.example.ui.components.SpokenLanguagesSelector
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.OnAmberContainer
import com.example.ui.theme.SaffronContainer
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronPrimaryDark
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealSecondary
import com.example.util.ProfilePhotoHelper

data class PendingReportTarget(
    val targetId: String,
    val targetType: ReportTargetType,
    val targetOwnerId: String,
    val targetLabel: String
)

@Composable
fun FilmSafetyReportDialog(
    target: PendingReportTarget,
    filmStrings: FilmLocalizedStrings,
    onDismiss: () -> Unit,
    onSubmit: (ReportReason, String) -> Unit
) {
    var selectedReason by remember { mutableStateOf(ReportReason.BROKER_OR_AGENT) }
    var details by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(filmStrings.reportDialogTitle, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = target.targetLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(filmStrings.reportReasonLabel, style = MaterialTheme.typography.labelMedium)
                ReportReason.entries.forEach { reason ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = selectedReason == reason,
                            onClick = { selectedReason = reason },
                            label = { Text(filmStrings.reportReasonLabel(reason)) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("report_reason_${reason.name}")
                        )
                    }
                }
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text(filmStrings.reportDetailsHint) },
                    maxLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("report_details_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(selectedReason, details) },
                modifier = Modifier.testTag("confirm_submit_report_btn")
            ) {
                Text(filmStrings.submitReportButton)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilmShootingCallsScreen(
    artistProfile: FirestoreArtistProfile?,
    posts: List<FirestoreCastingPost>,
    myApplications: List<FirestoreCastingApplication>,
    cityFilter: String,
    dateFilter: String,
    roleQuery: String,
    activeCities: List<String>,
    strings: LocalizedStrings,
    filmStrings: FilmLocalizedStrings,
    onCityFilterChange: (String) -> Unit,
    onDateFilterChange: (String) -> Unit,
    onRoleQueryChange: (String) -> Unit,
    onOpenArtistProfileTab: () -> Unit,
    onApplyPost: (FirestoreCastingPost, String) -> Unit,
    onSubmitReport: (PendingReportTarget, ReportReason, String) -> Unit,
    onBlockEntity: (String, ReportTargetType, String) -> Unit,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val myAppStatusMap = remember(myApplications) {
        myApplications.associate { it.postId to it.statusEnum() }
    }
    var pendingApplyPost by remember { mutableStateOf<FirestoreCastingPost?>(null) }
    var applyNote by remember { mutableStateOf("") }
    var pendingReport by remember { mutableStateOf<PendingReportTarget?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .testTag("film_shooting_calls_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Hero Banner
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkBackground),
                    border = BorderStroke(1.5.dp, SaffronPrimary.copy(alpha = 0.7f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(132.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_film_connect_hero),
                                contentDescription = filmStrings.filmConnectTitle,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(Color.Transparent, DarkBackground.copy(alpha = 0.92f))
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(14.dp)
                            ) {
                                Text(
                                    text = filmStrings.filmConnectTitle,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = filmStrings.filmConnectTagline,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SaffronPrimaryDark
                                )
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ListenButton(
                                label = strings.listen,
                                onClick = {
                                    onSpeak("${filmStrings.filmConnectTitle}. ${filmStrings.filmConnectTagline}. ${filmStrings.noGuaranteeNotice}")
                                }
                            )
                            if (artistProfile == null) {
                                Button(
                                    onClick = onOpenArtistProfileTab,
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("go_create_artist_btn")
                                ) {
                                    Text(filmStrings.navArtistProfile, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Safety Rules Banner
            item {
                Surface(
                    color = AmberContainer,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.2.dp, AmberTertiary.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("film_safety_banner")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.Security, contentDescription = null, tint = OnAmberContainer)
                            Text(
                                text = filmStrings.safetyBannerTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = OnAmberContainer,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Text(
                            text = filmStrings.safetyBannerPoints,
                            style = MaterialTheme.typography.bodySmall,
                            color = OnAmberContainer
                        )
                    }
                }
            }

            // Search by Role, Shooting Date, and City
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = roleQuery,
                            onValueChange = onRoleQueryChange,
                            placeholder = { Text(filmStrings.searchRoleHint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            trailingIcon = {
                                if (roleQuery.isNotBlank()) {
                                    IconButton(onClick = { onRoleQueryChange("") }) {
                                        Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("casting_search_role_input")
                        )
                        OutlinedTextField(
                            value = dateFilter,
                            onValueChange = onDateFilterChange,
                            placeholder = { Text(filmStrings.searchDateHint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingIcon = { Icon(Icons.Filled.CalendarMonth, contentDescription = null) },
                            trailingIcon = {
                                if (dateFilter.isNotBlank()) {
                                    IconButton(onClick = { onDateFilterChange("") }) {
                                        Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("casting_search_date_input")
                        )
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = cityFilter.isBlank(),
                                onClick = { onCityFilterChange("") },
                                label = { Text(filmStrings.allCitiesFilter) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SaffronPrimary,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("casting_city_filter_ALL")
                            )
                            activeCities.forEach { city ->
                                FilterChip(
                                    selected = cityFilter.equals(city, ignoreCase = true),
                                    onClick = { onCityFilterChange(city) },
                                    label = { Text(city) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SaffronPrimary,
                                        selectedLabelColor = Color.White
                                    ),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("casting_city_filter_$city")
                                )
                            }
                        }
                    }
                }
            }

            if (posts.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                Icons.Filled.Movie,
                                contentDescription = null,
                                tint = SaffronPrimary,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = filmStrings.noCastingPostsFound,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            } else {
                items(posts, key = { it.id }) { post ->
                    val appStatus = myAppStatusMap[post.id]
                    val unitLabel = filmStrings.paymentUnitLabel(post.paymentUnitEnum())
                    val typeLabel = filmStrings.accountTypeName(post.accountTypeEnum())
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.2.dp, SaffronPrimary.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("casting_post_card_${post.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(color = TealContainer, shape = RoundedCornerShape(50)) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Filled.Verified, contentDescription = null, tint = TealSecondary, modifier = Modifier.size(14.dp))
                                        Text(
                                            text = "$typeLabel • ${filmStrings.verifiedOrganizerBadge}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TealSecondary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            pendingReport = PendingReportTarget(
                                                targetId = post.id,
                                                targetType = ReportTargetType.CASTING_POST,
                                                targetOwnerId = post.posterId,
                                                targetLabel = "${post.roleTitle} (${post.organizationName})"
                                            )
                                        },
                                        modifier = Modifier.testTag("report_casting_btn_${post.id}")
                                    ) {
                                        Icon(Icons.Filled.Flag, contentDescription = filmStrings.reportButton, tint = CrimsonError)
                                    }
                                    IconButton(
                                        onClick = {
                                            onBlockEntity(
                                                post.posterId,
                                                ReportTargetType.CASTING_PROFILE,
                                                post.organizationName
                                            )
                                        },
                                        modifier = Modifier.testTag("block_casting_btn_${post.id}")
                                    ) {
                                        Icon(Icons.Filled.Block, contentDescription = filmStrings.blockButton, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }

                            Text(
                                text = post.roleTitle,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "${post.projectName} • ${post.organizationName}",
                                style = MaterialTheme.typography.titleSmall,
                                color = SaffronPrimary
                            )

                            Surface(
                                color = AmberContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "₹${post.paymentAmount} $unitLabel",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = OnAmberContainer,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.CalendarMonth, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("${filmStrings.shootDateLabel}: ${post.shootingDate}", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("${filmStrings.reportingTimeLabel}: ${post.reportingTime}", style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = TealSecondary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("${post.area}, ${post.city}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            }

                            val reqSummary = listOf(
                                String.format(filmStrings.artistsNeededFormat, post.artistsNeeded.toInt()),
                                String.format(filmStrings.ageRangeFormat, post.minAge.toInt(), post.maxAge.toInt()),
                                filmStrings.genderPrefLabel(post.genderPreferenceEnum()),
                                post.languages.joinToString(", ")
                            ).filter { it.isNotBlank() }.joinToString(" • ")
                            Text(
                                text = reqSummary,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (post.description.isNotBlank()) {
                                Text(
                                    text = post.description,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            Text(
                                text = filmStrings.noGuaranteeNotice,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (appStatus != null) {
                                Surface(
                                    color = when (appStatus) {
                                        CastingApplicationStatus.SELECTED -> EmeraldContainer
                                        CastingApplicationStatus.SHORTLISTED -> TealContainer
                                        CastingApplicationStatus.REJECTED -> CrimsonContainer
                                        CastingApplicationStatus.PENDING -> SaffronContainer
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = EmeraldSuccess)
                                        Text(
                                            text = "${filmStrings.appliedDirectLabel}: ${filmStrings.applicationStatusLabel(appStatus)}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            } else {
                                Button(
                                    onClick = {
                                        if (artistProfile == null) {
                                            onOpenArtistProfileTab()
                                        } else {
                                            pendingApplyPost = post
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("apply_casting_btn_${post.id}")
                                ) {
                                    Text(
                                        text = if (artistProfile == null) filmStrings.artistProfileTitle else filmStrings.applyDirectButton,
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingApplyPost?.let { targetPost ->
        AlertDialog(
            onDismissRequest = { pendingApplyPost = null },
            title = { Text("${filmStrings.applyDirectButton}: ${targetPost.roleTitle}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(targetPost.organizationName, fontWeight = FontWeight.SemiBold, color = SaffronPrimary)
                    Text(filmStrings.privacyNoticePhotosPhone, style = MaterialTheme.typography.bodySmall)
                    Text(filmStrings.noGuaranteeNotice, style = MaterialTheme.typography.bodySmall, color = AmberTertiary)
                    OutlinedTextField(
                        value = applyNote,
                        onValueChange = { applyNote = it },
                        label = { Text(strings.applyNoteHint) },
                        maxLines = 3,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("casting_apply_note_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onApplyPost(targetPost, applyNote)
                        applyNote = ""
                        pendingApplyPost = null
                    },
                    modifier = Modifier.testTag("confirm_apply_casting_btn")
                ) {
                    Text(strings.confirmApply)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingApplyPost = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    pendingReport?.let { target ->
        FilmSafetyReportDialog(
            target = target,
            filmStrings = filmStrings,
            onDismiss = { pendingReport = null },
            onSubmit = { reason, details ->
                onSubmitReport(target, reason, details)
                pendingReport = null
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ArtistProfileAndAppsScreen(
    artistProfile: FirestoreArtistProfile?,
    myApplications: List<FirestoreCastingApplication>,
    blockedEntities: List<FirestoreBlockedEntity>,
    activeLocations: List<IndianLocation>,
    strings: LocalizedStrings,
    filmStrings: FilmLocalizedStrings,
    onSaveArtistProfile: (
        name: String,
        age: Int,
        gender: WorkerGender?,
        city: String,
        area: String,
        phone: String,
        languages: List<String>,
        experienceYears: Int,
        skills: List<ArtistSkill>,
        bio: String,
        photosBase64: List<String>,
        noBrokerConfirmed: Boolean,
        zeroFeeAcknowledged: Boolean
    ) -> Unit,
    onUnblock: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val key = artistProfile?.uid ?: "new_artist"
    val defaultLoc = remember(key, artistProfile?.city, artistProfile?.area, activeLocations) {
        artistProfile?.let { IndianLocations.findActiveLocation(it.city, it.area, activeLocations) }
            ?: activeLocations.firstOrNull { it.city.equals("Hyderabad", ignoreCase = true) }
            ?: activeLocations.firstOrNull()
            ?: IndianLocations.defaultLocation
    }

    var name by remember(key, artistProfile?.name) { mutableStateOf(artistProfile?.name ?: "") }
    var ageText by remember(key, artistProfile?.age) { mutableStateOf((artistProfile?.age ?: 22L).toString()) }
    var phone by remember(key, artistProfile?.phone) { mutableStateOf(IndianMobileValidator.sanitizeInput(artistProfile?.phone ?: "")) }
    var city by remember(key, defaultLoc.city) { mutableStateOf(defaultLoc.city) }
    var area by remember(key, defaultLoc.area) { mutableStateOf(defaultLoc.area) }
    var gender by remember(key, artistProfile?.gender) { mutableStateOf(artistProfile?.genderEnum()) }
    var languages by remember(key, artistProfile?.languages) {
        mutableStateOf(artistProfile?.languages?.takeIf { it.isNotEmpty() } ?: listOf("Telugu"))
    }
    var expText by remember(key, artistProfile?.experienceYears) { mutableStateOf((artistProfile?.experienceYears ?: 0L).toString()) }
    var skills by remember(key, artistProfile?.skills) {
        mutableStateOf(artistProfile?.skillsEnumList() ?: listOf(ArtistSkill.JUNIOR_ARTIST))
    }
    var bio by remember(key, artistProfile?.bio) { mutableStateOf(artistProfile?.bio ?: "") }
    var photosBase64 by remember(key, artistProfile?.photosBase64) { mutableStateOf(artistProfile?.photosBase64 ?: emptyList()) }
    var noBrokerChecked by remember(key) { mutableStateOf(artistProfile?.noBrokerConfirmed ?: true) }
    var zeroFeeChecked by remember(key) { mutableStateOf(artistProfile?.zeroFeeAcknowledged ?: true) }

    val addPhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null && photosBase64.size < 3) {
            val encoded = ProfilePhotoHelper.encodeUriToBase64(context, uri)
            if (encoded != null) {
                photosBase64 = (photosBase64 + encoded).take(3)
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .testTag("artist_profile_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.2.dp, SaffronPrimary.copy(alpha = 0.4f)),
                    modifier = Modifier.testTag("artist_profile_form")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = if (artistProfile == null) filmStrings.artistProfileTitle else filmStrings.editArtistProfileTitle,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Surface(color = TealContainer, shape = RoundedCornerShape(12.dp)) {
                            Text(
                                text = filmStrings.privacyNoticePhotosPhone,
                                style = MaterialTheme.typography.bodySmall,
                                color = TealSecondary,
                                modifier = Modifier.padding(10.dp)
                            )
                        }

                        // Portfolio Photographs (max 3)
                        Text(filmStrings.portfolioPhotosLabel, style = MaterialTheme.typography.labelLarge)
                        Text(
                            text = filmStrings.maxThreePhotosHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            photosBase64.forEachIndexed { idx, encoded ->
                                val bmp = remember(encoded) { ProfilePhotoHelper.decodeBase64ToBitmap(encoded) }
                                Box(modifier = Modifier.size(84.dp)) {
                                    if (bmp != null) {
                                        Image(
                                            bitmap = bmp.asImageBitmap(),
                                            contentDescription = "Artist Photo ${idx + 1}",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(RoundedCornerShape(14.dp))
                                                .border(1.5.dp, SaffronPrimary, RoundedCornerShape(14.dp))
                                        )
                                    }
                                    IconButton(
                                        onClick = { photosBase64 = photosBase64.filterIndexed { i, _ -> i != idx } },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(DarkSurface.copy(alpha = 0.8f))
                                            .testTag("artist_remove_photo_$idx")
                                    ) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Remove photo", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            if (photosBase64.size < 3) {
                                OutlinedButton(
                                    onClick = {
                                        addPhotoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("artist_add_photo_btn")
                                ) {
                                    Icon(Icons.Filled.AddAPhoto, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text(String.format(filmStrings.addPhotoCountFormat, photosBase64.size))
                                }
                            }
                        }

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text(filmStrings.artistNameLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("artist_name_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = ageText,
                                onValueChange = { ageText = it.filter { ch -> ch.isDigit() }.take(3) },
                                label = { Text(filmStrings.artistAgeLabel) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("artist_age_input")
                            )
                            OutlinedTextField(
                                value = expText,
                                onValueChange = { expText = it.filter { ch -> ch.isDigit() }.take(2) },
                                label = { Text(strings.experienceYears) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("artist_exp_input")
                            )
                        }

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = IndianMobileValidator.sanitizeInput(it) },
                            label = { Text(strings.phoneLabel) },
                            prefix = { Text("+91 ") },
                            leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("artist_phone_input")
                        )

                        GenderSelector(
                            selectedGender = gender,
                            onGenderSelected = { gender = it },
                            strings = strings
                        )

                        CityAreaPicker(
                            selectedCity = city,
                            selectedArea = area,
                            onLocationSelected = { c, a ->
                                city = c
                                area = a
                            },
                            strings = strings,
                            activeLocations = activeLocations
                        )

                        SpokenLanguagesSelector(
                            selectedLanguages = languages,
                            onToggleLanguage = { lang ->
                                languages = if (languages.any { it.equals(lang, ignoreCase = true) }) {
                                    if (languages.size > 1) languages.filterNot { it.equals(lang, ignoreCase = true) } else languages
                                } else {
                                    languages + lang
                                }
                            },
                            strings = strings
                        )

                        Text(filmStrings.artistSkillsLabel, style = MaterialTheme.typography.labelLarge)
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ArtistSkill.entries.forEach { sk ->
                                val selected = skills.contains(sk)
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        skills = if (selected) {
                                            if (skills.size > 1) skills - sk else skills
                                        } else {
                                            skills + sk
                                        }
                                    },
                                    label = { Text(filmStrings.skillName(sk)) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SaffronContainer,
                                        selectedLabelColor = SaffronPrimary
                                    ),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("artist_skill_${sk.name}")
                                )
                            }
                        }

                        OutlinedTextField(
                            value = bio,
                            onValueChange = { bio = it },
                            label = { Text(filmStrings.artistBioLabel) },
                            maxLines = 3,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("artist_bio_input")
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = noBrokerChecked,
                                onCheckedChange = { noBrokerChecked = it },
                                modifier = Modifier.testTag("artist_no_broker_checkbox")
                            )
                            Text(filmStrings.noBrokerAttestation, style = MaterialTheme.typography.bodySmall)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = zeroFeeChecked,
                                onCheckedChange = { zeroFeeChecked = it },
                                modifier = Modifier.testTag("artist_zero_fee_checkbox")
                            )
                            Text(filmStrings.zeroFeeAttestation, style = MaterialTheme.typography.bodySmall)
                        }

                        BigActionButton(
                            text = filmStrings.saveArtistProfileButton,
                            icon = Icons.Filled.Save,
                            onClick = {
                                onSaveArtistProfile(
                                    name,
                                    ageText.toIntOrNull() ?: 0,
                                    gender,
                                    city,
                                    area,
                                    phone,
                                    languages,
                                    expText.toIntOrNull() ?: 0,
                                    skills,
                                    bio,
                                    photosBase64,
                                    noBrokerChecked,
                                    zeroFeeChecked
                                )
                            },
                            modifier = Modifier.testTag("save_artist_profile_btn")
                        )
                    }
                }
            }

            // My Casting Applications
            item {
                Text(
                    text = "${filmStrings.myCastingAppsTitle} (${myApplications.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("my_casting_apps_section")
                )
            }

            if (myApplications.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Text(
                            text = filmStrings.noCastingAppsYet,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(myApplications, key = { it.id }) { app ->
                    val status = app.statusEnum()
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("artist_app_card_${app.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.roleTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("${app.projectName} • ${app.organizationName}", style = MaterialTheme.typography.bodySmall, color = SaffronPrimary)
                                }
                                Surface(
                                    color = when (status) {
                                        CastingApplicationStatus.SELECTED -> EmeraldContainer
                                        CastingApplicationStatus.SHORTLISTED -> TealContainer
                                        CastingApplicationStatus.REJECTED -> CrimsonContainer
                                        CastingApplicationStatus.PENDING -> AmberContainer
                                    },
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = filmStrings.applicationStatusLabel(status),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            Text(
                                text = "₹${app.paymentAmount} ${filmStrings.paymentUnitLabel(app.paymentUnitEnum())} • ${app.shootingDate} (${app.reportingTime})",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${app.shootingArea}, ${app.shootingCity}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = filmStrings.noGuaranteeNotice,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Blocked Entities Management
            if (blockedEntities.isNotEmpty()) {
                item {
                    Text(
                        text = "${filmStrings.blockedListTitle} (${blockedEntities.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(blockedEntities, key = { it.id }) { blocked ->
                    Card(shape = RoundedCornerShape(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(blocked.targetLabel, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            TextButton(
                                onClick = { onUnblock(blocked.targetId) },
                                modifier = Modifier.testTag("unblock_btn_${blocked.targetId}")
                            ) {
                                Text(filmStrings.unblockButton)
                            }
                        }
                    }
                }
            }
        }
    }
}
