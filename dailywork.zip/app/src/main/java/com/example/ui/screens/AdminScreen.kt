package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CastingVerificationStatus
import com.example.data.FirestoreCastingProfile
import com.example.data.FirestoreContentReport
import com.example.data.FirestoreJob
import com.example.data.FirestoreServiceAreasConfig
import com.example.data.FirestoreUser
import com.example.data.IndianLocations
import com.example.data.JobStatus
import com.example.data.ReportStatus
import com.example.data.UserRole
import com.example.i18n.FilmLocalizedStrings
import com.example.i18n.LocalizedStrings
import com.example.ui.components.BigActionButton
import com.example.ui.components.JobStatusPill
import com.example.ui.components.VerifiedChip
import com.example.ui.components.WageBadge
import com.example.ui.components.WageDistributionChart
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.OnAmberContainer
import com.example.ui.theme.SaffronContainer
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealSecondary
import com.example.ui.viewmodel.AdminStats

@Composable
fun AdminOverviewScreen(
    stats: AdminStats,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "${strings.demoAdmin} • ${strings.navOverview}",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminStatCard(
                        title = strings.totalWorkers,
                        value = stats.totalWorkers.toString(),
                        icon = Icons.Filled.Engineering,
                        bg = SaffronContainer,
                        tint = SaffronPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatCard(
                        title = strings.totalEmployers,
                        value = stats.totalEmployers.toString(),
                        icon = Icons.Filled.BusinessCenter,
                        bg = TealContainer,
                        tint = TealSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminStatCard(
                        title = strings.openJobs,
                        value = stats.openJobs.toString(),
                        icon = Icons.Filled.Work,
                        bg = EmeraldContainer,
                        tint = EmeraldSuccess,
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatCard(
                        title = strings.avgDailyWage,
                        value = "₹${stats.averageDailyWage}",
                        icon = Icons.Filled.CurrencyRupee,
                        bg = AmberContainer,
                        tint = AmberTertiary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = strings.wageDistributionTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${stats.totalApplications} ${strings.totalApplications}",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        WageDistributionChart(
                            avgWages = stats.avgWageByCategory,
                            strings = strings
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    bg: Color,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = tint, modifier = Modifier.size(26.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun AdminUsersScreen(
    users: List<FirestoreUser>,
    strings: LocalizedStrings,
    onToggleVerify: (FirestoreUser) -> Unit,
    onToggleSuspend: (FirestoreUser) -> Unit,
    modifier: Modifier = Modifier
) {
    val nonAdminUsers = users.filter { it.roleEnum() != UserRole.ADMIN }
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    text = "${strings.navUsers} (${nonAdminUsers.size})",
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            items(nonAdminUsers, key = { it.id.ifBlank { it.uid } }) { user ->
                val uidKey = user.id.ifBlank { user.uid }
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = user.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${strings.roleName(user.roleEnum())} • ${user.phone} • ${user.area}, ${user.city}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (user.isSuspended) {
                                Surface(color = CrimsonContainer, shape = RoundedCornerShape(50)) {
                                    Text(
                                        text = strings.suspendedBadge,
                                        color = CrimsonError,
                                        style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            } else {
                                VerifiedChip(verified = user.isVerified, strings = strings)
                            }
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onToggleVerify(user) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (user.isVerified) MaterialTheme.colorScheme.surfaceVariant else TealSecondary,
                                    contentColor = if (user.isVerified) MaterialTheme.colorScheme.onSurface else Color.White
                                ),
                                modifier = Modifier.weight(1f).height(48.dp).testTag("verify_user_$uidKey"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (user.isVerified) strings.unverifiedBadge else strings.verifyAction)
                            }
                            OutlinedButton(
                                onClick = { onToggleSuspend(user) },
                                border = BorderStroke(
                                    1.dp,
                                    if (user.isSuspended) EmeraldSuccess else CrimsonError
                                ),
                                modifier = Modifier.weight(1f).height(48.dp).testTag("suspend_user_$uidKey"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = if (user.isSuspended) Icons.Filled.CheckCircle else Icons.Filled.Block,
                                    contentDescription = null,
                                    tint = if (user.isSuspended) EmeraldSuccess else CrimsonError,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (user.isSuspended) strings.activateAction else strings.suspendAction,
                                    color = if (user.isSuspended) EmeraldSuccess else CrimsonError
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminJobsAndBroadcastScreen(
    jobs: List<FirestoreJob>,
    strings: LocalizedStrings,
    onToggleJobStatus: (FirestoreJob, JobStatus) -> Unit,
    onDeleteJob: (FirestoreJob) -> Unit,
    onSendBroadcast: (title: String, message: String, targetRole: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var targetRole by remember { mutableStateOf("ALL") }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = strings.navBroadcast,
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text(strings.broadcastTitle) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().testTag("broadcast_title_input")
                        )
                        OutlinedTextField(
                            value = message,
                            onValueChange = { message = it },
                            label = { Text(strings.broadcastMessage) },
                            maxLines = 3,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().testTag("broadcast_msg_input")
                        )
                        Text(strings.targetAudience, style = MaterialTheme.typography.labelLarge)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "ALL" to strings.audienceAll,
                                "WORKER" to strings.audienceWorkers,
                                "EMPLOYER" to strings.audienceEmployers
                            ).forEach { (code, label) ->
                                FilterChip(
                                    selected = targetRole == code,
                                    onClick = { targetRole = code },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                )
                            }
                        }
                        BigActionButton(
                            text = strings.sendBroadcast,
                            icon = Icons.Filled.Campaign,
                            onClick = {
                                onSendBroadcast(title, message, targetRole)
                                title = ""
                                message = ""
                            },
                            enabled = title.isNotBlank() && message.isNotBlank(),
                            modifier = Modifier.testTag("send_broadcast_btn")
                        )
                    }
                }
            }

            item {
                Text(
                    text = "${strings.navJobs} (${jobs.size})",
                    style = MaterialTheme.typography.headlineSmall
                )
            }

            items(jobs, key = { it.id }) { job ->
                val status = job.statusEnum()
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(job.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    "${job.employerName} • ${job.area}, ${job.city}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            JobStatusPill(status = status, strings = strings)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            WageBadge(wage = job.dailyWage.toInt(), perDayText = strings.perDay)
                            if (job.dailyWage < 500L) {
                                Surface(color = AmberContainer, shape = RoundedCornerShape(10.dp)) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.Warning, contentDescription = null, tint = AmberTertiary, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.lowWageWarning, style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val next = if (status == JobStatus.OPEN) JobStatus.CLOSED else JobStatus.OPEN
                                    onToggleJobStatus(job, next)
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(if (status == JobStatus.OPEN) strings.closeJob else strings.reopenJob)
                            }
                            OutlinedButton(
                                onClick = { onDeleteJob(job) },
                                border = BorderStroke(1.dp, CrimsonError),
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = CrimsonError, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.deleteJob, color = CrimsonError)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminServiceAreasScreen(
    config: FirestoreServiceAreasConfig,
    strings: LocalizedStrings,
    onToggleCity: (String, Boolean) -> Unit,
    onAddCustomArea: (city: String, state: String, locality: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeCities = remember(config) { config.activeCityNames() }
    val activeLocations = remember(config) { config.toIndianLocations() }
    val allCatalogCities = remember(activeCities) {
        (IndianLocations.launchCities + IndianLocations.expansionCityNames + activeCities).distinct()
    }
    var customCity by remember { mutableStateOf("") }
    var customState by remember { mutableStateOf("Telangana") }
    var customLocality by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_service_areas_screen"),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .testTag("admin_service_areas_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = strings.adminServiceAreasTitle,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Text(
                        text = strings.adminServiceAreasSubtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                Surface(
                    color = TealContainer,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, TealSecondary.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Public,
                            contentDescription = null,
                            tint = TealSecondary
                        )
                        Column {
                            Text(
                                text = strings.activeCitiesTitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = TealSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = activeCities.joinToString(" • "),
                                style = MaterialTheme.typography.titleMedium,
                                color = TealSecondary,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.expansionCitiesTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        allCatalogCities.forEach { cityName ->
                            val isEnabled = config.isCityEnabled(cityName)
                            val count = IndianLocations.areasForCity(cityName, activeLocations).size
                            val canDisable = !isEnabled || activeCities.size > 1
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.LocationOn,
                                        contentDescription = null,
                                        tint = if (isEnabled) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = cityName,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (isEnabled && count > 0) {
                                            Text(
                                                text = "$count localities",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                                Switch(
                                    checked = isEnabled,
                                    enabled = canDisable,
                                    onCheckedChange = { checked ->
                                        onToggleCity(cityName, checked)
                                    },
                                    modifier = Modifier.testTag("toggle_city_$cityName")
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = strings.addCustomCityTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedTextField(
                            value = customCity,
                            onValueChange = { customCity = it },
                            label = { Text(strings.cityInputLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_city_input")
                        )
                        OutlinedTextField(
                            value = customLocality,
                            onValueChange = { customLocality = it },
                            label = { Text(strings.addLocalityLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_locality_input")
                        )
                        OutlinedTextField(
                            value = customState,
                            onValueChange = { customState = it },
                            label = { Text(strings.stateInputLabel) },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_state_input")
                        )
                        BigActionButton(
                            text = strings.addServiceAreaButton,
                            icon = Icons.Filled.AddLocationAlt,
                            onClick = {
                                onAddCustomArea(customCity, customState, customLocality)
                                customCity = ""
                                customLocality = ""
                            },
                            enabled = customCity.isNotBlank() && customLocality.isNotBlank(),
                            modifier = Modifier.testTag("add_service_area_btn")
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminFilmModerationScreen(
    castingProfiles: List<FirestoreCastingProfile>,
    reports: List<FirestoreContentReport>,
    strings: LocalizedStrings,
    filmStrings: FilmLocalizedStrings,
    onVerifyCasting: (FirestoreCastingProfile, Boolean, String) -> Unit,
    onToggleSuspendCasting: (FirestoreCastingProfile) -> Unit,
    onResolveReport: (
        report: FirestoreContentReport,
        newStatus: ReportStatus,
        actionNote: String,
        removeReportedPost: Boolean,
        suspendReportedOwner: Boolean
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var rejectNotes by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("admin_film_moderation_screen"),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .testTag("admin_film_moderation_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "${filmStrings.adminCastingVerifyTitle} (${castingProfiles.size})",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            items(castingProfiles, key = { it.uid.ifBlank { it.id } }) { profile ->
                val vStatus = profile.verificationStatusEnum()
                val noteVal = rejectNotes[profile.uid] ?: ""
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_casting_profile_${profile.uid}")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(profile.organizationName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${filmStrings.accountTypeName(profile.accountTypeEnum())} • ${profile.contactName} (${profile.phone})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SaffronPrimary
                                )
                            }
                            Surface(
                                color = when {
                                    profile.isSuspended -> CrimsonContainer
                                    vStatus == CastingVerificationStatus.VERIFIED -> EmeraldContainer
                                    vStatus == CastingVerificationStatus.REJECTED -> CrimsonContainer
                                    else -> AmberContainer
                                },
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = if (profile.isSuspended) strings.suspendedBadge else filmStrings.verificationStatusLabel(vStatus),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = "${profile.area}, ${profile.city} • ID: ${profile.idProofType} (${profile.idReferenceMasked})",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = profile.projectCredits,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = noteVal,
                            onValueChange = { rejectNotes = rejectNotes + (profile.uid to it) },
                            label = { Text(filmStrings.rejectReasonHint) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onVerifyCasting(profile, true, "") },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("admin_verify_casting_${profile.uid}")
                            ) {
                                Icon(Icons.Filled.Verified, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(filmStrings.approveVerifyButton, color = Color.White)
                            }
                            OutlinedButton(
                                onClick = { onVerifyCasting(profile, false, noteVal) },
                                border = BorderStroke(1.dp, CrimsonError),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("admin_reject_casting_${profile.uid}")
                            ) {
                                Text(filmStrings.rejectVerifyButton, color = CrimsonError)
                            }
                            OutlinedButton(
                                onClick = { onToggleSuspendCasting(profile) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("admin_suspend_casting_${profile.uid}")
                            ) {
                                Text(if (profile.isSuspended) strings.activateAction else strings.suspendAction)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "${filmStrings.adminReportsTitle} (${reports.size})",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            items(reports, key = { it.id }) { report ->
                val rStatus = report.statusEnum()
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.35f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_report_card_${report.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = report.targetLabel,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            Surface(
                                color = when (rStatus) {
                                    ReportStatus.OPEN -> AmberContainer
                                    ReportStatus.RESOLVED -> EmeraldContainer
                                    ReportStatus.DISMISSED -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = filmStrings.reportStatusLabel(rStatus),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (rStatus == ReportStatus.OPEN) OnAmberContainer else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Text(
                            text = "${filmStrings.reportReasonLabel(report.reasonEnum())} • By ${report.reporterName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonError
                        )
                        if (report.details.isNotBlank()) {
                            Text(report.details, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (rStatus == ReportStatus.OPEN) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        onResolveReport(report, ReportStatus.RESOLVED, "Closed reported post", true, false)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("admin_resolve_close_post_${report.id}")
                                ) {
                                    Text(filmStrings.resolveRemovePostButton, color = Color.White)
                                }
                                OutlinedButton(
                                    onClick = {
                                        onResolveReport(report, ReportStatus.RESOLVED, "Suspended reported owner", true, true)
                                    },
                                    border = BorderStroke(1.dp, CrimsonError),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("admin_resolve_suspend_${report.id}")
                                ) {
                                    Text(filmStrings.resolveSuspendAccountButton, color = CrimsonError)
                                }
                            }
                            OutlinedButton(
                                onClick = {
                                    onResolveReport(report, ReportStatus.DISMISSED, "Reviewed & dismissed", false, false)
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("admin_dismiss_report_${report.id}")
                            ) {
                                Text(filmStrings.dismissReportButton)
                            }
                        }
                    }
                }
            }
        }
    }
}


