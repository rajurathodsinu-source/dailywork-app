package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.AppLanguage
import com.example.data.FirestoreNotification
import com.example.data.FirestoreUser
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.IndianMobileValidator
import com.example.data.NotificationType
import com.example.data.UserRole
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.data.WorkerGender
import com.example.i18n.LocalizedStrings
import com.example.ui.components.BigActionButton
import com.example.ui.components.CityAreaPicker
import com.example.ui.components.GenderSelector
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.components.ListenButton
import com.example.ui.components.MultiSkillSelectorGrid
import com.example.ui.components.ProfileAvatar
import com.example.ui.components.ProfilePhotoPickerRow
import com.example.ui.components.SpokenLanguagesSelector
import com.example.ui.components.VerifiedChip
import com.example.ui.components.WorkAvailabilitySelector
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.SaffronContainer
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealSecondary

@Composable
fun NotificationsScreen(
    notifications: List<FirestoreNotification>,
    strings: LocalizedStrings,
    onMarkRead: (FirestoreNotification) -> Unit,
    onMarkAllRead: () -> Unit,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.navAlerts,
                    style = MaterialTheme.typography.headlineMedium
                )
                if (notifications.any { !it.isRead }) {
                    TextButton(
                        onClick = onMarkAllRead,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("mark_all_read_btn")
                    ) {
                        Icon(Icons.Filled.DoneAll, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.markAllRead)
                    }
                }
            }

            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsNone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = strings.noNotificationsYet,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(notifications, key = { it.id }) { notif ->
                        val (icon, bg, tint) = when (notif.typeEnum()) {
                            NotificationType.NEW_JOB -> Triple(Icons.Filled.Work, SaffronContainer, SaffronPrimary)
                            NotificationType.NEW_CASTING -> Triple(Icons.Filled.Movie, SaffronContainer, SaffronPrimary)
                            NotificationType.APPLICATION_ACCEPTED,
                            NotificationType.CASTING_SELECTED,
                            NotificationType.CASTING_VERIFIED -> Triple(Icons.Filled.CheckCircle, EmeraldContainer, EmeraldSuccess)
                            NotificationType.APPLICATION_RECEIVED,
                            NotificationType.CASTING_APPLIED,
                            NotificationType.CASTING_SHORTLISTED -> Triple(Icons.Filled.Person, TealContainer, TealSecondary)
                            NotificationType.ADMIN_ALERT -> Triple(Icons.Filled.Campaign, AmberContainer, AmberTertiary)
                            NotificationType.CASTING_REJECTED -> Triple(Icons.Filled.Notifications, CrimsonContainer, CrimsonError)
                            else -> Triple(Icons.Filled.Notifications, MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.primary)
                        }
                        Card(
                            onClick = { onMarkRead(notif) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("notification_card_${notif.id}"),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (notif.isRead) {
                                    MaterialTheme.colorScheme.surface
                                } else {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                                }
                            ),
                            border = BorderStroke(
                                width = if (notif.isRead) 1.dp else 1.5.dp,
                                color = if (notif.isRead) {
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                                } else {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                                }
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(bg),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = tint,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = notif.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (!notif.isRead) {
                                            Box(
                                                modifier = Modifier
                                                    .size(10.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.primary)
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        text = notif.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    ListenButton(
                                        label = strings.listen,
                                        onClick = { onSpeak("${notif.title}. ${notif.message}") }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(
    user: FirestoreUser?,
    userEmail: String?,
    isAdminUser: Boolean,
    adminModeEnabled: Boolean,
    language: AppLanguage,
    strings: LocalizedStrings,
    onLanguageSelected: (AppLanguage) -> Unit,
    onToggleAvailability: () -> Unit,
    onToggleAdminMode: (Boolean) -> Unit,
    onSaveProfile: (
        name: String,
        phone: String,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int,
        skills: List<WorkCategory>,
        spokenLanguages: List<String>,
        gender: WorkerGender?,
        availabilityStatus: WorkAvailability,
        profilePhotoBase64: String
    ) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier,
    activeLocations: List<IndianLocation> = IndianLocations.launchPresets
) {
    val userKey = user?.uid ?: "admin"
    val defaultActiveLoc = remember(userKey, user?.city, user?.area, activeLocations) {
        val candidate = if (user != null) {
            IndianLocations.findActiveLocation(user.city, user.area, activeLocations)
        } else null
        candidate ?: activeLocations.firstOrNull() ?: IndianLocations.defaultLocation
    }
    var name by remember(userKey, user?.name) { mutableStateOf(user?.name ?: "DailyWork Admin") }
    var phone by remember(userKey, user?.phone) {
        mutableStateOf(IndianMobileValidator.sanitizeInput(user?.phone ?: ""))
    }
    var city by remember(userKey, defaultActiveLoc.city) { mutableStateOf(defaultActiveLoc.city) }
    var area by remember(userKey, defaultActiveLoc.area) { mutableStateOf(defaultActiveLoc.area) }
    var skills by remember(userKey, user?.skills, user?.primarySkill) {
        mutableStateOf(user?.skillsEnumList() ?: listOf(WorkCategory.MASON))
    }
    var spokenLanguages by remember(userKey, user?.spokenLanguages) {
        mutableStateOf(user?.spokenLanguagesList() ?: emptyList())
    }
    var gender by remember(userKey, user?.gender) {
        mutableStateOf(user?.genderEnum())
    }
    var availabilityStatus by remember(userKey, user?.availabilityStatus, user?.isAvailable) {
        mutableStateOf(user?.availabilityEnum() ?: WorkAvailability.AVAILABLE_TODAY)
    }
    var profilePhotoBase64 by remember(userKey, user?.profilePhotoBase64) {
        mutableStateOf(user?.profilePhotoBase64 ?: "")
    }
    var wage by remember(userKey, user?.expectedDailyWage) {
        mutableIntStateOf((user?.expectedDailyWage ?: 700L).toInt())
    }
    var exp by remember(userKey, user?.experienceYears) {
        mutableIntStateOf((user?.experienceYears ?: 1L).toInt())
    }
    var saveAttempted by remember { mutableStateOf(false) }

    val cleanPhone = IndianMobileValidator.sanitizeInput(phone)
    val isPhoneInvalid = (saveAttempted || cleanPhone.length == 10) && !IndianMobileValidator.isValid(cleanPhone)

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = strings.navProfile,
                style = MaterialTheme.typography.headlineMedium
            )

            LanguageSelectorBar(
                currentLanguage = language,
                onLanguageSelected = onLanguageSelected
            )

            if (isAdminUser) {
                Surface(
                    color = TealContainer,
                    shape = RoundedCornerShape(18.dp),
                    border = BorderStroke(1.dp, TealSecondary.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = null,
                                tint = TealSecondary
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = strings.switchAdminMode,
                                style = MaterialTheme.typography.titleMedium,
                                color = TealSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Switch(
                            checked = adminModeEnabled,
                            onCheckedChange = onToggleAdminMode,
                            modifier = Modifier.testTag("admin_mode_switch")
                        )
                    }
                }
            }

            // User Summary Card
            if (user != null) {
                val role = user.roleEnum()
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProfileAvatar(
                                    photoBase64 = user.profilePhotoBase64,
                                    name = user.name,
                                    size = 54.dp
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = user.name,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                    Text(
                                        text = "${strings.roleName(role)} • ${user.phone}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (!userEmail.isNullOrBlank()) {
                                        Text(
                                            text = userEmail,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            VerifiedChip(verified = user.isVerified, strings = strings)
                        }

                        if (role == UserRole.WORKER) {
                            Surface(
                                color = if (user.isAvailable) EmeraldContainer else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val availText = when (user.availabilityEnum()) {
                                        WorkAvailability.AVAILABLE_TODAY -> strings.availableToday
                                        WorkAvailability.AVAILABLE_THIS_WEEK -> strings.availThisWeek
                                        WorkAvailability.NOT_AVAILABLE -> strings.notAvailable
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = availText,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = if (user.isAvailable) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "${user.completedJobs} ${strings.jobsDone} • ★ ${user.rating}",
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                    Switch(
                                        checked = user.isAvailable,
                                        onCheckedChange = { onToggleAvailability() },
                                        modifier = Modifier.testTag("profile_availability_switch")
                                    )
                                }
                            }
                        }
                    }
                }

                if (role != UserRole.ADMIN) {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            if (role == UserRole.WORKER) {
                                ProfilePhotoPickerRow(
                                    photoBase64 = profilePhotoBase64,
                                    name = name,
                                    strings = strings,
                                    onPhotoSelected = { profilePhotoBase64 = it },
                                    onRemovePhoto = { profilePhotoBase64 = "" }
                                )
                            }

                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = {
                                    Text(if (role == UserRole.WORKER) strings.nameLabel else strings.employerNameLabel)
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
                            )

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = IndianMobileValidator.sanitizeInput(it) },
                                label = { Text(strings.phoneLabel) },
                                prefix = { Text("+91 ") },
                                leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                isError = isPhoneInvalid,
                                supportingText = if (isPhoneInvalid) {
                                    { Text(strings.invalidIndianMobileHint) }
                                } else null,
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth().testTag("profile_phone_input")
                            )

                            CityAreaPicker(
                                selectedCity = city,
                                selectedArea = area,
                                onLocationSelected = { c, a ->
                                    city = c
                                    area = a
                                },
                                strings = strings,
                                activeLocations = activeLocations
                            )

                            if (role == UserRole.WORKER) {
                                Text(
                                    text = strings.selectSkillsMulti,
                                    style = MaterialTheme.typography.labelLarge
                                )
                                MultiSkillSelectorGrid(
                                    selectedSkills = skills,
                                    onToggleSkill = { clicked ->
                                        skills = if (skills.contains(clicked)) {
                                            if (skills.size > 1) skills - clicked else skills
                                        } else {
                                            skills + clicked
                                        }
                                    },
                                    strings = strings
                                )

                                GenderSelector(
                                    selectedGender = gender,
                                    onGenderSelected = { gender = it },
                                    strings = strings
                                )

                                SpokenLanguagesSelector(
                                    selectedLanguages = spokenLanguages,
                                    onToggleLanguage = { lang ->
                                        spokenLanguages = if (spokenLanguages.any { it.equals(lang, ignoreCase = true) }) {
                                            spokenLanguages.filterNot { it.equals(lang, ignoreCase = true) }
                                        } else {
                                            spokenLanguages + lang
                                        }
                                    },
                                    strings = strings
                                )

                                WorkAvailabilitySelector(
                                    selected = availabilityStatus,
                                    onSelected = { availabilityStatus = it },
                                    strings = strings
                                )

                                Text(
                                    text = "${strings.expectedDailyWage}: ₹$wage",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(600, 750, 900, 1100).forEach { w ->
                                        FilterChip(
                                            selected = wage == w,
                                            onClick = { wage = w },
                                            label = { Text("₹$w") },
                                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                        )
                                    }
                                }
                                Text(
                                    text = "${strings.experienceYears}: $exp",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(1, 3, 5, 8).forEach { y ->
                                        FilterChip(
                                            selected = exp == y,
                                            onClick = { exp = y },
                                            label = { Text("$y+") },
                                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                        )
                                    }
                                }
                            }

                            BigActionButton(
                                text = strings.saveProfile,
                                icon = Icons.Filled.Save,
                                onClick = {
                                    saveAttempted = true
                                    val primary = skills.firstOrNull() ?: WorkCategory.HELPER
                                    onSaveProfile(
                                        name,
                                        cleanPhone,
                                        city,
                                        area,
                                        primary,
                                        exp,
                                        wage,
                                        skills,
                                        spokenLanguages,
                                        gender,
                                        availabilityStatus,
                                        profilePhotoBase64
                                    )
                                },
                                modifier = Modifier.testTag("save_profile_button")
                            )
                        }
                    }
                }
            }

            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("logout_button"),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, CrimsonError)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = null,
                    tint = CrimsonError
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = strings.logout,
                    style = MaterialTheme.typography.titleMedium,
                    color = CrimsonError,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
