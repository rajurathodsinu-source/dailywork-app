package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.CastingAccountType
import com.example.data.CastingApplicationStatus
import com.example.data.CastingVerificationStatus
import com.example.data.FirestoreCastingApplication
import com.example.data.FirestoreCastingPost
import com.example.data.FirestoreCastingProfile
import com.example.data.GenderPreference
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.IndianMobileValidator
import com.example.data.JobStatus
import com.example.data.PaymentUnit
import com.example.data.ReportReason
import com.example.data.ReportTargetType
import com.example.i18n.FilmLocalizedStrings
import com.example.i18n.LocalizedStrings
import com.example.ui.components.BigActionButton
import com.example.ui.components.CityAreaPicker
import com.example.ui.components.JobStatusPill
import com.example.ui.components.SpokenLanguagesSelector
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.OnAmberContainer
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealSecondary
import com.example.util.ContactHelper
import com.example.util.ProfilePhotoHelper

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CastingStudioScreen(
    castingProfile: FirestoreCastingProfile?,
    myPosts: List<FirestoreCastingPost>,
    activeLocations: List<IndianLocation>,
    strings: LocalizedStrings,
    filmStrings: FilmLocalizedStrings,
    onSubmitVerification: (
        accountType: CastingAccountType,
        organizationName: String,
        contactName: String,
        phone: String,
        city: String,
        area: String,
        projectCredits: String,
        idProofType: String,
        idReferenceMasked: String,
        verificationNotes: String,
        noBrokerConfirmed: Boolean,
        zeroFeeConfirmed: Boolean
    ) -> Unit,
    onPostCasting: (
        projectName: String,
        roleTitle: String,
        artistsNeeded: Int,
        minAge: Int,
        maxAge: Int,
        genderPreference: GenderPreference,
        languages: List<String>,
        shootingDate: String,
        reportingTime: String,
        city: String,
        area: String,
        paymentAmount: Int,
        paymentUnit: PaymentUnit,
        description: String,
        noBrokerConfirmed: Boolean,
        zeroFeeConfirmed: Boolean
    ) -> Unit,
    onTogglePostStatus: (FirestoreCastingPost, JobStatus) -> Unit,
    onDeletePost: (FirestoreCastingPost) -> Unit,
    modifier: Modifier = Modifier
) {
    val key = castingProfile?.uid ?: "new_casting"
    val defaultLoc = remember(key, castingProfile?.city, castingProfile?.area, activeLocations) {
        castingProfile?.let { IndianLocations.findActiveLocation(it.city, it.area, activeLocations) }
            ?: activeLocations.firstOrNull { it.city.equals("Hyderabad", ignoreCase = true) }
            ?: activeLocations.firstOrNull()
            ?: IndianLocations.defaultLocation
    }

    var accountType by remember(key, castingProfile?.accountType) {
        mutableStateOf(castingProfile?.accountTypeEnum() ?: CastingAccountType.CASTING_DIRECTOR)
    }
    var orgName by remember(key, castingProfile?.organizationName) { mutableStateOf(castingProfile?.organizationName ?: "") }
    var contactName by remember(key, castingProfile?.contactName) { mutableStateOf(castingProfile?.contactName ?: "") }
    var phone by remember(key, castingProfile?.phone) { mutableStateOf(IndianMobileValidator.sanitizeInput(castingProfile?.phone ?: "")) }
    var city by remember(key, defaultLoc.city) { mutableStateOf(defaultLoc.city) }
    var area by remember(key, defaultLoc.area) { mutableStateOf(defaultLoc.area) }
    var credits by remember(key, castingProfile?.projectCredits) { mutableStateOf(castingProfile?.projectCredits ?: "") }
    var idProofType by remember(key, castingProfile?.idProofType) { mutableStateOf(castingProfile?.idProofType?.ifBlank { "Film Chamber Card" } ?: "Film Chamber Card") }
    var idRefMasked by remember(key, castingProfile?.idReferenceMasked) { mutableStateOf(castingProfile?.idReferenceMasked ?: "") }
    var notes by remember(key, castingProfile?.verificationNotes) { mutableStateOf(castingProfile?.verificationNotes ?: "") }
    var noBrokerChecked by remember(key) { mutableStateOf(castingProfile?.noBrokerConfirmed ?: true) }
    var zeroFeeChecked by remember(key) { mutableStateOf(castingProfile?.zeroFeeConfirmed ?: true) }
    var showForm by remember(key, castingProfile?.verificationStatus) {
        mutableStateOf(
            castingProfile == null ||
                castingProfile.verificationStatusEnum() == CastingVerificationStatus.REJECTED
        )
    }
    var showPostSheet by remember { mutableStateOf(false) }

    val status = castingProfile?.verificationStatusEnum()
    val isVerified = status == CastingVerificationStatus.VERIFIED && castingProfile?.isSuspended == false

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .testTag("casting_studio_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Verification Status Banner
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isVerified -> EmeraldContainer
                            status == CastingVerificationStatus.PENDING -> AmberContainer
                            status == CastingVerificationStatus.REJECTED -> CrimsonContainer
                            else -> MaterialTheme.colorScheme.surface
                        }
                    ),
                    border = BorderStroke(
                        1.2.dp,
                        when {
                            isVerified -> EmeraldSuccess
                            status == CastingVerificationStatus.PENDING -> AmberTertiary
                            status == CastingVerificationStatus.REJECTED -> CrimsonError
                            else -> SaffronPrimary.copy(alpha = 0.45f)
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("casting_verification_status_card")
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = when {
                                        isVerified -> Icons.Filled.Verified
                                        status == CastingVerificationStatus.PENDING -> Icons.Filled.HourglassTop
                                        else -> Icons.Filled.Badge
                                    },
                                    contentDescription = null,
                                    tint = when {
                                        isVerified -> EmeraldSuccess
                                        status == CastingVerificationStatus.REJECTED -> CrimsonError
                                        status == CastingVerificationStatus.PENDING -> OnAmberContainer
                                        else -> SaffronPrimary
                                    }
                                )
                                Text(
                                    text = when {
                                        isVerified -> "${filmStrings.verifiedOrganizerBadge}: ${castingProfile?.organizationName}"
                                        status == CastingVerificationStatus.PENDING -> filmStrings.pendingVerificationTitle
                                        status == CastingVerificationStatus.REJECTED -> filmStrings.rejectedVerificationTitle
                                        else -> filmStrings.castingVerificationTitle
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            if (castingProfile != null) {
                                OutlinedButton(
                                    onClick = { showForm = !showForm },
                                    modifier = Modifier.testTag("toggle_casting_form_btn")
                                ) {
                                    Text(if (showForm) "Hide" else "Edit ID")
                                }
                            }
                        }

                        Text(
                            text = when {
                                isVerified -> filmStrings.verifiedPublishUnlockedDesc
                                status == CastingVerificationStatus.PENDING -> filmStrings.pendingVerificationDesc
                                status == CastingVerificationStatus.REJECTED -> castingProfile?.rejectionReason?.ifBlank { filmStrings.rejectedVerificationTitle } ?: ""
                                else -> filmStrings.castingVerificationSubtitle
                            },
                            style = MaterialTheme.typography.bodyMedium
                        )

                        Button(
                            onClick = { showPostSheet = true },
                            enabled = isVerified,
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("open_post_casting_btn")
                        ) {
                            Icon(Icons.Filled.AddCircle, contentDescription = null, tint = Color.White)
                            Spacer(Modifier.width(8.dp))
                            Text(filmStrings.postCastingButton, color = Color.White, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }

            // Verification Identity Form
            if (showForm) {
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("casting_verification_form")
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = filmStrings.selectAccountTypeLabel,
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                CastingAccountType.entries.forEach { type ->
                                    val selected = accountType == type
                                    FilterChip(
                                        selected = selected,
                                        onClick = { accountType = type },
                                        label = { Text(filmStrings.accountTypeName(type)) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = SaffronPrimary,
                                            selectedLabelColor = Color.White
                                        ),
                                        modifier = Modifier
                                            .minimumInteractiveComponentSize()
                                            .testTag("casting_type_${type.name}")
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = orgName,
                                onValueChange = { orgName = it },
                                label = { Text(filmStrings.organizationNameLabel) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("casting_org_input")
                            )
                            OutlinedTextField(
                                value = contactName,
                                onValueChange = { contactName = it },
                                label = { Text(filmStrings.contactNameLabel) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("casting_contact_input")
                            )
                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = IndianMobileValidator.sanitizeInput(it) },
                                label = { Text(strings.phoneLabel) },
                                prefix = { Text("+91 ") },
                                leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("casting_phone_input")
                            )

                            CityAreaPicker(
                                selectedCity = city,
                                selectedArea = area,
                                onLocationSelected = { c, a ->
                                    city = c
                                    area = a
                                },
                                strings = strings,
                                activeLocations = activeLocations
                            )

                            OutlinedTextField(
                                value = credits,
                                onValueChange = { credits = it },
                                label = { Text(filmStrings.projectCreditsLabel) },
                                maxLines = 2,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("casting_credits_input")
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = idProofType,
                                    onValueChange = { idProofType = it },
                                    label = { Text(filmStrings.idProofTypeLabel) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("casting_id_type_input")
                                )
                                OutlinedTextField(
                                    value = idRefMasked,
                                    onValueChange = { idRefMasked = it },
                                    label = { Text(filmStrings.idReferenceMaskedLabel) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("casting_id_ref_input")
                                )
                            }
                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text(filmStrings.verificationNotesLabel) },
                                maxLines = 2,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("casting_notes_input")
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = noBrokerChecked,
                                    onCheckedChange = { noBrokerChecked = it },
                                    modifier = Modifier.testTag("casting_no_broker_checkbox")
                                )
                                Text(filmStrings.noBrokerAttestation, style = MaterialTheme.typography.bodySmall)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = zeroFeeChecked,
                                    onCheckedChange = { zeroFeeChecked = it },
                                    modifier = Modifier.testTag("casting_zero_fee_checkbox")
                                )
                                Text(filmStrings.zeroFeeAttestation, style = MaterialTheme.typography.bodySmall)
                            }

                            BigActionButton(
                                text = filmStrings.submitVerificationButton,
                                icon = Icons.Filled.Verified,
                                onClick = {
                                    onSubmitVerification(
                                        accountType,
                                        orgName,
                                        contactName,
                                        phone,
                                        city,
                                        area,
                                        credits,
                                        idProofType,
                                        idRefMasked,
                                        notes,
                                        noBrokerChecked,
                                        zeroFeeChecked
                                    )
                                },
                                modifier = Modifier.testTag("submit_casting_verify_btn")
                            )
                        }
                    }
                }
            }

            // My Posted Casting Calls
            item {
                Text(
                    text = "${filmStrings.myCastingPostsTitle} (${myPosts.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            if (myPosts.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Filled.Movie, contentDescription = null, tint = SaffronPrimary)
                            Text(filmStrings.noCastingPostsFound, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            } else {
                items(myPosts, key = { it.id }) { post ->
                    val pStatus = post.statusEnum()
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier.testTag("my_casting_post_${post.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(post.roleTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("${post.projectName} • ${post.area}, ${post.city}", style = MaterialTheme.typography.bodySmall)
                                }
                                JobStatusPill(status = pStatus, strings = strings)
                            }
                            Text(
                                text = "₹${post.paymentAmount} ${filmStrings.paymentUnitLabel(post.paymentUnitEnum())} • ${post.shootingDate} • ${post.reportingTime}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val next = if (pStatus == JobStatus.OPEN) JobStatus.CLOSED else JobStatus.OPEN
                                        onTogglePostStatus(post, next)
                                    },
                                    modifier = Modifier.weight(1f).height(48.dp)
                                ) {
                                    Text(if (pStatus == JobStatus.OPEN) strings.closeJob else strings.reopenJob)
                                }
                                OutlinedButton(
                                    onClick = { onDeletePost(post) },
                                    border = BorderStroke(1.dp, CrimsonError),
                                    modifier = Modifier.weight(1f).height(48.dp)
                                ) {
                                    Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = CrimsonError)
                                    Spacer(Modifier.width(4.dp))
                                    Text(strings.deleteJob, color = CrimsonError)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPostSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var projectName by remember { mutableStateOf("") }
        var roleTitle by remember { mutableStateOf("") }
        var artistsNeededText by remember { mutableStateOf("5") }
        var minAgeText by remember { mutableStateOf("18") }
        var maxAgeText by remember { mutableStateOf("45") }
        var genderPref by remember { mutableStateOf(GenderPreference.ANY) }
        var postLanguages by remember { mutableStateOf(listOf("Telugu")) }
        var shootingDate by remember { mutableStateOf("2026-11-30") }
        var reportingTime by remember { mutableStateOf("6:30 AM") }
        var postCity by remember { mutableStateOf(city) }
        var postArea by remember { mutableStateOf(area) }
        var paymentText by remember { mutableStateOf("1500") }
        var paymentUnit by remember { mutableStateOf(PaymentUnit.PER_DAY) }
        var description by remember { mutableStateOf("") }
        var sheetNoBroker by remember { mutableStateOf(true) }
        var sheetZeroFee by remember { mutableStateOf(true) }

        ModalBottomSheet(
            onDismissRequest = { showPostSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(filmStrings.publishCastingTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text(filmStrings.projectNameLabel) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("post_casting_project_input")
                )
                OutlinedTextField(
                    value = roleTitle,
                    onValueChange = { roleTitle = it },
                    label = { Text(filmStrings.roleTitleLabel) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().testTag("post_casting_role_input")
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = artistsNeededText,
                        onValueChange = { artistsNeededText = it.filter { ch -> ch.isDigit() }.take(3) },
                        label = { Text(filmStrings.artistsNeededLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("post_casting_count_input")
                    )
                    OutlinedTextField(
                        value = minAgeText,
                        onValueChange = { minAgeText = it.filter { ch -> ch.isDigit() }.take(2) },
                        label = { Text(filmStrings.minAgeLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("post_casting_min_age_input")
                    )
                    OutlinedTextField(
                        value = maxAgeText,
                        onValueChange = { maxAgeText = it.filter { ch -> ch.isDigit() }.take(3) },
                        label = { Text(filmStrings.maxAgeLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("post_casting_max_age_input")
                    )
                }

                Text(filmStrings.genderPrefLabel, style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GenderPreference.entries.forEach { pref ->
                        FilterChip(
                            selected = genderPref == pref,
                            onClick = { genderPref = pref },
                            label = { Text(filmStrings.genderPrefLabel(pref)) },
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                        )
                    }
                }

                SpokenLanguagesSelector(
                    selectedLanguages = postLanguages,
                    onToggleLanguage = { lang ->
                        postLanguages = if (postLanguages.any { it.equals(lang, ignoreCase = true) }) {
                            if (postLanguages.size > 1) postLanguages.filterNot { it.equals(lang, ignoreCase = true) } else postLanguages
                        } else {
                            postLanguages + lang
                        }
                    },
                    strings = strings
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = shootingDate,
                        onValueChange = { shootingDate = it },
                        label = { Text(filmStrings.shootingDateInputLabel) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("post_casting_date_input")
                    )
                    OutlinedTextField(
                        value = reportingTime,
                        onValueChange = { reportingTime = it },
                        label = { Text(filmStrings.reportingTimeInputLabel) },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("post_casting_time_input")
                    )
                }

                CityAreaPicker(
                    selectedCity = postCity,
                    selectedArea = postArea,
                    onLocationSelected = { c, a ->
                        postCity = c
                        postArea = a
                    },
                    strings = strings,
                    activeLocations = activeLocations
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = paymentText,
                        onValueChange = { paymentText = it.filter { ch -> ch.isDigit() }.take(6) },
                        label = { Text(filmStrings.paymentAmountLabel) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("post_casting_pay_input")
                    )
                }
                Text(filmStrings.paymentUnitLabel, style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PaymentUnit.entries.forEach { unit ->
                        FilterChip(
                            selected = paymentUnit == unit,
                            onClick = { paymentUnit = unit },
                            label = { Text(filmStrings.paymentUnitLabel(unit)) },
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                        )
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(filmStrings.castingDescLabel) },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("post_casting_desc_input")
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = sheetNoBroker, onCheckedChange = { sheetNoBroker = it })
                    Text(filmStrings.noBrokerAttestation, style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = sheetZeroFee, onCheckedChange = { sheetZeroFee = it })
                    Text(filmStrings.zeroFeeAttestation, style = MaterialTheme.typography.bodySmall)
                }

                BigActionButton(
                    text = filmStrings.publishCastingSubmitButton,
                    icon = Icons.AutoMirrored.Filled.Send,
                    onClick = {
                        onPostCasting(
                            projectName,
                            roleTitle,
                            artistsNeededText.toIntOrNull() ?: 5,
                            minAgeText.toIntOrNull() ?: 18,
                            maxAgeText.toIntOrNull() ?: 45,
                            genderPref,
                            postLanguages,
                            shootingDate,
                            reportingTime,
                            postCity,
                            postArea,
                            paymentText.toIntOrNull() ?: 1500,
                            paymentUnit,
                            description,
                            sheetNoBroker,
                            sheetZeroFee
                        )
                        showPostSheet = false
                    },
                    enabled = projectName.trim().length >= 2 && roleTitle.trim().length >= 2 && shootingDate.trim().length >= 6,
                    modifier = Modifier.testTag("publish_casting_submit_btn")
                )
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun CastingApplicantsScreen(
    applications: List<FirestoreCastingApplication>,
    strings: LocalizedStrings,
    filmStrings: FilmLocalizedStrings,
    onUpdateStatus: (FirestoreCastingApplication, CastingApplicationStatus) -> Unit,
    onSubmitReport: (PendingReportTarget, ReportReason, String) -> Unit,
    onBlockArtist: (String, ReportTargetType, String) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pendingReport by remember { mutableStateOf<PendingReportTarget?>(null) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .fillMaxSize()
                .testTag("casting_applicants_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "${filmStrings.navApplicants} (${applications.size})",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }

            if (applications.isEmpty()) {
                item {
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Text(
                            text = strings.noApplicationsYet,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(applications, key = { it.id }) { app ->
                    val status = app.statusEnum()
                    val canDirectContact = status == CastingApplicationStatus.SHORTLISTED || status == CastingApplicationStatus.SELECTED
                    val maskedPhone = if (app.artistPhone.length >= 4) {
                        "••••••${app.artistPhone.takeLast(4)}"
                    } else {
                        "••••••"
                    }

                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("casting_applicant_card_${app.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${app.artistName} (${app.artistAge} yrs)",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        text = "${app.roleTitle} (${app.projectName})",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SaffronPrimary
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        color = when (status) {
                                            CastingApplicationStatus.SELECTED -> EmeraldContainer
                                            CastingApplicationStatus.SHORTLISTED -> TealContainer
                                            CastingApplicationStatus.REJECTED -> CrimsonContainer
                                            CastingApplicationStatus.PENDING -> AmberContainer
                                        },
                                        shape = RoundedCornerShape(50)
                                    ) {
                                        Text(
                                            text = filmStrings.applicationStatusLabel(status),
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            pendingReport = PendingReportTarget(
                                                targetId = app.artistId,
                                                targetType = ReportTargetType.ARTIST_PROFILE,
                                                targetOwnerId = app.artistId,
                                                targetLabel = app.artistName
                                            )
                                        },
                                        modifier = Modifier.testTag("report_applicant_btn_${app.id}")
                                    ) {
                                        Icon(Icons.Filled.Flag, contentDescription = filmStrings.reportButton, tint = CrimsonError)
                                    }
                                    IconButton(
                                        onClick = {
                                            onBlockArtist(
                                                app.artistId,
                                                ReportTargetType.ARTIST_PROFILE,
                                                app.artistName
                                            )
                                        },
                                        modifier = Modifier.testTag("block_applicant_btn_${app.id}")
                                    ) {
                                        Icon(Icons.Filled.Block, contentDescription = filmStrings.blockButton)
                                    }
                                }
                            }

                            Text(
                                text = "${app.artistArea}, ${app.artistCity} • ${app.artistExperienceYears} ${strings.yearsExpShort} • ${app.artistLanguages.joinToString(", ")}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (app.artistBio.isNotBlank()) {
                                Text(app.artistBio, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (app.note.isNotBlank()) {
                                Text("\"${app.note}\"", style = MaterialTheme.typography.bodySmall)
                            }

                            if (app.artistPhotosBase64.isNotEmpty()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    app.artistPhotosBase64.forEachIndexed { idx, encoded ->
                                        val bmp = remember(encoded) { ProfilePhotoHelper.decodeBase64ToBitmap(encoded) }
                                        if (bmp != null) {
                                            Image(
                                                bitmap = bmp.asImageBitmap(),
                                                contentDescription = "${app.artistName} photo ${idx + 1}",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .size(72.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .border(1.dp, SaffronPrimary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                            )
                                        }
                                    }
                                }
                            }

                            // Direct contact for shortlisted/selected; masked privacy while pending
                            if (canDirectContact) {
                                Text(
                                    text = "${filmStrings.directContactSelected} ${app.artistPhone}",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            if (!ContactHelper.dialPhone(context, app.artistPhone)) {
                                                onShowMessage("Dialer not available")
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("contact_selected_artist_call_${app.id}")
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(strings.callEmployer, color = Color.White)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            if (!ContactHelper.openWhatsApp(context, app.artistPhone, "Film Direct Connect: ${app.projectName} (${app.roleTitle})")) {
                                                onShowMessage("WhatsApp not installed")
                                            }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("contact_selected_artist_whatsapp_${app.id}")
                                    ) {
                                        Text(strings.whatsappEmployer)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            if (!ContactHelper.sendSms(context, app.artistPhone, "Film Direct Connect: ${app.projectName} shoot on ${app.shootingDate}")) {
                                                onShowMessage("SMS not available")
                                            }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("contact_selected_artist_sms_${app.id}")
                                    ) {
                                        Text(strings.smsEmployer)
                                    }
                                }
                            } else {
                                Text(
                                    text = "$maskedPhone • ${filmStrings.phoneHiddenUntilShortlist}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (status == CastingApplicationStatus.PENDING || status == CastingApplicationStatus.SHORTLISTED) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (status == CastingApplicationStatus.PENDING) {
                                        OutlinedButton(
                                            onClick = { onUpdateStatus(app, CastingApplicationStatus.SHORTLISTED) },
                                            border = BorderStroke(1.2.dp, TealSecondary),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .testTag("shortlist_applicant_btn_${app.id}")
                                        ) {
                                            Icon(Icons.Filled.Star, contentDescription = null, tint = TealSecondary, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(filmStrings.shortlistButton, color = TealSecondary, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    Button(
                                        onClick = { onUpdateStatus(app, CastingApplicationStatus.SELECTED) },
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("select_applicant_btn_${app.id}")
                                    ) {
                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(filmStrings.selectArtistButton, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(
                                        onClick = { onUpdateStatus(app, CastingApplicationStatus.REJECTED) },
                                        border = BorderStroke(1.2.dp, CrimsonError),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("reject_applicant_btn_${app.id}")
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = null, tint = CrimsonError, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(filmStrings.rejectArtistButton, color = CrimsonError, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingReport?.let { target ->
        FilmSafetyReportDialog(
            target = target,
            filmStrings = filmStrings,
            onDismiss = { pendingReport = null },
            onSubmit = { reason, details ->
                onSubmitReport(target, reason, details)
                pendingReport = null
            }
        )
    }
}
