package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.AppLanguage
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.IndianMobileValidator
import com.example.data.UserRole
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.data.WorkerGender
import com.example.i18n.AppStrings
import com.example.i18n.LocalizedStrings
import com.example.ui.components.BigActionButton
import com.example.ui.components.CityAreaPicker
import com.example.ui.components.GenderSelector
import com.example.ui.components.LanguageSelectorBar
import com.example.ui.components.ListenButton
import com.example.ui.components.MultiSkillSelectorGrid
import com.example.ui.components.ProfilePhotoPickerRow
import com.example.ui.components.SpokenLanguagesSelector
import com.example.ui.components.WorkAvailabilitySelector
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.DailyWorkTheme
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealSecondary
import com.example.ui.viewmodel.LocalMigrationPreview

@Composable
fun GoogleSignInScreen(
    language: AppLanguage,
    strings: LocalizedStrings,
    selectedRole: UserRole = UserRole.WORKER,
    isSigningIn: Boolean,
    authError: String?,
    onLanguageSelected: (AppLanguage) -> Unit,
    onRoleSelected: (UserRole) -> Unit = {},
    onClearError: () -> Unit,
    onSpeak: (String) -> Unit,
    onGoogleSignInClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LanguageSelectorBar(
                currentLanguage = language,
                onLanguageSelected = onLanguageSelected
            )

            // Hero Header Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(190.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_worker_hero),
                        contentDescription = strings.appName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.15f),
                                        Color.Black.copy(alpha = 0.78f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(18.dp)
                    ) {
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White.copy(alpha = 0.94f)
                        )
                    }
                    ListenButton(
                        label = strings.listen,
                        onClick = {
                            onSpeak("${strings.appName}. ${strings.tagline}. ${strings.googleSignInSubtitle}")
                        },
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                    )
                }
            }

            if (authError != null) {
                Surface(
                    onClick = onClearError,
                    color = CrimsonContainer,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = authError,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CrimsonError,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            // Google Sign-In Card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        RoleSelectButton(
                            text = strings.tabWorkerReg,
                            icon = Icons.Filled.Construction,
                            selected = selectedRole != UserRole.EMPLOYER,
                            selectedColor = SaffronPrimary,
                            onClick = {
                                onRoleSelected(UserRole.WORKER)
                                onClearError()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("signin_role_worker_btn")
                        )
                        RoleSelectButton(
                            text = strings.tabEmployerReg,
                            icon = Icons.Filled.BusinessCenter,
                            selected = selectedRole == UserRole.EMPLOYER,
                            selectedColor = TealSecondary,
                            onClick = {
                                onRoleSelected(UserRole.EMPLOYER)
                                onClearError()
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("signin_role_employer_btn")
                        )
                    }

                    Text(
                        text = strings.googleSignInSubtitle,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            onClearError()
                            onGoogleSignInClick()
                        },
                        enabled = !isSigningIn,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .testTag("google_sign_in_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SaffronPrimary,
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
                    ) {
                        if (isSigningIn) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = Color.White,
                                strokeWidth = 2.5.dp
                            )
                            Spacer(Modifier.width(12.dp))
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Login,
                                contentDescription = null,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                        }
                        Text(
                            text = strings.signInWithGoogle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun RoleOnboardingScreen(
    firebaseDisplayName: String,
    firebaseEmail: String?,
    localMigrationPreview: LocalMigrationPreview,
    isAdminUser: Boolean,
    language: AppLanguage,
    strings: LocalizedStrings,
    authError: String?,
    onLanguageSelected: (AppLanguage) -> Unit,
    onClearError: () -> Unit,
    onSpeak: (String) -> Unit,
    onOpenAdminDashboard: () -> Unit,
    onRegisterProfile: (
        name: String,
        phone: String,
        role: UserRole,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int,
        skills: List<WorkCategory>,
        spokenLanguages: List<String>,
        gender: WorkerGender?,
        availabilityStatus: WorkAvailability,
        profilePhotoBase64: String
    ) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier,
    initialPreferredRole: UserRole = UserRole.WORKER,
    activeLocations: List<IndianLocation> = IndianLocations.launchPresets
) {
    val localUser = localMigrationPreview.localUser
    val initialRole = when (localUser?.role) {
        UserRole.EMPLOYER -> UserRole.EMPLOYER
        UserRole.WORKER -> UserRole.WORKER
        else -> if (initialPreferredRole == UserRole.EMPLOYER) UserRole.EMPLOYER else UserRole.WORKER
    }
    val defaultLoc = remember(localUser?.id, activeLocations) {
        val candidate = if (localUser != null) {
            IndianLocations.findActiveLocation(localUser.city, localUser.area, activeLocations)
        } else null
        candidate ?: activeLocations.firstOrNull() ?: IndianLocations.defaultLocation
    }

    var selectedRole by remember(localUser?.id, initialRole) { mutableStateOf(initialRole) }
    // Never auto-fill Google email into the worker's full name field
    var regName by remember(localUser?.id) {
        mutableStateOf(
            localUser?.name?.takeIf { it.isNotBlank() && !it.contains("@") } ?: ""
        )
    }
    var regPhone by remember(localUser?.id) {
        mutableStateOf(IndianMobileValidator.sanitizeInput(localUser?.phone ?: ""))
    }
    var regCity by remember(localUser?.id, defaultLoc.city) { mutableStateOf(defaultLoc.city) }
    var regArea by remember(localUser?.id, defaultLoc.area) { mutableStateOf(defaultLoc.area) }
    var regSkills by remember(localUser?.id) {
        mutableStateOf(listOf(localUser?.primarySkill ?: WorkCategory.MASON))
    }
    var regWage by remember(localUser?.id) {
        mutableIntStateOf(localUser?.expectedDailyWage ?: WorkCategory.MASON.defaultDailyWage)
    }
    var regExp by remember(localUser?.id) { mutableIntStateOf(localUser?.experienceYears ?: 3) }
    var regLanguages by remember(localUser?.id) {
        val defaultLang = when (language) {
            AppLanguage.TELUGU -> listOf("Telugu")
            AppLanguage.HINDI -> listOf("Hindi")
            AppLanguage.ENGLISH -> listOf("Telugu", "English")
        }
        mutableStateOf(defaultLang)
    }
    var regGender by remember(localUser?.id) { mutableStateOf<WorkerGender?>(null) }
    var regAvailability by remember(localUser?.id) { mutableStateOf(WorkAvailability.AVAILABLE_TODAY) }
    var regPhotoBase64 by remember(localUser?.id) { mutableStateOf("") }
    var submitAttempted by remember { mutableStateOf(false) }

    val cleanPhone = IndianMobileValidator.sanitizeInput(regPhone)
    val isNameError = submitAttempted && regName.isBlank()
    val isPhoneInvalid = (submitAttempted || cleanPhone.length == 10) && !IndianMobileValidator.isValid(cleanPhone)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            LanguageSelectorBar(
                currentLanguage = language,
                onLanguageSelected = onLanguageSelected
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.completeProfileTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    if (!firebaseEmail.isNullOrBlank()) {
                        Text(
                            text = firebaseEmail,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                ListenButton(
                    label = strings.listen,
                    onClick = {
                        onSpeak("${strings.completeProfileTitle}. ${strings.tabWorkerReg} or ${strings.tabEmployerReg}.")
                    }
                )
            }

            if (isAdminUser) {
                BigActionButton(
                    text = strings.switchAdminMode,
                    icon = Icons.Filled.AdminPanelSettings,
                    containerColor = Color(0xFF334155),
                    onClick = onOpenAdminDashboard,
                    modifier = Modifier.testTag("onboarding_admin_btn")
                )
            }

            if (localMigrationPreview.hasData) {
                Surface(
                    color = TealContainer,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, TealSecondary.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CloudSync,
                            contentDescription = null,
                            tint = TealSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = strings.migrateLocalBanner,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TealSecondary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Big 2-Way Role Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RoleSelectButton(
                    text = strings.tabWorkerReg,
                    icon = Icons.Filled.Construction,
                    selected = selectedRole == UserRole.WORKER,
                    selectedColor = SaffronPrimary,
                    onClick = {
                        selectedRole = UserRole.WORKER
                        onClearError()
                    },
                    modifier = Modifier.weight(1f).testTag("role_worker_btn")
                )
                RoleSelectButton(
                    text = strings.tabEmployerReg,
                    icon = Icons.Filled.BusinessCenter,
                    selected = selectedRole == UserRole.EMPLOYER,
                    selectedColor = TealSecondary,
                    onClick = {
                        selectedRole = UserRole.EMPLOYER
                        onClearError()
                    },
                    modifier = Modifier.weight(1f).testTag("role_employer_btn")
                )
            }

            if (authError != null) {
                Surface(
                    color = CrimsonContainer,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = authError,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CrimsonError,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }

            val isWorker = selectedRole == UserRole.WORKER
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (isWorker) {
                        ProfilePhotoPickerRow(
                            photoBase64 = regPhotoBase64,
                            name = regName,
                            strings = strings,
                            onPhotoSelected = { regPhotoBase64 = it },
                            onRemovePhoto = { regPhotoBase64 = "" }
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = regName,
                            onValueChange = { regName = it; onClearError() },
                            label = { Text(if (isWorker) strings.nameLabel else strings.employerNameLabel) },
                            placeholder = {
                                Text(
                                    text = strings.fullNamePlaceholder,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                            isError = isNameError,
                            supportingText = if (isNameError) {
                                { Text(strings.enterValidName) }
                            } else null,
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().testTag("reg_name_input")
                        )
                        val cleanDisplayName = firebaseDisplayName.trim()
                        if (regName.isBlank() && cleanDisplayName.isNotBlank() && !cleanDisplayName.contains("@")) {
                            AssistChip(
                                onClick = { regName = cleanDisplayName },
                                label = { Text(cleanDisplayName) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Filled.Person,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("use_google_name_chip")
                            )
                        }
                    }

                    OutlinedTextField(
                        value = regPhone,
                        onValueChange = {
                            regPhone = IndianMobileValidator.sanitizeInput(it)
                            onClearError()
                        },
                        label = { Text(strings.phoneLabel) },
                        prefix = { Text("+91 ") },
                        leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        isError = isPhoneInvalid,
                        supportingText = if (isPhoneInvalid) {
                            { Text(strings.invalidIndianMobileHint, modifier = Modifier.testTag("reg_phone_error")) }
                        } else null,
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("reg_phone_input")
                    )

                    CityAreaPicker(
                        selectedCity = regCity,
                        selectedArea = regArea,
                        onLocationSelected = { c, a ->
                            regCity = c
                            regArea = a
                        },
                        strings = strings,
                        activeLocations = activeLocations
                    )

                    if (isWorker) {
                        Text(
                            text = strings.selectSkillsMulti,
                            style = MaterialTheme.typography.labelLarge
                        )
                        MultiSkillSelectorGrid(
                            selectedSkills = regSkills,
                            onToggleSkill = { clicked ->
                                regSkills = if (regSkills.contains(clicked)) {
                                    if (regSkills.size > 1) regSkills - clicked else regSkills
                                } else {
                                    regSkills + clicked
                                }
                                regWage = regSkills.first().defaultDailyWage
                            },
                            strings = strings
                        )

                        GenderSelector(
                            selectedGender = regGender,
                            onGenderSelected = { regGender = it },
                            strings = strings
                        )

                        SpokenLanguagesSelector(
                            selectedLanguages = regLanguages,
                            onToggleLanguage = { lang ->
                                regLanguages = if (regLanguages.any { it.equals(lang, ignoreCase = true) }) {
                                    regLanguages.filterNot { it.equals(lang, ignoreCase = true) }
                                } else {
                                    regLanguages + lang
                                }
                            },
                            strings = strings
                        )

                        WorkAvailabilitySelector(
                            selected = regAvailability,
                            onSelected = { regAvailability = it },
                            strings = strings
                        )

                        Text(
                            text = "${strings.expectedDailyWage}: ₹$regWage",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(600, 750, 900, 1100).forEach { wagePreset ->
                                FilterChip(
                                    selected = regWage == wagePreset,
                                    onClick = { regWage = wagePreset },
                                    label = { Text("₹$wagePreset") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer
                                    ),
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                )
                            }
                        }

                        Text(
                            text = "${strings.experienceYears}: $regExp",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1, 3, 5, 8).forEach { yrs ->
                                FilterChip(
                                    selected = regExp == yrs,
                                    onClick = { regExp = yrs },
                                    label = { Text("$yrs+") },
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                )
                            }
                        }
                    }

                    BigActionButton(
                        text = if (isWorker) strings.registerWorkerButton else strings.registerEmployerButton,
                        icon = Icons.Filled.PersonAdd,
                        containerColor = if (isWorker) SaffronPrimary else TealSecondary,
                        onClick = {
                            submitAttempted = true
                            val primarySkill = regSkills.firstOrNull() ?: WorkCategory.HELPER
                            onRegisterProfile(
                                regName,
                                cleanPhone,
                                selectedRole,
                                regCity,
                                regArea,
                                primarySkill,
                                regExp,
                                regWage,
                                regSkills,
                                regLanguages,
                                regGender,
                                regAvailability,
                                regPhotoBase64
                            )
                        },
                        modifier = Modifier.testTag("reg_submit_button")
                    )
                }
            }

            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("onboarding_sign_out_btn"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.7f))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = null,
                    tint = CrimsonError
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = strings.logout,
                    color = CrimsonError,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RoleSelectButton(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    selectedColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) selectedColor else selectedColor.copy(alpha = 0.08f),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) selectedColor else selectedColor.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = if (selected) Color.White else selectedColor,
                modifier = Modifier.size(26.dp)
            )
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun GoogleSignInScreenPreview() {
    DailyWorkTheme {
        var lang by remember { mutableStateOf(AppLanguage.ENGLISH) }
        var role by remember { mutableStateOf(UserRole.WORKER) }
        GoogleSignInScreen(
            language = lang,
            strings = AppStrings.get(lang),
            selectedRole = role,
            isSigningIn = false,
            authError = null,
            onLanguageSelected = { lang = it },
            onRoleSelected = { role = it },
            onClearError = {},
            onSpeak = {},
            onGoogleSignInClick = {}
        )
    }
}

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun RoleOnboardingScreenPreview() {
    DailyWorkTheme {
        var lang by remember { mutableStateOf(AppLanguage.ENGLISH) }
        RoleOnboardingScreen(
            firebaseDisplayName = "Ramesh Kumar",
            firebaseEmail = "ramesh@example.com",
            localMigrationPreview = LocalMigrationPreview(),
            isAdminUser = false,
            language = lang,
            strings = AppStrings.get(lang),
            authError = null,
            onLanguageSelected = { lang = it },
            onClearError = {},
            onSpeak = {},
            onOpenAdminDashboard = {},
            onRegisterProfile = { _, _, _, _, _, _, _, _, _, _, _, _, _ -> },
            onSignOut = {}
        )
    }
}
