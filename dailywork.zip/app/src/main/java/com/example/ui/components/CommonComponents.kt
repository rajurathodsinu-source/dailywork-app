package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Carpenter
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Plumbing
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppLanguage
import com.example.data.ApplicationStatus
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.JobStatus
import com.example.data.SpokenLanguages
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.data.WorkerGender
import com.example.i18n.LocalizedStrings
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.OnAmberContainer
import com.example.ui.theme.SaffronContainer
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealContainer
import com.example.ui.theme.TealSecondary
import com.example.util.ProfilePhotoHelper

fun categoryIcon(category: WorkCategory): ImageVector = when (category) {
    WorkCategory.MASON -> Icons.Filled.Construction
    WorkCategory.HELPER -> Icons.Filled.Engineering
    WorkCategory.ELECTRICIAN -> Icons.Filled.ElectricBolt
    WorkCategory.PLUMBER -> Icons.Filled.Plumbing
    WorkCategory.PAINTER -> Icons.Filled.FormatPaint
    WorkCategory.CARPENTER -> Icons.Filled.Carpenter
    WorkCategory.LOADER -> Icons.Filled.LocalShipping
    WorkCategory.FARM_WORKER -> Icons.Filled.Agriculture
    WorkCategory.CLEANER -> Icons.Filled.CleaningServices
    WorkCategory.DRIVER -> Icons.Filled.Build
}

fun categoryTint(category: WorkCategory): Color = when (category) {
    WorkCategory.MASON -> SaffronPrimary
    WorkCategory.HELPER -> AmberTertiary
    WorkCategory.ELECTRICIAN -> Color(0xFF0284C7)
    WorkCategory.PLUMBER -> TealSecondary
    WorkCategory.PAINTER -> Color(0xFF9333EA)
    WorkCategory.CARPENTER -> Color(0xFFB45309)
    WorkCategory.LOADER -> Color(0xFF475569)
    WorkCategory.FARM_WORKER -> EmeraldSuccess
    WorkCategory.CLEANER -> Color(0xFF0D9488)
    WorkCategory.DRIVER -> Color(0xFFDC2626)
}

@Composable
fun LanguageSelectorBar(
    currentLanguage: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Translate,
                contentDescription = "Language",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 6.dp).size(20.dp)
            )
            AppLanguage.entries.forEach { lang ->
                val selected = lang == currentLanguage
                Surface(
                    onClick = { onLanguageSelected(lang) },
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("lang_btn_${lang.code}"),
                    color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = lang.nativeLabel,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ListenButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.Transparent
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("listen_button"),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = containerColor),
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.secondary)
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
            contentDescription = label,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
            maxLines = 1
        )
    }
}

@Composable
fun WageBadge(
    wage: Int,
    perDayText: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = AmberContainer,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, AmberTertiary.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "₹$wage",
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp),
                color = OnAmberContainer,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = perDayText,
                style = MaterialTheme.typography.labelMedium,
                color = OnAmberContainer.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
fun ApplicationStatusPill(
    status: ApplicationStatus,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status) {
        ApplicationStatus.PENDING -> AmberContainer to OnAmberContainer
        ApplicationStatus.ACCEPTED -> EmeraldContainer to EmeraldSuccess
        ApplicationStatus.REJECTED -> CrimsonContainer to CrimsonError
        ApplicationStatus.COMPLETED -> TealContainer to TealSecondary
    }
    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(50)
    ) {
        Text(
            text = strings.applicationStatusText(status),
            style = MaterialTheme.typography.labelMedium,
            color = fg,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun JobStatusPill(
    status: JobStatus,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status) {
        JobStatus.OPEN -> EmeraldContainer to EmeraldSuccess
        JobStatus.FILLED -> AmberContainer to OnAmberContainer
        JobStatus.CLOSED -> CrimsonContainer to CrimsonError
    }
    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(50)
    ) {
        Text(
            text = strings.jobStatusText(status),
            style = MaterialTheme.typography.labelMedium,
            color = fg,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun VerifiedChip(
    verified: Boolean,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = if (verified) TealContainer else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(50)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (verified) Icons.Filled.Verified else Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = if (verified) TealSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(15.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = if (verified) strings.verifiedBadge else strings.unverifiedBadge,
                style = MaterialTheme.typography.labelMedium,
                color = if (verified) TealSecondary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkillSelectorGrid(
    selectedSkill: WorkCategory,
    onSkillSelected: (WorkCategory) -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    FlowRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        maxItemsInEachRow = 2
    ) {
        WorkCategory.entries.forEach { category ->
            val isSelected = category == selectedSkill
            val tint = categoryTint(category)
            Surface(
                onClick = { onSkillSelected(category) },
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag("skill_option_${category.name}"),
                color = if (isSelected) SaffronContainer else MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(tint.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = categoryIcon(category),
                            contentDescription = strings.categoryName(category),
                            tint = tint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = strings.categoryName(category),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileAvatar(
    photoBase64: String,
    name: String,
    size: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    val bitmap = remember(photoBase64) {
        ProfilePhotoHelper.decodeBase64ToBitmap(photoBase64)
    }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = name.ifBlank { "Profile Photo" },
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .border(2.dp, SaffronPrimary.copy(alpha = 0.7f), CircleShape)
        )
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(SaffronContainer)
                .border(1.5.dp, SaffronPrimary.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            val initial = name.trim().firstOrNull()?.uppercaseChar()
            if (initial != null) {
                Text(
                    text = initial.toString(),
                    style = MaterialTheme.typography.titleLarge,
                    color = SaffronPrimary,
                    fontWeight = FontWeight.ExtraBold
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = "Profile Photo",
                    tint = SaffronPrimary,
                    modifier = Modifier.size(size * 0.55f)
                )
            }
        }
    }
}

@Composable
fun ProfilePhotoPickerRow(
    photoBase64: String,
    name: String,
    strings: LocalizedStrings,
    onPhotoSelected: (String) -> Unit,
    onRemovePhoto: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val encoded = ProfilePhotoHelper.encodeUriToBase64(context, uri)
            if (encoded != null) {
                onPhotoSelected(encoded)
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = strings.profilePhotoLabel,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ProfileAvatar(
                photoBase64 = photoBase64,
                name = name,
                size = 64.dp
            )
            OutlinedButton(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("upload_photo_btn"),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    imageVector = Icons.Filled.AddAPhoto,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = if (photoBase64.isNotBlank()) strings.changePhoto else strings.uploadPhoto,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (photoBase64.isNotBlank()) {
                TextButton(
                    onClick = onRemovePhoto,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("remove_photo_btn")
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = strings.removePhoto,
                        tint = CrimsonError,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(strings.removePhoto, color = CrimsonError)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MultiSkillSelectorGrid(
    selectedSkills: List<WorkCategory>,
    onToggleSkill: (WorkCategory) -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    FlowRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        maxItemsInEachRow = 2
    ) {
        WorkCategory.entries.forEach { category ->
            val isSelected = selectedSkills.contains(category)
            val tint = categoryTint(category)
            Surface(
                onClick = { onToggleSkill(category) },
                modifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                    .testTag("multi_skill_${category.name}"),
                color = if (isSelected) SaffronContainer else MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(tint.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = categoryIcon(category),
                            contentDescription = strings.categoryName(category),
                            tint = tint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = strings.categoryName(category),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = SaffronPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SpokenLanguagesSelector(
    selectedLanguages: List<String>,
    onToggleLanguage: (String) -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = strings.spokenLanguagesLabel,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SpokenLanguages.options.forEach { lang ->
                val selected = selectedLanguages.any { it.equals(lang, ignoreCase = true) }
                FilterChip(
                    selected = selected,
                    onClick = { onToggleLanguage(lang) },
                    label = { Text(lang) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TealContainer,
                        selectedLabelColor = TealSecondary
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("spoken_lang_$lang")
                )
            }
        }
    }
}

@Composable
fun GenderSelector(
    selectedGender: WorkerGender?,
    onGenderSelected: (WorkerGender) -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = strings.genderLabel,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            WorkerGender.entries.forEach { gender ->
                val label = when (gender) {
                    WorkerGender.MALE -> strings.genderMale
                    WorkerGender.FEMALE -> strings.genderFemale
                    WorkerGender.OTHER -> strings.genderOther
                }
                FilterChip(
                    selected = selectedGender == gender,
                    onClick = { onGenderSelected(gender) },
                    label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("gender_${gender.name}")
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkAvailabilitySelector(
    selected: WorkAvailability,
    onSelected: (WorkAvailability) -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = strings.workAvailabilityLabel,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            WorkAvailability.entries.forEach { option ->
                val label = when (option) {
                    WorkAvailability.AVAILABLE_TODAY -> strings.availableToday
                    WorkAvailability.AVAILABLE_THIS_WEEK -> strings.availThisWeek
                    WorkAvailability.NOT_AVAILABLE -> strings.notAvailable
                }
                val isSelected = selected == option
                val selectedBg = when (option) {
                    WorkAvailability.AVAILABLE_TODAY -> EmeraldContainer
                    WorkAvailability.AVAILABLE_THIS_WEEK -> TealContainer
                    WorkAvailability.NOT_AVAILABLE -> CrimsonContainer
                }
                val selectedFg = when (option) {
                    WorkAvailability.AVAILABLE_TODAY -> EmeraldSuccess
                    WorkAvailability.AVAILABLE_THIS_WEEK -> TealSecondary
                    WorkAvailability.NOT_AVAILABLE -> CrimsonError
                }
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelected(option) },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = selectedBg,
                        selectedLabelColor = selectedFg
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("availability_${option.name}")
                )
            }
        }
    }
}

@Composable
fun ComingSoonCard(
    outsideLabel: String?,
    strings: LocalizedStrings,
    onSwitchToActiveArea: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    cardTestTag: String = "coming_soon_card"
) {
    val cleanLabel = outsideLabel?.trim().orEmpty()
    val detailText = if (cleanLabel.isNotBlank() && strings.comingSoonOutsideCity.contains("%s")) {
        String.format(strings.comingSoonOutsideCity, cleanLabel)
    } else {
        strings.comingSoonDesc
    }
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag(cardTestTag),
        color = AmberContainer,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.5.dp, AmberTertiary.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(AmberTertiary.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOff,
                        contentDescription = strings.comingSoonTitle,
                        tint = OnAmberContainer,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Text(
                    text = strings.comingSoonTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = OnAmberContainer,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.weight(1f)
                )
            }
            Text(
                text = detailText,
                style = MaterialTheme.typography.bodyMedium,
                color = OnAmberContainer.copy(alpha = 0.92f)
            )
            if (onSwitchToActiveArea != null) {
                OutlinedButton(
                    onClick = onSwitchToActiveArea,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("coming_soon_reset_btn"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, OnAmberContainer.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = OnAmberContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = strings.switchToWarangal,
                        color = OnAmberContainer,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CityAreaPicker(
    selectedCity: String,
    selectedArea: String,
    onLocationSelected: (String, String) -> Unit,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier,
    activeLocations: List<IndianLocation> = IndianLocations.launchPresets
) {
    val activeCities = remember(activeLocations) {
        activeLocations.map { it.city }.distinct().ifEmpty { IndianLocations.launchCities }
    }
    var searchQuery by remember { mutableStateOf("") }
    val searchResults = remember(searchQuery, activeLocations) {
        IndianLocations.searchLocations(searchQuery, activeLocations)
    }
    val outsideMatch = remember(searchQuery, activeLocations) {
        IndianLocations.findOutsideCatalogMatch(searchQuery, activeLocations)
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Surface(
            color = TealContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("service_areas_live_banner")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Public,
                    contentDescription = null,
                    tint = TealSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = String.format(strings.serviceAreasLiveBanner, activeCities.joinToString(", ")),
                    style = MaterialTheme.typography.labelLarge,
                    color = TealSecondary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = {
                Text(
                    text = strings.searchCityAreaHint,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(
                        onClick = { searchQuery = "" },
                        modifier = Modifier.testTag("city_area_search_clear")
                    ) {
                        Icon(Icons.Filled.Clear, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("city_area_search_input")
        )
        Spacer(Modifier.height(10.dp))

        if (searchQuery.isNotBlank()) {
            if (outsideMatch != null || (searchQuery.trim().length >= 3 && searchResults.isEmpty())) {
                ComingSoonCard(
                    outsideLabel = outsideMatch?.city ?: searchQuery.trim(),
                    strings = strings,
                    onSwitchToActiveArea = { searchQuery = "" },
                    cardTestTag = "city_picker_coming_soon"
                )
                Spacer(Modifier.height(8.dp))
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                searchResults.take(12).forEach { loc ->
                    val isLocSelected = loc.city.equals(selectedCity, ignoreCase = true) &&
                        loc.area.equals(selectedArea, ignoreCase = true)
                    FilterChip(
                        selected = isLocSelected,
                        onClick = {
                            onLocationSelected(loc.city, loc.area)
                            searchQuery = ""
                        },
                        label = { Text("${loc.area}, ${loc.city}") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("loc_match_${loc.city}_${loc.area}")
                    )
                }

                val cleanTyped = searchQuery.trim()
                val activeSelectedCity = activeCities.firstOrNull {
                    it.equals(selectedCity, ignoreCase = true)
                } ?: activeCities.first()
                val hasExactArea = searchResults.any {
                    it.area.equals(cleanTyped, ignoreCase = true) &&
                        it.city.equals(activeSelectedCity, ignoreCase = true)
                }
                if (outsideMatch == null && cleanTyped.length >= 2 && !hasExactArea && searchResults.isNotEmpty()) {
                    AssistChip(
                        onClick = {
                            onLocationSelected(activeSelectedCity, cleanTyped)
                            searchQuery = ""
                        },
                        label = { Text("$cleanTyped, $activeSelectedCity") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("custom_area_chip")
                    )
                }
            }
        } else {
            Text(
                text = strings.cityLabel,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                activeCities.forEach { city ->
                    val isSelected = city.equals(selectedCity, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            val firstArea = IndianLocations.areasForCity(city, activeLocations)
                                .firstOrNull()?.area ?: city
                            onLocationSelected(city, firstArea)
                        },
                        label = {
                            Text(
                                text = city,
                                style = MaterialTheme.typography.labelLarge,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("city_chip_$city")
                    )
                }
            }

            val areas = IndianLocations.areasForCity(selectedCity, activeLocations)
            if (areas.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "${strings.areaLabel} ($selectedArea)",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    areas.forEach { loc ->
                        val isAreaSelected = loc.area.equals(selectedArea, ignoreCase = true)
                        FilterChip(
                            selected = isAreaSelected,
                            onClick = { onLocationSelected(loc.city, loc.area) },
                            label = {
                                Text(
                                    text = loc.area,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondary,
                                selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("area_chip_${loc.area}")
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BigActionButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun MealsBadge(text: String) {
    Surface(
        color = EmeraldContainer,
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Restaurant,
                contentDescription = null,
                tint = EmeraldSuccess,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelMedium,
                color = EmeraldSuccess
            )
        }
    }
}

@Composable
fun WageDistributionChart(
    avgWages: Map<WorkCategory, Int>,
    strings: LocalizedStrings,
    modifier: Modifier = Modifier
) {
    val entries = avgWages.entries.sortedByDescending { it.value }.take(6)
    if (entries.isEmpty()) return
    val maxWage = (entries.maxOfOrNull { it.value } ?: 1000).coerceAtLeast(1000)

    Column(modifier = modifier.fillMaxWidth()) {
        entries.forEach { (category, avgWage) ->
            val ratio = (avgWage.toFloat() / maxWage.toFloat()).coerceIn(0.08f, 1f)
            val tint = categoryTint(category)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.categoryName(category),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.width(105.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Canvas(
                    modifier = Modifier
                        .weight(1f)
                        .height(18.dp)
                ) {
                    drawRoundRect(
                        color = tint.copy(alpha = 0.14f),
                        topLeft = Offset.Zero,
                        size = Size(size.width, size.height),
                        cornerRadius = CornerRadius(12f, 12f)
                    )
                    drawRoundRect(
                        color = tint,
                        topLeft = Offset.Zero,
                        size = Size(size.width * ratio, size.height),
                        cornerRadius = CornerRadius(12f, 12f)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "₹$avgWage",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(56.dp)
                )
            }
        }
    }
}
