package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.WorkOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.FirestoreApplication
import com.example.data.FirestoreJob
import com.example.data.FirestoreUser
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import com.example.data.WorkAvailability
import com.example.data.WorkCategory
import com.example.i18n.LocalizedStrings
import com.example.ui.components.ApplicationStatusPill
import com.example.ui.components.BigActionButton
import com.example.ui.components.CityAreaPicker
import com.example.ui.components.ComingSoonCard
import com.example.ui.components.ListenButton
import com.example.ui.components.MealsBadge
import com.example.ui.components.ProfileAvatar
import com.example.ui.components.WageBadge
import com.example.ui.components.categoryIcon
import com.example.ui.components.categoryTint
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.TealSecondary
import com.example.ui.viewmodel.JobWithDistance
import com.example.util.ContactHelper
import com.example.util.GpsDetectionResult
import com.example.util.LocationHelper
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkerJobsScreen(
    worker: FirestoreUser,
    selectedLocation: Pair<String, String>,
    locationQuery: String,
    categoryFilter: WorkCategory?,
    minWageFilter: Int,
    jobs: List<JobWithDistance>,
    strings: LocalizedStrings,
    onToggleAvailability: () -> Unit,
    onLocationQueryChange: (String) -> Unit,
    onLocationPicked: (String, String) -> Unit,
    onCategoryFilterChange: (WorkCategory?) -> Unit,
    onMinWageFilterChange: (Int) -> Unit,
    onApplyJob: (FirestoreJob, String) -> Unit,
    onSpeak: (String) -> Unit,
    onShowMessage: (String) -> Unit,
    modifier: Modifier = Modifier,
    activeLocations: List<IndianLocation> = IndianLocations.launchPresets,
    outsideAreaNotice: String? = null,
    onGpsResult: ((GpsDetectionResult) -> Unit)? = null,
    onDismissOutsideNotice: () -> Unit = {}
) {
    val context = LocalContext.current
    var selectedJobSheet by remember { mutableStateOf<JobWithDistance?>(null) }
    var showLocationPickerSheet by remember { mutableStateOf(false) }

    val activeCities = remember(activeLocations) {
        activeLocations.map { it.city }.distinct().ifEmpty { IndianLocations.launchCities }
    }

    val handleGpsDetection: () -> Unit = {
        val result = LocationHelper.detectServiceLocation(context, activeLocations)
        if (onGpsResult != null) {
            if (result is GpsDetectionResult.Unavailable) {
                onShowMessage(strings.gpsUnavailable)
                showLocationPickerSheet = true
            } else {
                onGpsResult(result)
            }
        } else {
            when (result) {
                is GpsDetectionResult.InsideServiceArea -> {
                    onLocationPicked(result.location.city, result.location.area)
                    onShowMessage("${strings.gpsUpdated}: ${result.location.displayName}")
                }
                is GpsDetectionResult.OutsideServiceArea -> {
                    onShowMessage(strings.gpsOutsideServiceArea)
                }
                GpsDetectionResult.Unavailable -> {
                    onShowMessage(strings.gpsUnavailable)
                    showLocationPickerSheet = true
                }
            }
        }
    }

    val gpsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            handleGpsDetection()
        } else {
            onShowMessage(strings.gpsUnavailable)
            showLocationPickerSheet = true
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .testTag("worker_jobs_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Hero Banner + Availability Toggle
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column {
                        Box(modifier = Modifier.fillMaxWidth().height(120.dp)) {
                            Image(
                                painter = painterResource(id = R.drawable.img_worker_hero),
                                contentDescription = strings.nearbyJobsTitle,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Black.copy(alpha = 0.1f),
                                                Color.Black.copy(alpha = 0.72f)
                                            )
                                        )
                                    )
                            )
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProfileAvatar(
                                    photoBase64 = worker.profilePhotoBase64,
                                    name = worker.name,
                                    size = 48.dp
                                )
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    val skillsText = worker.skillsEnumList().joinToString(", ") { strings.categoryName(it) }
                                    Text(
                                        text = "${worker.name} • $skillsText",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${selectedLocation.second}, ${selectedLocation.first}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.9f)
                                    )
                                }
                            }
                        }
                        Surface(
                            color = if (worker.isAvailable) EmeraldContainer else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val availText = when (worker.availabilityEnum()) {
                                    WorkAvailability.AVAILABLE_TODAY -> strings.availableToday
                                    WorkAvailability.AVAILABLE_THIS_WEEK -> strings.availThisWeek
                                    WorkAvailability.NOT_AVAILABLE -> strings.notAvailable
                                }
                                Text(
                                    text = availText,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (worker.isAvailable) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = worker.isAvailable,
                                    onCheckedChange = { onToggleAvailability() },
                                    modifier = Modifier.testTag("worker_availability_switch")
                                )
                            }
                        }
                    }
                }
            }

            // Location Search + GPS Near Me Button
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = strings.nearbyJobsTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            modifier = Modifier.weight(1f)
                        )
                        FilledNearMeButton(
                            label = strings.nearMeGps,
                            onClick = {
                                val coords = LocationHelper.readLastKnownCoordinates(context)
                                if (coords != null) {
                                    handleGpsDetection()
                                } else {
                                    gpsPermissionLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                                }
                            }
                        )
                    }

                    // Active Service City Switcher Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        activeCities.forEach { city ->
                            val isSelected = city.equals(selectedLocation.first, ignoreCase = true)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    val firstArea = IndianLocations.areasForCity(city, activeLocations)
                                        .firstOrNull()?.area ?: city
                                    onLocationPicked(city, firstArea)
                                },
                                label = { Text(city, fontWeight = FontWeight.SemiBold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("worker_service_city_$city")
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = locationQuery,
                            onValueChange = onLocationQueryChange,
                            placeholder = { Text(strings.searchLocationHint, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            trailingIcon = {
                                if (locationQuery.isNotEmpty()) {
                                    IconButton(onClick = { onLocationQueryChange("") }) {
                                        Icon(Icons.Filled.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.weight(1f).testTag("job_location_search")
                        )
                        Surface(
                            onClick = { showLocationPickerSheet = true },
                            modifier = Modifier
                                .height(54.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("pick_city_btn"),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = strings.cityLabel,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = selectedLocation.first,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                    }
                }
            }

            // Category Filter Chips
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = categoryFilter == null,
                            onClick = { onCategoryFilterChange(null) },
                            label = { Text(strings.allCategories) },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        )
                        WorkCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = categoryFilter == cat,
                                onClick = {
                                    onCategoryFilterChange(if (categoryFilter == cat) null else cat)
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = categoryIcon(cat),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = { Text(strings.categoryName(cat)) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            )
                        }
                    }

                    // Daily Wage Filter Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${strings.minWageLabel}:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        listOf(0, 600, 800, 1000).forEach { wage ->
                            FilterChip(
                                selected = minWageFilter == wage,
                                onClick = { onMinWageFilterChange(wage) },
                                label = {
                                    Text(if (wage == 0) strings.allCategories else "₹$wage+")
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer
                                ),
                                modifier = Modifier.minimumInteractiveComponentSize()
                            )
                        }
                    }
                }
            }

            val computedOutsideNotice = outsideAreaNotice ?: IndianLocations.findOutsideCatalogMatch(
                locationQuery,
                activeLocations
            )?.city

            if (computedOutsideNotice != null) {
                item {
                    ComingSoonCard(
                        outsideLabel = computedOutsideNotice,
                        strings = strings,
                        onSwitchToActiveArea = {
                            onDismissOutsideNotice()
                            onLocationQueryChange("")
                        },
                        cardTestTag = "worker_coming_soon_card"
                    )
                }
            }

            if (jobs.isEmpty()) {
                if (computedOutsideNotice == null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.WorkOutline,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = strings.noJobsFound,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            } else {
                items(jobs, key = { it.job.id }) { item ->
                    WorkerJobCard(
                        item = item,
                        strings = strings,
                        onOpenDetails = { selectedJobSheet = item },
                        onQuickApply = { onApplyJob(item.job, "") },
                        onCallEmployer = {
                            if (!ContactHelper.dialPhone(context, item.job.employerPhone)) {
                                onShowMessage("Phone app unavailable: ${item.job.employerPhone}")
                            }
                        },
                        onSpeak = {
                            val dist = item.distanceKm.roundToInt()
                            onSpeak(
                                "${item.job.title}. ${strings.categoryName(item.job.categoryEnum())}. " +
                                    "${item.job.dailyWage} rupees ${strings.perDay}. " +
                                    "${item.job.area}, ${item.job.city}, $dist ${strings.kmAway}."
                            )
                        }
                    )
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    selectedJobSheet?.let { sheetItem ->
        var applyNote by remember(sheetItem.job.id) { mutableStateOf("") }
        ModalBottomSheet(onDismissRequest = { selectedJobSheet = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = sheetItem.job.title,
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.weight(1f)
                    )
                    WageBadge(wage = sheetItem.job.dailyWage.toInt(), perDayText = strings.perDay)
                }

                Text(
                    text = "${sheetItem.job.employerName} • ${sheetItem.job.area}, ${sheetItem.job.city}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = sheetItem.job.description,
                    style = MaterialTheme.typography.bodyLarge
                )

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("${strings.shiftLabel}: ${sheetItem.job.shiftTiming}", style = MaterialTheme.typography.bodyMedium)
                    Text("${strings.durationLabel}: ${sheetItem.job.workDurationDays} ${strings.daysUnit}", style = MaterialTheme.typography.bodyMedium)
                }
                Text(
                    text = "${strings.workersNeededLabel}: ${sheetItem.job.workersNeeded}",
                    style = MaterialTheme.typography.bodyMedium
                )

                if (sheetItem.applicationStatus == null) {
                    OutlinedTextField(
                        value = applyNote,
                        onValueChange = { applyNote = it },
                        label = { Text(strings.applyNoteHint) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    BigActionButton(
                        text = strings.confirmApply,
                        icon = Icons.Filled.CheckCircle,
                        onClick = {
                            onApplyJob(sheetItem.job, applyNote)
                            selectedJobSheet = null
                        },
                        modifier = Modifier.testTag("confirm_apply_btn")
                    )
                } else {
                    ApplicationStatusPill(status = sheetItem.applicationStatus, strings = strings)
                }

                // Direct Contact Employer Buttons (Call / WhatsApp / SMS)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (!ContactHelper.dialPhone(context, sheetItem.job.employerPhone)) {
                                onShowMessage("Phone app unavailable: ${sheetItem.job.employerPhone}")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TealSecondary),
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.callEmployer, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = {
                            val ok = ContactHelper.openWhatsApp(
                                context,
                                sheetItem.job.employerPhone,
                                "Namaste, I saw your DailyWork job: ${sheetItem.job.title}. My name is ${worker.name}."
                            )
                            if (!ok) {
                                onShowMessage("WhatsApp unavailable. Call: ${sheetItem.job.employerPhone}")
                            }
                        },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.whatsappEmployer, maxLines = 1)
                    }
                    OutlinedButton(
                        onClick = {
                            val ok = ContactHelper.sendSms(
                                context,
                                sheetItem.job.employerPhone,
                                "DailyWork: ${worker.name} (${worker.phone}) interested in ${sheetItem.job.title}."
                            )
                            if (!ok) {
                                onShowMessage("SMS app unavailable. Call: ${sheetItem.job.employerPhone}")
                            }
                        },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Filled.Sms, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(strings.smsEmployer, maxLines = 1)
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
        }
    }

    if (showLocationPickerSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showLocationPickerSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CityAreaPicker(
                    selectedCity = selectedLocation.first,
                    selectedArea = selectedLocation.second,
                    onLocationSelected = { c, a ->
                        onLocationPicked(c, a)
                        showLocationPickerSheet = false
                    },
                    strings = strings,
                    activeLocations = activeLocations
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun FilledNearMeButton(
    label: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("near_me_gps_button"),
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.MyLocation,
                contentDescription = label,
                tint = TealSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = TealSecondary
            )
        }
    }
}

@Composable
private fun WorkerJobCard(
    item: JobWithDistance,
    strings: LocalizedStrings,
    onOpenDetails: () -> Unit,
    onQuickApply: () -> Unit,
    onCallEmployer: () -> Unit,
    onSpeak: () -> Unit
) {
    val job = item.job
    val category = job.categoryEnum()
    val tint = categoryTint(category)
    val distLabel = if (item.distanceKm < 1.0) "< 1 ${strings.kmAway}" else "${item.distanceKm.roundToInt()} ${strings.kmAway}"

    Card(
        onClick = onOpenDetails,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("job_card_${job.id}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(tint.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = categoryIcon(category),
                            contentDescription = strings.categoryName(category),
                            tint = tint,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = job.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${strings.categoryName(category)} • ${job.employerName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                WageBadge(wage = job.dailyWage.toInt(), perDayText = strings.perDay)
            }

            // Location + Distance + Listen Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = SaffronPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${job.area}, ${job.city} • $distLabel",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                ListenButton(label = strings.listen, onClick = onSpeak)
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.AccessTime, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "${job.workDurationDays} ${strings.daysUnit} • ${job.shiftTiming}",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
                if (job.includesMeals) {
                    MealsBadge(strings.mealsIncluded)
                }
            }

            // Big Worker Action Row: APPLY + CALL EMPLOYER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (item.applicationStatus == null) {
                    Button(
                        onClick = onQuickApply,
                        modifier = Modifier
                            .weight(1.2f)
                            .height(50.dp)
                            .testTag("apply_btn_${job.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                    ) {
                        Text(
                            text = strings.applyNow,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Surface(
                        modifier = Modifier.weight(1.2f).height(50.dp),
                        color = EmeraldContainer,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            ApplicationStatusPill(status = item.applicationStatus, strings = strings)
                        }
                    }
                }

                Button(
                    onClick = onCallEmployer,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp)
                        .testTag("call_employer_btn_${job.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TealSecondary)
                ) {
                    Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = strings.callEmployer,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun WorkerApplicationsScreen(
    applications: List<FirestoreApplication>,
    strings: LocalizedStrings,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier,
    onShowMessage: (String) -> Unit = {}
) {
    val context = LocalContext.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            Text(
                text = strings.navMyWork,
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )

            if (applications.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = strings.noApplicationsYet,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(applications, key = { it.id }) { app ->
                        val title = app.jobTitle.ifBlank { strings.categoryName(app.skillEnum()) }
                        val status = app.statusEnum()
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    ApplicationStatusPill(status = status, strings = strings)
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        if (app.employerName.isNotBlank()) {
                                            Text(
                                                text = app.employerName,
                                                style = MaterialTheme.typography.bodyLarge
                                            )
                                        }
                                        val locText = listOf(app.jobArea, app.jobCity)
                                            .filter { it.isNotBlank() }
                                            .joinToString(", ")
                                        if (locText.isNotBlank()) {
                                            Text(
                                                text = locText,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    if (app.dailyWage > 0L) {
                                        WageBadge(wage = app.dailyWage.toInt(), perDayText = strings.perDay)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (app.employerPhone.isNotBlank()) {
                                        Button(
                                            onClick = {
                                                if (!ContactHelper.dialPhone(context, app.employerPhone)) {
                                                    onShowMessage("Phone app unavailable: ${app.employerPhone}")
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = TealSecondary),
                                            modifier = Modifier.weight(1f).height(48.dp),
                                            shape = RoundedCornerShape(14.dp)
                                        ) {
                                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(strings.callEmployer)
                                        }
                                    }
                                    ListenButton(
                                        label = strings.listen,
                                        onClick = {
                                            onSpeak("$title. ${strings.applicationStatusText(status)}. ${app.dailyWage} rupees ${strings.perDay}")
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
