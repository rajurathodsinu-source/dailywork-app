package com.example.i18n

import com.example.data.AppLanguage
import com.example.data.ArtistSkill
import com.example.data.CastingAccountType
import com.example.data.CastingApplicationStatus
import com.example.data.CastingVerificationStatus
import com.example.data.GenderPreference
import com.example.data.PaymentUnit
import com.example.data.ReportReason
import com.example.data.ReportStatus

data class FilmLocalizedStrings(
    val langCode: String,
    val moduleDailyLabour: String,
    val moduleFilmConnect: String,
    val filmConnectTitle: String,
    val filmConnectTagline: String,
    val subRoleArtist: String,
    val subRoleCasting: String,
    val navShootingCalls: String,
    val navArtistProfile: String,
    val navCastingStudio: String,
    val navApplicants: String,
    val navFilmModeration: String,
    val safetyBannerTitle: String,
    val safetyBannerPoints: String,
    val noGuaranteeNotice: String,
    val noBrokerAttestation: String,
    val zeroFeeAttestation: String,
    val privacyNoticePhotosPhone: String,
    val searchRoleHint: String,
    val searchDateHint: String,
    val allCitiesFilter: String,
    val anyDateFilter: String,
    val noCastingPostsFound: String,
    val verifiedOrganizerBadge: String,
    val artistsNeededFormat: String,
    val ageRangeFormat: String,
    val shootDateLabel: String,
    val reportingTimeLabel: String,
    val paymentLabel: String,
    val applyDirectButton: String,
    val appliedDirectLabel: String,
    val createArtistFirstMsg: String,
    val artistProfileTitle: String,
    val editArtistProfileTitle: String,
    val artistNameLabel: String,
    val artistAgeLabel: String,
    val artistBioLabel: String,
    val artistSkillsLabel: String,
    val portfolioPhotosLabel: String,
    val addPhotoCountFormat: String,
    val maxThreePhotosHint: String,
    val saveArtistProfileButton: String,
    val myCastingAppsTitle: String,
    val noCastingAppsYet: String,
    val castingVerificationTitle: String,
    val castingVerificationSubtitle: String,
    val selectAccountTypeLabel: String,
    val organizationNameLabel: String,
    val contactNameLabel: String,
    val projectCreditsLabel: String,
    val idProofTypeLabel: String,
    val idReferenceMaskedLabel: String,
    val verificationNotesLabel: String,
    val submitVerificationButton: String,
    val pendingVerificationTitle: String,
    val pendingVerificationDesc: String,
    val rejectedVerificationTitle: String,
    val verifiedPublishUnlockedDesc: String,
    val postCastingButton: String,
    val publishCastingTitle: String,
    val projectNameLabel: String,
    val roleTitleLabel: String,
    val artistsNeededLabel: String,
    val minAgeLabel: String,
    val maxAgeLabel: String,
    val genderPrefLabel: String,
    val shootingDateInputLabel: String,
    val reportingTimeInputLabel: String,
    val paymentAmountLabel: String,
    val paymentUnitLabel: String,
    val castingDescLabel: String,
    val publishCastingSubmitButton: String,
    val myCastingPostsTitle: String,
    val shortlistButton: String,
    val selectArtistButton: String,
    val rejectArtistButton: String,
    val phoneHiddenUntilShortlist: String,
    val directContactSelected: String,
    val reportButton: String,
    val blockButton: String,
    val reportDialogTitle: String,
    val reportReasonLabel: String,
    val reportDetailsHint: String,
    val submitReportButton: String,
    val reportSubmittedMsg: String,
    val blockedSuccessMsg: String,
    val unblockButton: String,
    val blockedListTitle: String,
    val adminCastingVerifyTitle: String,
    val adminReportsTitle: String,
    val approveVerifyButton: String,
    val rejectVerifyButton: String,
    val rejectReasonHint: String,
    val resolveRemovePostButton: String,
    val resolveSuspendAccountButton: String,
    val dismissReportButton: String,
    val artistProfileSavedMsg: String,
    val castingSubmittedMsg: String,
    val castingPostPublishedMsg: String,
    val artistAppliedSuccessMsg: String,
    val noBrokerErrorMsg: String,
    val invalidAgeErrorMsg: String
) {
    fun accountTypeName(type: CastingAccountType): String = when (langCode) {
        "te" -> when (type) {
            CastingAccountType.FILM_PRODUCER -> "ఫిల్మ్ ప్రొడ్యూసర్"
            CastingAccountType.FILM_DIRECTOR -> "ఫిల్మ్ డైరెక్టర్"
            CastingAccountType.PRODUCTION_HOUSE -> "ప్రొడక్షన్ హౌస్"
            CastingAccountType.CASTING_DIRECTOR -> "కాస్టింగ్ డైరెక్టర్"
            CastingAccountType.ASSISTANT_DIRECTOR -> "అసిస్టెంట్ డైరెక్టర్"
            CastingAccountType.PRODUCTION_MANAGER -> "ప్రొడక్షన్ మేనేజర్"
            CastingAccountType.SHORT_FILM_PRODUCER -> "షార్ట్ ఫిల్మ్ ప్రొడ్యూసర్"
            CastingAccountType.WEB_SERIES_PRODUCER -> "వెబ్ సిరీస్ ప్రొడ్యూసర్"
            CastingAccountType.AD_FILM_MAKER -> "యాడ్ ఫిల్మ్ మేకర్"
        }
        "hi" -> when (type) {
            CastingAccountType.FILM_PRODUCER -> "फिल्म निर्माता"
            CastingAccountType.FILM_DIRECTOR -> "फिल्म निर्देशक"
            CastingAccountType.PRODUCTION_HOUSE -> "प्रोडक्शन हाउस"
            CastingAccountType.CASTING_DIRECTOR -> "कास्टिंग डायरेक्टर"
            CastingAccountType.ASSISTANT_DIRECTOR -> "असिस्टेंट डायरेक्टर"
            CastingAccountType.PRODUCTION_MANAGER -> "प्रोडक्शन मैनेजर"
            CastingAccountType.SHORT_FILM_PRODUCER -> "शॉर्ट फिल्म निर्माता"
            CastingAccountType.WEB_SERIES_PRODUCER -> "वेब सीरीज निर्माता"
            CastingAccountType.AD_FILM_MAKER -> "एड फिल्म मेकर"
        }
        else -> when (type) {
            CastingAccountType.FILM_PRODUCER -> "Film Producer"
            CastingAccountType.FILM_DIRECTOR -> "Film Director"
            CastingAccountType.PRODUCTION_HOUSE -> "Production House"
            CastingAccountType.CASTING_DIRECTOR -> "Casting Director"
            CastingAccountType.ASSISTANT_DIRECTOR -> "Assistant Director"
            CastingAccountType.PRODUCTION_MANAGER -> "Production Manager"
            CastingAccountType.SHORT_FILM_PRODUCER -> "Short Film Producer"
            CastingAccountType.WEB_SERIES_PRODUCER -> "Web Series Producer"
            CastingAccountType.AD_FILM_MAKER -> "Ad Film Maker"
        }
    }

    fun skillName(skill: ArtistSkill): String = when (langCode) {
        "te" -> when (skill) {
            ArtistSkill.JUNIOR_ARTIST -> "జూనియర్ ఆర్టిస్ట్"
            ArtistSkill.SUPPORTING_ROLE -> "సపోర్టింగ్ రోల్"
            ArtistSkill.CROWD_ARTIST -> "క్రౌడ్ ఆర్టిస్ట్"
            ArtistSkill.DANCER -> "డ్యాన్సర్"
            ArtistSkill.STUNT_ACTION -> "స్టంట్ / యాక్షన్"
            ArtistSkill.AD_MODEL -> "యాడ్ మోడల్"
            ArtistSkill.VOICE_DUBBING -> "వాయిస్ / డబ్బింగ్"
            ArtistSkill.FEATURED_EXTRA -> "ఫీచర్డ్ ఎక్స్‌ట్రా"
        }
        "hi" -> when (skill) {
            ArtistSkill.JUNIOR_ARTIST -> "जूनियर आर्टिस्ट"
            ArtistSkill.SUPPORTING_ROLE -> "सपोर्टिंग रोल"
            ArtistSkill.CROWD_ARTIST -> "क्राउड आर्टिस्ट"
            ArtistSkill.DANCER -> "डांसर"
            ArtistSkill.STUNT_ACTION -> "स्टंट / एक्शन"
            ArtistSkill.AD_MODEL -> "एड मॉडल"
            ArtistSkill.VOICE_DUBBING -> "वॉइस / डबिंग"
            ArtistSkill.FEATURED_EXTRA -> "फीचर्ड एक्स्ट्रा"
        }
        else -> when (skill) {
            ArtistSkill.JUNIOR_ARTIST -> "Junior Artist"
            ArtistSkill.SUPPORTING_ROLE -> "Supporting Role"
            ArtistSkill.CROWD_ARTIST -> "Crowd Artist"
            ArtistSkill.DANCER -> "Dancer"
            ArtistSkill.STUNT_ACTION -> "Stunt / Action"
            ArtistSkill.AD_MODEL -> "Ad Film Model"
            ArtistSkill.VOICE_DUBBING -> "Voice / Dubbing"
            ArtistSkill.FEATURED_EXTRA -> "Featured Extra"
        }
    }

    fun paymentUnitLabel(unit: PaymentUnit): String = when (langCode) {
        "te" -> when (unit) {
            PaymentUnit.PER_DAY -> "/ రోజు"
            PaymentUnit.PER_PROJECT -> "/ ప్రాజెక్ట్"
            PaymentUnit.PER_SHIFT -> "/ షిఫ్ట్"
        }
        "hi" -> when (unit) {
            PaymentUnit.PER_DAY -> "/ दिन"
            PaymentUnit.PER_PROJECT -> "/ प्रोजेक्ट"
            PaymentUnit.PER_SHIFT -> "/ शिफ्ट"
        }
        else -> when (unit) {
            PaymentUnit.PER_DAY -> "/ day"
            PaymentUnit.PER_PROJECT -> "/ project"
            PaymentUnit.PER_SHIFT -> "/ shift"
        }
    }

    fun genderPrefLabel(pref: GenderPreference): String = when (langCode) {
        "te" -> when (pref) {
            GenderPreference.ANY -> "ఎవరైనా"
            GenderPreference.MALE -> "పురుషులు"
            GenderPreference.FEMALE -> "మహిళలు"
            GenderPreference.OTHER -> "ఇతర"
        }
        "hi" -> when (pref) {
            GenderPreference.ANY -> "कोई भी"
            GenderPreference.MALE -> "पुरुष"
            GenderPreference.FEMALE -> "महिला"
            GenderPreference.OTHER -> "अन्य"
        }
        else -> when (pref) {
            GenderPreference.ANY -> "Any"
            GenderPreference.MALE -> "Male"
            GenderPreference.FEMALE -> "Female"
            GenderPreference.OTHER -> "Other"
        }
    }

    fun applicationStatusLabel(status: CastingApplicationStatus): String = when (langCode) {
        "te" -> when (status) {
            CastingApplicationStatus.PENDING -> "పెండింగ్"
            CastingApplicationStatus.SHORTLISTED -> "షార్ట్‌లిస్ట్"
            CastingApplicationStatus.SELECTED -> "ఎంపికయ్యారు"
            CastingApplicationStatus.REJECTED -> "తిరస్కరించబడింది"
        }
        "hi" -> when (status) {
            CastingApplicationStatus.PENDING -> "समीक्षा में"
            CastingApplicationStatus.SHORTLISTED -> "शॉर्टलिस्टेड"
            CastingApplicationStatus.SELECTED -> "चयनित"
            CastingApplicationStatus.REJECTED -> "अस्वीकृत"
        }
        else -> when (status) {
            CastingApplicationStatus.PENDING -> "Pending"
            CastingApplicationStatus.SHORTLISTED -> "Shortlisted"
            CastingApplicationStatus.SELECTED -> "Selected"
            CastingApplicationStatus.REJECTED -> "Not Selected"
        }
    }

    fun verificationStatusLabel(status: CastingVerificationStatus): String = when (langCode) {
        "te" -> when (status) {
            CastingVerificationStatus.PENDING -> "పరిశీలనలో ఉంది"
            CastingVerificationStatus.VERIFIED -> "ధృవీకరించబడింది"
            CastingVerificationStatus.REJECTED -> "తిరస్కరించబడింది"
        }
        "hi" -> when (status) {
            CastingVerificationStatus.PENDING -> "जांच लंबित"
            CastingVerificationStatus.VERIFIED -> "सत्यापित"
            CastingVerificationStatus.REJECTED -> "अस्वीकृत"
        }
        else -> when (status) {
            CastingVerificationStatus.PENDING -> "Pending Review"
            CastingVerificationStatus.VERIFIED -> "Verified"
            CastingVerificationStatus.REJECTED -> "Rejected"
        }
    }

    fun reportReasonLabel(reason: ReportReason): String = when (langCode) {
        "te" -> when (reason) {
            ReportReason.BROKER_OR_AGENT -> "బ్రోకర్ / మధ్యవర్తి ఖాతా"
            ReportReason.MONEY_OR_FEE_DEMAND -> "డబ్బు లేదా ఫీజు డిమాండ్"
            ReportReason.FAKE_CASTING -> "నకిలీ కాస్టింగ్ పోస్ట్"
            ReportReason.HARASSMENT -> "వేధింపు లేదా అసభ్య ప్రవర్తన"
            ReportReason.PRIVACY_VIOLATION -> "వ్యక్తిగత ఫోటో / ఫోన్ దుర్వినియోగం"
        }
        "hi" -> when (reason) {
            ReportReason.BROKER_OR_AGENT -> "दलाल / एजेंट खाता"
            ReportReason.MONEY_OR_FEE_DEMAND -> "पैसे या रजिस्ट्रेशन फीस की मांग"
            ReportReason.FAKE_CASTING -> "नकली कास्टिंग कॉल"
            ReportReason.HARASSMENT -> "उत्पीड़न या दुर्व्यवहार"
            ReportReason.PRIVACY_VIOLATION -> "फोटो या मोबाइल नंबर का दुरुपयोग"
        }
        else -> when (reason) {
            ReportReason.BROKER_OR_AGENT -> "Broker / Agent Account"
            ReportReason.MONEY_OR_FEE_DEMAND -> "Demanding Money / Registration Fee"
            ReportReason.FAKE_CASTING -> "Fake or Misleading Casting"
            ReportReason.HARASSMENT -> "Harassment / Unsafe Conduct"
            ReportReason.PRIVACY_VIOLATION -> "Photo or Contact Privacy Abuse"
        }
    }

    fun reportStatusLabel(status: ReportStatus): String = when (langCode) {
        "te" -> when (status) {
            ReportStatus.OPEN -> "తెరిచి ఉంది"
            ReportStatus.RESOLVED -> "పరిష్కరించబడింది"
            ReportStatus.DISMISSED -> "కొట్టివేయబడింది"
        }
        "hi" -> when (status) {
            ReportStatus.OPEN -> "खुला"
            ReportStatus.RESOLVED -> "कार्रवाई पूरी"
            ReportStatus.DISMISSED -> "खारिज"
        }
        else -> when (status) {
            ReportStatus.OPEN -> "Open"
            ReportStatus.RESOLVED -> "Resolved"
            ReportStatus.DISMISSED -> "Dismissed"
        }
    }
}

object FilmStrings {
    fun get(language: AppLanguage): FilmLocalizedStrings = when (language) {
        AppLanguage.ENGLISH -> english
        AppLanguage.TELUGU -> telugu
        AppLanguage.HINDI -> hindi
    }

    private val english = FilmLocalizedStrings(
        langCode = "en",
        moduleDailyLabour = "Daily Labour",
        moduleFilmConnect = "Film Connect",
        filmConnectTitle = "Film Direct Connect",
        filmConnectTagline = "Direct Film & Ad Casting • Zero Brokers • Zero Fees",
        subRoleArtist = "Junior Artist",
        subRoleCasting = "Producer / Casting",
        navShootingCalls = "Shoots",
        navArtistProfile = "My Artist",
        navCastingStudio = "Casting Studio",
        navApplicants = "Applicants",
        navFilmModeration = "Film Admin",
        safetyBannerTitle = "Direct & Safe Casting Rules",
        safetyBannerPoints = "• No brokers or agents allowed\n• ₹0 app commission & ₹0 artist fee\n• Admin verifies casting IDs before posting\n• Selection is not guaranteed",
        noGuaranteeNotice = "Submitting an application connects you directly with verified makers — selection or employment is not guaranteed.",
        noBrokerAttestation = "I confirm I am acting directly (not a broker or middleman agent).",
        zeroFeeAttestation = "I agree there is ₹0 commission and ₹0 registration fee for artists.",
        privacyNoticePhotosPhone = "Your photos & phone stay private and are shared only when you apply to a verified post.",
        searchRoleHint = "Search role or project (e.g. Junior Artist, Ad Shoot)",
        searchDateHint = "Shooting date (e.g. 2026-11-28 or Nov)",
        allCitiesFilter = "All Cities",
        anyDateFilter = "All Dates",
        noCastingPostsFound = "No open verified casting calls match your filters.",
        verifiedOrganizerBadge = "Verified Casting",
        artistsNeededFormat = "%d artists needed",
        ageRangeFormat = "Age %d-%d",
        shootDateLabel = "Shoot Date",
        reportingTimeLabel = "Reporting",
        paymentLabel = "Pay",
        applyDirectButton = "APPLY DIRECTLY",
        appliedDirectLabel = "APPLIED",
        createArtistFirstMsg = "Save your Junior Artist profile & photos below to apply directly to shoots.",
        artistProfileTitle = "Create Junior Artist Profile",
        editArtistProfileTitle = "Edit Junior Artist Profile",
        artistNameLabel = "Artist Full Name",
        artistAgeLabel = "Age (Years)",
        artistBioLabel = "Short Intro / Camera Experience",
        artistSkillsLabel = "Artist Roles & Skills",
        portfolioPhotosLabel = "Artist Photographs (Max 3)",
        addPhotoCountFormat = "Add Photo (%d/3)",
        maxThreePhotosHint = "Pick up to 3 clear photos from your gallery. Never shared publicly.",
        saveArtistProfileButton = "SAVE ARTIST PROFILE",
        myCastingAppsTitle = "My Casting Applications",
        noCastingAppsYet = "No casting applications yet. Browse open shooting calls!",
        castingVerificationTitle = "Production & Casting Verification",
        castingVerificationSubtitle = "Only Producers, Directors, Production Houses, Casting Directors, ADs, Production Managers, Short Film/Web Series Producers & Ad Film Makers may publish casting calls.",
        selectAccountTypeLabel = "Select Verified Filmmaker Role (9 Allowed)",
        organizationNameLabel = "Production Banner / Studio Name",
        contactNameLabel = "Contact Person Name",
        projectCreditsLabel = "Film / Ad Credits or Past Work",
        idProofTypeLabel = "ID Proof Type (e.g. Film Chamber Card / PAN / GST)",
        idReferenceMaskedLabel = "Masked ID Number (e.g. XXXX-4821)",
        verificationNotesLabel = "Notes for Verification Team (optional)",
        submitVerificationButton = "SUBMIT FOR VERIFICATION",
        pendingVerificationTitle = "Verification Under Review",
        pendingVerificationDesc = "Admin is verifying your filmmaker identity. Publishing casting posts unlocks automatically once approved.",
        rejectedVerificationTitle = "Verification Declined",
        verifiedPublishUnlockedDesc = "Identity verified! You can publish direct casting calls and shortlist artists.",
        postCastingButton = "POST CASTING REQUIREMENT",
        publishCastingTitle = "Post Direct Casting Call",
        projectNameLabel = "Project Name (Film / Web Series / Ad)",
        roleTitleLabel = "Role Needed (e.g. College Student / Background)",
        artistsNeededLabel = "No. of Artists Required",
        minAgeLabel = "Min Age",
        maxAgeLabel = "Max Age",
        genderPrefLabel = "Gender Requirement",
        shootingDateInputLabel = "Shooting Date (YYYY-MM-DD)",
        reportingTimeInputLabel = "Reporting Time (e.g. 6:30 AM)",
        paymentAmountLabel = "Payment Amount (₹)",
        paymentUnitLabel = "Payment Unit",
        castingDescLabel = "Costume / Scene Notes (optional)",
        publishCastingSubmitButton = "PUBLISH CASTING CALL",
        myCastingPostsTitle = "Your Casting Calls",
        shortlistButton = "SHORTLIST",
        selectArtistButton = "SELECT",
        rejectArtistButton = "REJECT",
        phoneHiddenUntilShortlist = "Phone hidden until shortlisted/selected",
        directContactSelected = "Selected Artist — Contact Directly:",
        reportButton = "Report",
        blockButton = "Block",
        reportDialogTitle = "Report Safety / Broker Violation",
        reportReasonLabel = "Select Reason",
        reportDetailsHint = "Describe the issue (e.g. broker asking commission or fee)",
        submitReportButton = "SUBMIT REPORT",
        reportSubmittedMsg = "Report sent to Admin moderation queue.",
        blockedSuccessMsg = "Blocked. Content from this account is now hidden.",
        unblockButton = "Unblock",
        blockedListTitle = "Blocked Accounts & Posts",
        adminCastingVerifyTitle = "Casting Identity Verifications",
        adminReportsTitle = "Safety & Broker Reports",
        approveVerifyButton = "VERIFY",
        rejectVerifyButton = "REJECT",
        rejectReasonHint = "Reason (e.g. Invalid ID / Broker suspected)",
        resolveRemovePostButton = "Close Post & Resolve",
        resolveSuspendAccountButton = "Suspend Account & Resolve",
        dismissReportButton = "Dismiss",
        artistProfileSavedMsg = "Junior Artist profile saved!",
        castingSubmittedMsg = "Verification request submitted to Admin!",
        castingPostPublishedMsg = "Verified casting call is now live!",
        artistAppliedSuccessMsg = "Applied directly to production! Track status in My Artist tab.",
        noBrokerErrorMsg = "Please confirm both No Broker/Agent and ₹0 Fee rules.",
        invalidAgeErrorMsg = "Please enter valid age bounds."
    )

    private val telugu = FilmLocalizedStrings(
        langCode = "te",
        moduleDailyLabour = "రోజువారీ పని",
        moduleFilmConnect = "ఫిల్మ్ కనెక్ట్",
        filmConnectTitle = "ఫిల్మ్ డైరెక్ట్ కనెక్ట్",
        filmConnectTagline = "డైరెక్ట్ షూటింగ్ అవకాశాలు • బ్రోకర్లు లేరు • ఫీజు లేదు",
        subRoleArtist = "జూనియర్ ఆర్టిస్ట్",
        subRoleCasting = "ప్రొడ్యూసర్ / కాస్టింగ్",
        navShootingCalls = "షూటింగ్స్",
        navArtistProfile = "నా ఆర్టిస్ట్",
        navCastingStudio = "కాస్టింగ్ స్టూడియో",
        navApplicants = "దరఖాస్తులు",
        navFilmModeration = "ఫిల్మ్ అడ్మిన్",
        safetyBannerTitle = "సురక్షిత కాస్టింగ్ నియమాలు",
        safetyBannerPoints = "• బ్రోకర్లు లేదా ఏజెంట్లకు అనుమతి లేదు\n• ₹0 కమీషన్ & ₹0 ఆర్టిస్ట్ ఫీజు\n• అడ్మిన్ ధృవీకరించిన తర్వాతే కాస్టింగ్ పోస్ట్\n• ఎంపికకు హామీ లేదు",
        noGuaranteeNotice = "దరఖాస్తు చేయడం ద్వారా మీరు నేరుగా ధృవీకరించబడిన మేకర్స్‌కు చేరుతారు — ఉద్యోగ లేదా ఎంపిక హామీ లేదు.",
        noBrokerAttestation = "నేను నేరుగా పనిచేస్తున్నానని (బ్రోకర్/ఏజెంట్ కాదని) ధృవీకరిస్తున్నాను.",
        zeroFeeAttestation = "ఆర్టిస్టులకు ₹0 ఫీజు మరియు ₹0 కమీషన్ నియమానికి అంగీకరిస్తున్నాను.",
        privacyNoticePhotosPhone = "మీ ఫోటోలు & ఫోన్ ప్రైవేట్‌గా ఉంటాయి; మీరు దరఖాస్తు చేసిన ధృవీకరించబడిన పోస్ట్‌కు మాత్రమే కనిపిస్తాయి.",
        searchRoleHint = "పాత్ర లేదా ప్రాజెక్ట్ వెతకండి (ఉదా: జూనియర్ ఆర్టిస్ట్)",
        searchDateHint = "షూటింగ్ తేదీ (ఉదా: 2026-11-28)",
        allCitiesFilter = "అన్ని నగరాలు",
        anyDateFilter = "అన్ని తేదీలు",
        noCastingPostsFound = "ప్రస్తుతం మీ ఫిల్టర్లకు సరిపోలే ధృవీకరించబడిన కాస్టింగ్ పోస్టులు లేవు.",
        verifiedOrganizerBadge = "ధృవీకరించబడిన కాస్టింగ్",
        artistsNeededFormat = "%d మంది ఆర్టిస్టులు కావాలి",
        ageRangeFormat = "వయసు %d-%d",
        shootDateLabel = "షూట్ తేదీ",
        reportingTimeLabel = "రిపోర్టింగ్",
        paymentLabel = "పేమెంట్",
        applyDirectButton = "నేరుగా దరఖాస్తు చేయండి",
        appliedDirectLabel = "దరఖాస్తు అయింది",
        createArtistFirstMsg = "దరఖాస్తు చేయడానికి ముందుగా మీ జూనియర్ ఆర్టిస్ట్ ప్రొఫైల్ & ఫోటోలను సేవ్ చేయండి.",
        artistProfileTitle = "జూనియర్ ఆర్టిస్ట్ ప్రొఫైల్",
        editArtistProfileTitle = "ఆర్టిస్ట్ ప్రొఫైల్ మార్చండి",
        artistNameLabel = "ఆర్టిస్ట్ పూర్తి పేరు",
        artistAgeLabel = "వయసు (సంవత్సరాలు)",
        artistBioLabel = "పరిచయం / అనుభవం వివరాలు",
        artistSkillsLabel = "నటన / పాత్ర నైపుణ్యాలు",
        portfolioPhotosLabel = "ఆర్టిస్ట్ ఫోటోలు (గరిష్టం 3)",
        addPhotoCountFormat = "ఫోటో జతచేయండి (%d/3)",
        maxThreePhotosHint = "గ్యాలరీ నుండి గరిష్టంగా 3 స్పష్టమైన ఫోటోలు ఎంచుకోండి.",
        saveArtistProfileButton = "ఆర్టిస్ట్ ప్రొఫైల్ సేవ్ చేయండి",
        myCastingAppsTitle = "నా కాస్టింగ్ దరఖాస్తులు",
        noCastingAppsYet = "ఇంకా కాస్టింగ్ దరఖాస్తులు లేవు. షూటింగ్ కాల్స్ చూడండి!",
        castingVerificationTitle = "ప్రొడక్షన్ & కాస్టింగ్ ధృవీకరణ",
        castingVerificationSubtitle = "ప్రొడ్యూసర్, డైరెక్టర్, ప్రొడక్షన్ హౌస్, కాస్టింగ్ డైరెక్టర్, AD, ప్రొడక్షన్ మేనేజర్, షార్ట్ ఫిల్మ్ / వెబ్ సిరీస్ & యాడ్ ఫిల్మ్ మేకర్స్ మాత్రమే పోస్ట్ చేయగలరు.",
        selectAccountTypeLabel = "మీ ఫిల్మ్ పాత్రను ఎంచుకోండి (9 మాత్రమే)",
        organizationNameLabel = "ప్రొడక్షన్ బ్యానర్ / స్టూడియో పేరు",
        contactNameLabel = "సంప్రదించే వ్యక్తి పేరు",
        projectCreditsLabel = "పాత సినిమాలు / యాడ్ వర్క్ వివరాలు",
        idProofTypeLabel = "గుర్తింపు పత్రం రకం (Film Chamber / PAN / GST)",
        idReferenceMaskedLabel = "మాస్క్ చేసిన ID నంబర్ (ఉదా: XXXX-4821)",
        verificationNotesLabel = "అడ్మిన్ కోసం అదనపు వివరాలు (ఐచ్ఛికం)",
        submitVerificationButton = "ధృవీకరణ కోసం పంపండి",
        pendingVerificationTitle = "ధృవీకరణ పరిశీలనలో ఉంది",
        pendingVerificationDesc = "అడ్మిన్ మీ వివరాలు పరిశీలిస్తున్నారు. ఆమోదం తర్వాత మీరు కాస్టింగ్ పోస్ట్ చేయగలరు.",
        rejectedVerificationTitle = "ధృవీకరణ తిరస్కరించబడింది",
        verifiedPublishUnlockedDesc = "మీ ఖాతా ధృవీకరించబడింది! ఇప్పుడు మీరు నేరుగా కాస్టింగ్ కాల్స్ పోస్ట్ చేయవచ్చు.",
        postCastingButton = "కొత్త కాస్టింగ్ అవసరం పోస్ట్ చేయండి",
        publishCastingTitle = "నేరుగా కాస్టింగ్ పోస్ట్ చేయండి",
        projectNameLabel = "ప్రాజెక్ట్ పేరు (సినిమా / వెబ్ సిరీస్ / యాడ్)",
        roleTitleLabel = "కావలసిన పాత్ర (ఉదా: కాలేజ్ స్టూడెంట్)",
        artistsNeededLabel = "కావలసిన ఆర్టిస్టుల సంఖ్య",
        minAgeLabel = "కనీస వయసు",
        maxAgeLabel = "గరిష్ట వయసు",
        genderPrefLabel = "లింగ అవసరం",
        shootingDateInputLabel = "షూటింగ్ తేదీ (YYYY-MM-DD)",
        reportingTimeInputLabel = "రిపోర్టింగ్ సమయం (ఉదా: 6:30 AM)",
        paymentAmountLabel = "పేమెంట్ మొత్తం (₹)",
        paymentUnitLabel = "పేమెంట్ విధానం",
        castingDescLabel = "కాస్ట్యూమ్ / సీన్ వివరాలు (ఐచ్ఛికం)",
        publishCastingSubmitButton = "కాస్టింగ్ కాల్ ప్రచురించండి",
        myCastingPostsTitle = "మీరు పోస్ట్ చేసిన కాస్టింగ్ కాల్స్",
        shortlistButton = "షార్ట్‌లిస్ట్",
        selectArtistButton = "ఎంపిక చేయి",
        rejectArtistButton = "తిరస్కరించు",
        phoneHiddenUntilShortlist = "షార్ట్‌లిస్ట్ / ఎంపిక తర్వాత ఫోన్ కనిపిస్తుంది",
        directContactSelected = "ఎంపికైన ఆర్టిస్ట్ — నేరుగా సంప్రదించండి:",
        reportButton = "రిపోర్ట్",
        blockButton = "బ్లాక్",
        reportDialogTitle = "భద్రత / బ్రోకర్ రిపోర్ట్ చేయండి",
        reportReasonLabel = "కారణం ఎంచుకోండి",
        reportDetailsHint = "సమస్య వివరాలు రాయండి (ఉదా: డబ్బు అడగడం లేదా బ్రోకర్)",
        submitReportButton = "రిపోర్ట్ పంపండి",
        reportSubmittedMsg = "రిపోర్ట్ అడ్మిన్‌కు పంపబడింది.",
        blockedSuccessMsg = "బ్లాక్ చేయబడింది. వీరి పోస్టులు ఇకపై కనిపించవు.",
        unblockButton = "అన్‌బ్లాక్",
        blockedListTitle = "బ్లాక్ చేసిన ఖాతాలు",
        adminCastingVerifyTitle = "కాస్టింగ్ ఖాతాల ధృవీకరణ",
        adminReportsTitle = "భద్రత & బ్రోకర్ రిపోర్టులు",
        approveVerifyButton = "ధృవీకరించు",
        rejectVerifyButton = "తిరస్కరించు",
        rejectReasonHint = "తిరస్కరణ కారణం రాయండి",
        resolveRemovePostButton = "పోస్ట్ మూసివేసి పరిష్కరించు",
        resolveSuspendAccountButton = "ఖాతా సస్పెండ్ చేయి",
        dismissReportButton = "కొట్టివేయి",
        artistProfileSavedMsg = "జూనియర్ ఆర్టిస్ట్ ప్రొఫైల్ సేవ్ అయింది!",
        castingSubmittedMsg = "ధృవీకరణ అభ్యర్థన అడ్మిన్‌కు పంపబడింది!",
        castingPostPublishedMsg = "కాస్టింగ్ కాల్ లైవ్ అయింది!",
        artistAppliedSuccessMsg = "నేరుగా దరఖాస్తు పంపబడింది! నా ఆర్టిస్ట్ ట్యాబ్‌లో స్థితి చూడండి.",
        noBrokerErrorMsg = "బ్రోకర్ రహిత & ₹0 ఫీజు నియమాలను నిర్ధారించండి.",
        invalidAgeErrorMsg = "దయచేసి సరైన వయసు పరిధి ఇవ్వండి."
    )

    private val hindi = FilmLocalizedStrings(
        langCode = "hi",
        moduleDailyLabour = "दैनिक मज़दूरी",
        moduleFilmConnect = "फिल्म कनेक्ट",
        filmConnectTitle = "फिल्म डायरेक्ट कनेक्ट",
        filmConnectTagline = "सीधे शूटिंग अवसर • कोई दलाल नहीं • कोई फीस नहीं",
        subRoleArtist = "जूनियर आर्टिस्ट",
        subRoleCasting = "निर्माता / कास्टिंग",
        navShootingCalls = "शूटिंग",
        navArtistProfile = "मेरा आर्टिस्ट",
        navCastingStudio = "कास्टिंग स्टूडियो",
        navApplicants = "आवेदक",
        navFilmModeration = "फिल्म एडमिन",
        safetyBannerTitle = "सुरक्षित और सीधी कास्टिंग के नियम",
        safetyBannerPoints = "• किसी दलाल या एजेंट को अनुमति नहीं\n• ₹0 ऐप कमीशन और ₹0 आर्टिस्ट फीस\n• पोस्ट से पहले एडमिन पहचान सत्यापित करता है\n• चयन की कोई गारंटी नहीं",
        noGuaranteeNotice = "आवेदन करने से आप सीधे सत्यापित निर्माताओं से जुड़ते हैं — चयन या काम की गारंटी नहीं है।",
        noBrokerAttestation = "मैं पुष्टि करता/करती हूँ कि मैं सीधे काम कर रहा/रही हूँ (कोई दलाल या एजेंट नहीं)।",
        zeroFeeAttestation = "मैं सहमत हूँ कि आर्टिस्ट के लिए ₹0 फीस और ₹0 कमीशन है।",
        privacyNoticePhotosPhone = "आपकी फोटो और मोबाइल नंबर सुरक्षित रहते हैं; केवल आवेदन किए गए सत्यापित पोस्ट को दिखते हैं।",
        searchRoleHint = "रोल या प्रोजेक्ट खोजें (जैसे जूनियर आर्टिस्ट)",
        searchDateHint = "शूटिंग तारीख (जैसे 2026-11-28)",
        allCitiesFilter = "सभी शहर",
        anyDateFilter = "सभी तारीखें",
        noCastingPostsFound = "आपके फ़िल्टर से मेल खाती कोई सत्यापित कास्टिंग कॉल नहीं मिली।",
        verifiedOrganizerBadge = "सत्यापित कास्टिंग",
        artistsNeededFormat = "%d आर्टिस्ट चाहिए",
        ageRangeFormat = "उम्र %d-%d",
        shootDateLabel = "शूट तारीख",
        reportingTimeLabel = "रिपोर्टिंग",
        paymentLabel = "भुगतान",
        applyDirectButton = "सीधा आवेदन करें",
        appliedDirectLabel = "आवेदन किया",
        createArtistFirstMsg = "शूटिंग पर सीधे आवेदन करने के लिए पहले नीचे अपना जूनियर आर्टिस्ट प्रोफ़ाइल और फोटो सेव करें।",
        artistProfileTitle = "जूनियर आर्टिस्ट प्रोफ़ाइल बनाएं",
        editArtistProfileTitle = "आर्टिस्ट प्रोफ़ाइल बदलें",
        artistNameLabel = "आर्टिस्ट का पूरा नाम",
        artistAgeLabel = "उम्र (साल)",
        artistBioLabel = "परिचय / कैमरा अनुभव",
        artistSkillsLabel = "कलाकार कौशल और भूमिकाएं",
        portfolioPhotosLabel = "आर्टिस्ट फोटो (अधिकतम 3)",
        addPhotoCountFormat = "फोटो जोड़ें (%d/3)",
        maxThreePhotosHint = "गैलरी से अधिकतम 3 साफ फोटो चुनें। ये सार्वजनिक नहीं दिखेंगी।",
        saveArtistProfileButton = "आर्टिस्ट प्रोफ़ाइल सेव करें",
        myCastingAppsTitle = "मेरे कास्टिंग आवेदन",
        noCastingAppsYet = "अभी कोई कास्टिंग आवेदन नहीं है। खुली शूटिंग कॉल देखें!",
        castingVerificationTitle = "प्रोडक्शन और कास्टिंग पहचान सत्यापन",
        castingVerificationSubtitle = "केवल फिल्म निर्माता, निर्देशक, प्रोडक्शन हाउस, कास्टिंग डायरेक्टर, AD, प्रोडक्शन मैनेजर, शॉर्ट फिल्म/वेब सीरीज और एड फिल्म मेकर ही पोस्ट कर सकते हैं।",
        selectAccountTypeLabel = "अपनी फिल्म भूमिका चुनें (केवल 9 मान्य)",
        organizationNameLabel = "प्रोडक्शन बैनर / स्टूडियो नाम",
        contactNameLabel = "संपर्क व्यक्ति का नाम",
        projectCreditsLabel = "पिछली फिल्म / एड प्रोजेक्ट जानकारी",
        idProofTypeLabel = "आईडी प्रमाण प्रकार (Film Chamber / PAN / GST)",
        idReferenceMaskedLabel = "मास्क किया गया आईडी नंबर (जैसे XXXX-4821)",
        verificationNotesLabel = "एडमिन टीम के लिए नोट (वैकल्पिक)",
        submitVerificationButton = "सत्यापन के लिए भेजें",
        pendingVerificationTitle = "सत्यापन जांच में है",
        pendingVerificationDesc = "एडमिन आपकी पहचान जांच रहा है। मंजूरी के बाद ही आप कास्टिंग पोस्ट कर पाएंगे।",
        rejectedVerificationTitle = "सत्यापन अस्वीकार किया गया",
        verifiedPublishUnlockedDesc = "पहचान सत्यापित! अब आप सीधी कास्टिंग कॉल पोस्ट कर सकते हैं और कलाकार चुन सकते हैं।",
        postCastingButton = "नई कास्टिंग आवश्यकता पोस्ट करें",
        publishCastingTitle = "सीधी कास्टिंग कॉल पोस्ट करें",
        projectNameLabel = "प्रोजेक्ट का नाम (फिल्म / वेब सीरीज / एड)",
        roleTitleLabel = "आवश्यक रोल (जैसे कॉलेज छात्र)",
        artistsNeededLabel = "कितने आर्टिस्ट चाहिए",
        minAgeLabel = "न्यूनतम उम्र",
        maxAgeLabel = "अधिकतम उम्र",
        genderPrefLabel = "लिंग आवश्यकता",
        shootingDateInputLabel = "शूटिंग तारीख (YYYY-MM-DD)",
        reportingTimeInputLabel = "रिपोर्टिंग समय (जैसे 6:30 AM)",
        paymentAmountLabel = "भुगतान राशि (₹)",
        paymentUnitLabel = "भुगतान प्रकार",
        castingDescLabel = "कपड़े / सीन जानकारी (वैकल्पिक)",
        publishCastingSubmitButton = "कास्टिंग कॉल प्रकाशित करें",
        myCastingPostsTitle = "आपकी पोस्ट की गई कास्टिंग कॉल",
        shortlistButton = "शॉर्टलिस्ट",
        selectArtistButton = "चुनें",
        rejectArtistButton = "अस्वीकार",
        phoneHiddenUntilShortlist = "शॉर्टलिस्ट/चयन तक फ़ोन नंबर छिपा है",
        directContactSelected = "चयनित आर्टिस्ट — सीधा संपर्क करें:",
        reportButton = "रिपोर्ट",
        blockButton = "ब्लॉक",
        reportDialogTitle = "सुरक्षा / दलाल उल्लंघन रिपोर्ट करें",
        reportReasonLabel = "कारण चुनें",
        reportDetailsHint = "समस्या लिखें (जैसे पैसे मांगना या दलाल होना)",
        submitReportButton = "रिपोर्ट भेजें",
        reportSubmittedMsg = "रिपोर्ट एडमिन मॉडरेशन को भेज दी गई है।",
        blockedSuccessMsg = "ब्लॉक किया गया। इस खाते की पोस्ट अब छिपी रहेंगी।",
        unblockButton = "अनब्लॉक",
        blockedListTitle = "ब्लॉक किए गए खाते और पोस्ट",
        adminCastingVerifyTitle = "कास्टिंग पहचान सत्यापन",
        adminReportsTitle = "सुरक्षा और दलाल रिपोर्ट",
        approveVerifyButton = "सत्यापित करें",
        rejectVerifyButton = "अस्वीकार करें",
        rejectReasonHint = "अस्वीकार करने का कारण लिखें",
        resolveRemovePostButton = "पोस्ट बंद करें और हल करें",
        resolveSuspendAccountButton = "खाता निलंबित करें",
        dismissReportButton = "खारिज करें",
        artistProfileSavedMsg = "जूनियर आर्टिस्ट प्रोफ़ाइल सेव हो गई!",
        castingSubmittedMsg = "सत्यापन अनुरोध एडमिन को भेजा गया!",
        castingPostPublishedMsg = "कास्टिंग कॉल अब लाइव है!",
        artistAppliedSuccessMsg = "सीधे आवेदन भेजा गया! मेरा आर्टिस्ट टैब में स्थिति देखें।",
        noBrokerErrorMsg = "कृपया नो-ब्रोकर और ₹0 फीस दोनों नियमों की पुष्टि करें।",
        invalidAgeErrorMsg = "कृपया सही उम्र सीमा लिखें।"
    )
}
