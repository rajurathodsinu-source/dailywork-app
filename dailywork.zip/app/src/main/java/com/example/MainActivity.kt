package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.AppLanguage
import com.example.data.AppModule
import com.example.data.DailyWorkDatabase
import com.example.data.FirestoreRepository
import com.example.data.FirestoreUser
import com.example.data.SessionPreferences
import com.example.data.UserRole
import com.example.i18n.AppStrings
import com.example.i18n.FilmStrings
import com.example.ui.screens.AdminFilmModerationScreen
import com.example.ui.screens.AdminJobsAndBroadcastScreen
import com.example.ui.screens.AdminOverviewScreen
import com.example.ui.screens.AdminServiceAreasScreen
import com.example.ui.screens.AdminUsersScreen
import com.example.ui.screens.ArtistProfileAndAppsScreen
import com.example.ui.screens.CastingApplicantsScreen
import com.example.ui.screens.CastingStudioScreen
import com.example.ui.screens.EmployerApplicationsScreen
import com.example.ui.screens.EmployerHomeScreen
import com.example.ui.screens.EmployerWorkersScreen
import com.example.ui.screens.FilmShootingCallsScreen
import com.example.ui.screens.GoogleSignInScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RoleOnboardingScreen
import com.example.ui.screens.WorkerApplicationsScreen
import com.example.ui.screens.WorkerJobsScreen
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.DailyWorkTheme
import com.example.ui.theme.SaffronPrimary
import com.example.ui.viewmodel.DailyWorkViewModel
import com.example.ui.viewmodel.ProfileUiState
import com.example.util.GoogleAuthHelper
import com.example.util.VoiceAssistant
import com.example.util.authStateFlow
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DailyWorkTheme {
                DailyWorkApp()
            }
        }
    }
}

private data class NavTab(
    val label: String,
    val icon: ImageVector,
    val badgeCount: Int = 0,
    val tag: String
)

@Composable
fun DailyWorkApp() {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val prefs = remember(appContext) { SessionPreferences(appContext) }
    val signedOutSnackbarHostState = remember { SnackbarHostState() }

    var activeSpeechFeedback by remember {
        mutableStateOf<(String) -> Unit>({ spoken ->
            scope.launch {
                signedOutSnackbarHostState.currentSnackbarData?.dismiss()
                signedOutSnackbarHostState.showSnackbar(spoken)
            }
        })
    }
    val currentSpeechFeedback by rememberUpdatedState(activeSpeechFeedback)

    val voiceAssistant = remember(appContext) {
        VoiceAssistant(appContext) { spokenText ->
            currentSpeechFeedback(spokenText)
        }
    }
    DisposableEffect(voiceAssistant) {
        onDispose { voiceAssistant.shutdown() }
    }

    val storedLanguage by prefs.languageFlow.collectAsStateWithLifecycle(initialValue = AppLanguage.ENGLISH)
    var currentLanguage by remember { mutableStateOf(storedLanguage) }
    LaunchedEffect(storedLanguage) {
        currentLanguage = storedLanguage
    }
    val strings = remember(currentLanguage) { AppStrings.get(currentLanguage) }

    val storedPreferredRole by prefs.preferredRoleFlow.collectAsStateWithLifecycle(initialValue = UserRole.WORKER)
    var preferredRole by remember { mutableStateOf(storedPreferredRole) }
    LaunchedEffect(storedPreferredRole) {
        preferredRole = storedPreferredRole
    }

    val authUserFlow = remember { Firebase.auth.authStateFlow() }
    val firebaseUser by authUserFlow.collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    var autoSignInAttempted by remember { mutableStateOf(false) }
    var isSigningIn by remember { mutableStateOf(false) }
    var signInError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (!autoSignInAttempted && Firebase.auth.currentUser == null) {
            autoSignInAttempted = true
            GoogleAuthHelper.attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = { isSigningIn = false },
                onUnauthenticated = { isSigningIn = false },
                scope = scope
            )
        }
    }

    val user = firebaseUser
    if (user == null) {
        SideEffect {
            activeSpeechFeedback = { spoken ->
                scope.launch {
                    signedOutSnackbarHostState.currentSnackbarData?.dismiss()
                    signedOutSnackbarHostState.showSnackbar(spoken)
                }
            }
        }
        Scaffold(
            snackbarHost = { SnackbarHost(signedOutSnackbarHostState) },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            GoogleSignInScreen(
                language = currentLanguage,
                strings = strings,
                selectedRole = preferredRole,
                isSigningIn = isSigningIn,
                authError = signInError,
                onLanguageSelected = { lang ->
                    currentLanguage = lang
                    scope.launch { prefs.setLanguage(lang) }
                },
                onRoleSelected = { role ->
                    preferredRole = role
                    scope.launch { prefs.setPreferredRole(role) }
                },
                onClearError = { signInError = null },
                onSpeak = { text -> voiceAssistant.speak(text, currentLanguage) },
                onGoogleSignInClick = {
                    isSigningIn = true
                    signInError = null
                    GoogleAuthHelper.onGoogleSignInClicked(
                        context = context,
                        credentialManager = credentialManager,
                        onAuthSuccess = { isSigningIn = false },
                        onAuthError = { msg ->
                            isSigningIn = false
                            signInError = msg
                        },
                        onAuthCancelled = {
                            isSigningIn = false
                            scope.launch {
                                signedOutSnackbarHostState.currentSnackbarData?.dismiss()
                                signedOutSnackbarHostState.showSnackbar(
                                    "Google Sign-In cancelled or no Google account selected on device."
                                )
                            }
                        },
                        scope = scope
                    )
                },
                modifier = Modifier.padding(innerPadding)
            )
        }
    } else {
        key(user.uid) {
            SignedInDailyWorkFlow(
                firebaseUser = user,
                credentialManager = credentialManager,
                prefs = prefs,
                voiceAssistant = voiceAssistant,
                initialPreferredRole = preferredRole,
                onRegisterSpeechFeedback = { sink -> activeSpeechFeedback = sink }
            )
        }
    }
}

@Composable
private fun SignedInDailyWorkFlow(
    firebaseUser: FirebaseUser,
    credentialManager: CredentialManager,
    prefs: SessionPreferences,
    voiceAssistant: VoiceAssistant,
    initialPreferredRole: UserRole,
    onRegisterSpeechFeedback: ((String) -> Unit) -> Unit
) {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()

    val viewModel: DailyWorkViewModel = viewModel(
        key = firebaseUser.uid,
        factory = viewModelFactory {
            initializer {
                DailyWorkViewModel(
                    firestoreRepo = FirestoreRepository(appContext),
                    localDb = DailyWorkDatabase.getInstance(appContext),
                    prefs = prefs,
                    currentUserId = firebaseUser.uid,
                    currentUserEmail = firebaseUser.email,
                    isEmailVerified = firebaseUser.isEmailVerified,
                    appContext = appContext
                )
            }
        }
    )

    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val strings = remember(language) { AppStrings.get(language) }
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationCount.collectAsStateWithLifecycle()
    val isAdminUser by viewModel.isAdminUser.collectAsStateWithLifecycle()
    val adminModeEnabled by viewModel.adminModeEnabled.collectAsStateWithLifecycle()
    val localMigrationPreview by viewModel.localMigrationPreview.collectAsStateWithLifecycle()
    val activeLocations by viewModel.activeLocations.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    SideEffect {
        onRegisterSpeechFeedback { spoken -> viewModel.showMessage(spoken) }
    }
    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(profileState) {
        if (profileState is ProfileUiState.Ready && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val performSignOut: () -> Unit = {
        viewModel.toggleAdminMode(false)
        GoogleAuthHelper.signOut(credentialManager, scope)
    }

    if (isAdminUser && adminModeEnabled) {
        val currentProfile = (profileState as? ProfileUiState.Ready)?.user
        AuthenticatedShell(
            user = currentProfile,
            userEmail = firebaseUser.email,
            isAdminUser = true,
            adminModeEnabled = true,
            unreadCount = unreadCount,
            snackbarHostState = snackbarHostState,
            viewModel = viewModel,
            onSpeak = { voiceAssistant.speak(it, language) },
            onSignOut = performSignOut
        )
        return
    }

    when (val state = profileState) {
        ProfileUiState.Loading -> {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) },
                contentWindowInsets = WindowInsets.safeDrawing
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }
        }

        is ProfileUiState.Error -> {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) },
                contentWindowInsets = WindowInsets.safeDrawing
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.widthIn(max = 480.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = CrimsonContainer)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = CrimsonError,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = state.message,
                                style = MaterialTheme.typography.bodyLarge,
                                color = CrimsonError
                            )
                            OutlinedButton(onClick = performSignOut) {
                                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(strings.logout)
                            }
                        }
                    }
                }
            }
        }

        ProfileUiState.NeedsOnboarding -> {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) },
                contentWindowInsets = WindowInsets.safeDrawing
            ) { innerPadding ->
                RoleOnboardingScreen(
                    firebaseDisplayName = firebaseUser.displayName ?: "",
                    firebaseEmail = firebaseUser.email,
                    localMigrationPreview = localMigrationPreview,
                    isAdminUser = isAdminUser,
                    language = language,
                    strings = strings,
                    authError = authError,
                    onLanguageSelected = { viewModel.setLanguage(it) },
                    onClearError = { viewModel.clearAuthError() },
                    onSpeak = { voiceAssistant.speak(it, language) },
                    onOpenAdminDashboard = { viewModel.toggleAdminMode(true) },
                    onRegisterProfile = { name, phone, role, city, area, skill, exp, wage, skills, langs, gender, avail, photo ->
                        viewModel.registerProfile(
                            name = name,
                            phone = phone,
                            role = role,
                            city = city,
                            area = area,
                            skill = skill,
                            experienceYears = exp,
                            expectedDailyWage = wage,
                            skills = skills,
                            spokenLanguages = langs,
                            gender = gender,
                            availabilityStatus = avail,
                            profilePhotoBase64 = photo
                        )
                    },
                    onSignOut = performSignOut,
                    modifier = Modifier.padding(innerPadding),
                    initialPreferredRole = initialPreferredRole,
                    activeLocations = activeLocations
                )
            }
        }

        is ProfileUiState.Ready -> {
            val user = state.user
            if (user.isSuspended) {
                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            modifier = Modifier.widthIn(max = 480.dp),
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = CrimsonContainer),
                            border = BorderStroke(1.dp, CrimsonError.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Block,
                                    contentDescription = null,
                                    tint = CrimsonError,
                                    modifier = Modifier.size(48.dp)
                                )
                                Text(
                                    text = strings.accountSuspendedMsg,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CrimsonError,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedButton(
                                    onClick = performSignOut,
                                    modifier = Modifier.fillMaxWidth().height(50.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, CrimsonError)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, tint = CrimsonError)
                                    Spacer(Modifier.width(8.dp))
                                    Text(strings.logout, color = CrimsonError, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            } else {
                AuthenticatedShell(
                    user = user,
                    userEmail = firebaseUser.email,
                    isAdminUser = isAdminUser,
                    adminModeEnabled = adminModeEnabled,
                    unreadCount = unreadCount,
                    snackbarHostState = snackbarHostState,
                    viewModel = viewModel,
                    onSpeak = { voiceAssistant.speak(it, language) },
                    onSignOut = performSignOut
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedShell(
    user: FirestoreUser?,
    userEmail: String?,
    isAdminUser: Boolean,
    adminModeEnabled: Boolean,
    unreadCount: Int,
    snackbarHostState: SnackbarHostState,
    viewModel: DailyWorkViewModel,
    onSpeak: (String) -> Unit,
    onSignOut: () -> Unit
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val strings = remember(language) { AppStrings.get(language) }
    val filmStrings = remember(language) { FilmStrings.get(language) }
    val activeModule by viewModel.activeModule.collectAsStateWithLifecycle()
    val selectedLocation by viewModel.selectedLocation.collectAsStateWithLifecycle()
    val locationQuery by viewModel.locationQuery.collectAsStateWithLifecycle()
    val categoryFilter by viewModel.categoryFilter.collectAsStateWithLifecycle()
    val minWageFilter by viewModel.minWageFilter.collectAsStateWithLifecycle()
    val nearbyJobs by viewModel.nearbyJobs.collectAsStateWithLifecycle()
    val workerApps by viewModel.workerApplications.collectAsStateWithLifecycle()
    val employerJobs by viewModel.employerJobs.collectAsStateWithLifecycle()
    val employerApps by viewModel.employerApplications.collectAsStateWithLifecycle()
    val filteredWorkers by viewModel.filteredWorkers.collectAsStateWithLifecycle()
    val workerSearchQuery by viewModel.workerSearchQuery.collectAsStateWithLifecycle()
    val workerSkillFilter by viewModel.workerSkillFilter.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val allJobs by viewModel.allJobs.collectAsStateWithLifecycle()
    val adminStats by viewModel.adminStats.collectAsStateWithLifecycle()
    val serviceAreasConfig by viewModel.serviceAreasConfig.collectAsStateWithLifecycle()
    val activeLocations by viewModel.activeLocations.collectAsStateWithLifecycle()
    val activeCities by viewModel.activeCities.collectAsStateWithLifecycle()
    val outsideAreaNotice by viewModel.outsideAreaNotice.collectAsStateWithLifecycle()

    // Module 2: Film Direct Connect states
    val artistProfile by viewModel.artistProfile.collectAsStateWithLifecycle()
    val castingProfile by viewModel.castingProfile.collectAsStateWithLifecycle()
    val filteredCastingPosts by viewModel.filteredCastingPosts.collectAsStateWithLifecycle()
    val myCastingApps by viewModel.myCastingApplications.collectAsStateWithLifecycle()
    val myCastingPosts by viewModel.myCastingPosts.collectAsStateWithLifecycle()
    val castingOwnerApps by viewModel.castingOwnerApplications.collectAsStateWithLifecycle()
    val blockedEntities by viewModel.blockedEntities.collectAsStateWithLifecycle()
    val castingCityFilter by viewModel.castingCityFilter.collectAsStateWithLifecycle()
    val castingDateFilter by viewModel.castingDateFilter.collectAsStateWithLifecycle()
    val castingRoleQuery by viewModel.castingRoleQuery.collectAsStateWithLifecycle()
    val allCastingProfiles by viewModel.allCastingProfiles.collectAsStateWithLifecycle()
    val allContentReports by viewModel.allContentReports.collectAsStateWithLifecycle()

    val effectiveAdmin = isAdminUser && adminModeEnabled
    val activeRole = if (effectiveAdmin) UserRole.ADMIN else (user?.roleEnum() ?: UserRole.WORKER)

    var selectedTab by remember(user?.uid, effectiveAdmin, activeModule) { mutableIntStateOf(0) }

    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    val tabs = if (activeModule == AppModule.FILM_CONNECT) {
        if (effectiveAdmin) {
            listOf(
                NavTab(filmStrings.navFilmModeration, Icons.Filled.Security, badgeCount = allContentReports.count { it.status == "OPEN" }, tag = "nav_film_admin"),
                NavTab(filmStrings.navShootingCalls, Icons.Filled.Movie, tag = "nav_film_shoots"),
                NavTab(strings.navServiceAreas, Icons.Filled.Public, tag = "nav_admin_service_areas"),
                NavTab(strings.navProfile, Icons.Filled.Person, tag = "nav_admin_profile")
            )
        } else {
            listOf(
                NavTab(filmStrings.navShootingCalls, Icons.Filled.Movie, tag = "nav_film_shoots"),
                NavTab(filmStrings.navArtistProfile, Icons.Filled.Person, tag = "nav_film_artist"),
                NavTab(filmStrings.navCastingStudio, Icons.Filled.AddBusiness, tag = "nav_film_casting"),
                NavTab(filmStrings.navApplicants, Icons.Filled.HowToReg, badgeCount = castingOwnerApps.count { it.status == "PENDING" }, tag = "nav_film_applicants"),
                NavTab(strings.navAlerts, Icons.Filled.Notifications, badgeCount = unreadCount, tag = "nav_film_alerts")
            )
        }
    } else {
        when (activeRole) {
            UserRole.WORKER -> listOf(
                NavTab(strings.navJobs, Icons.Filled.Work, tag = "nav_jobs"),
                NavTab(strings.navMyWork, Icons.Filled.AssignmentTurnedIn, tag = "nav_my_work"),
                NavTab(strings.navAlerts, Icons.Filled.Notifications, badgeCount = unreadCount, tag = "nav_alerts"),
                NavTab(strings.navProfile, Icons.Filled.Person, tag = "nav_profile")
            )
            UserRole.EMPLOYER -> listOf(
                NavTab(strings.navPostJob, Icons.Filled.AddBusiness, tag = "nav_post_job"),
                NavTab(strings.navWorkers, Icons.Filled.Group, tag = "nav_workers"),
                NavTab(strings.navApplicants, Icons.Filled.HowToReg, badgeCount = employerApps.count { it.status == "PENDING" }, tag = "nav_applicants"),
                NavTab(strings.navAlerts, Icons.Filled.Notifications, badgeCount = unreadCount, tag = "nav_alerts"),
                NavTab(strings.navProfile, Icons.Filled.Person, tag = "nav_profile")
            )
            UserRole.ADMIN -> listOf(
                NavTab(strings.navOverview, Icons.Filled.AdminPanelSettings, tag = "nav_admin_overview"),
                NavTab(strings.navUsers, Icons.Filled.Group, tag = "nav_admin_users"),
                NavTab(strings.navBroadcast, Icons.Filled.Campaign, tag = "nav_admin_broadcast"),
                NavTab(strings.navServiceAreas, Icons.Filled.Public, tag = "nav_admin_service_areas"),
                NavTab(strings.navProfile, Icons.Filled.Person, tag = "nav_admin_profile")
            )
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                Column {
                    TopAppBar(
                        title = {
                            Text(
                                text = if (activeModule == AppModule.FILM_CONNECT) {
                                    filmStrings.filmConnectTitle
                                } else {
                                    "${strings.appName} • ${strings.roleName(activeRole)}"
                                },
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        actions = {
                            if (isAdminUser) {
                                TextButton(
                                    onClick = { viewModel.toggleAdminMode(!adminModeEnabled) },
                                    modifier = Modifier.testTag("topbar_admin_toggle")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.AdminPanelSettings,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = if (adminModeEnabled) strings.exitAdminMode else strings.demoAdmin,
                                        maxLines = 1
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    // Dual-Marketplace Module Switcher: Daily Labour | Film Connect
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 2.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val labourSelected = activeModule == AppModule.DAILY_LABOUR
                            val filmSelected = activeModule == AppModule.FILM_CONNECT
                            Surface(
                                onClick = {
                                    viewModel.setActiveModule(AppModule.DAILY_LABOUR)
                                    selectedTab = 0
                                },
                                color = if (labourSelected) SaffronPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("module_tab_daily_labour")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Work,
                                        contentDescription = null,
                                        tint = if (labourSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = filmStrings.moduleDailyLabour,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (labourSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Surface(
                                onClick = {
                                    viewModel.setActiveModule(AppModule.FILM_CONNECT)
                                    selectedTab = 0
                                },
                                color = if (filmSelected) SaffronPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .minimumInteractiveComponentSize()
                                    .testTag("module_tab_film_connect")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Movie,
                                        contentDescription = null,
                                        tint = if (filmSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = filmStrings.moduleFilmConnect,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = if (filmSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(
                        windowInsets = WindowInsets.navigationBars
                    ) {
                        tabs.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (tab.badgeCount > 0) {
                                                Badge { Text(tab.badgeCount.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(tab.icon, contentDescription = tab.label)
                                    }
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail {
                        tabs.forEachIndexed { index, tab ->
                            NavigationRailItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (tab.badgeCount > 0) {
                                                Badge { Text(tab.badgeCount.toString()) }
                                            }
                                        }
                                    ) {
                                        Icon(tab.icon, contentDescription = tab.label)
                                    }
                                },
                                label = { Text(tab.label, maxLines = 1) },
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    if (activeModule == AppModule.FILM_CONNECT) {
                        if (effectiveAdmin) {
                            when (selectedTab) {
                                0 -> AdminFilmModerationScreen(
                                    castingProfiles = allCastingProfiles,
                                    reports = allContentReports,
                                    strings = strings,
                                    filmStrings = filmStrings,
                                    onVerifyCasting = { profile, approve, reason ->
                                        viewModel.adminVerifyCastingProfile(profile, approve, reason)
                                    },
                                    onToggleSuspendCasting = { viewModel.adminToggleSuspendCastingProfile(it) },
                                    onResolveReport = { rep, status, note, closePost, suspendOwner ->
                                        viewModel.adminResolveReport(rep, status, note, closePost, suspendOwner)
                                    }
                                )
                                1 -> FilmShootingCallsScreen(
                                    artistProfile = artistProfile,
                                    posts = filteredCastingPosts,
                                    myApplications = myCastingApps,
                                    cityFilter = castingCityFilter,
                                    dateFilter = castingDateFilter,
                                    roleQuery = castingRoleQuery,
                                    activeCities = activeCities,
                                    strings = strings,
                                    filmStrings = filmStrings,
                                    onCityFilterChange = { viewModel.setCastingCityFilter(it) },
                                    onDateFilterChange = { viewModel.setCastingDateFilter(it) },
                                    onRoleQueryChange = { viewModel.setCastingRoleQuery(it) },
                                    onOpenArtistProfileTab = {},
                                    onApplyPost = { post, note -> viewModel.applyToCastingPost(post, note) },
                                    onSubmitReport = { target, reason, details ->
                                        viewModel.submitContentReport(target.targetId, target.targetType, target.targetOwnerId, target.targetLabel, reason, details)
                                    },
                                    onBlockEntity = { id, type, label -> viewModel.blockEntity(id, type, label) },
                                    onSpeak = onSpeak
                                )
                                2 -> AdminServiceAreasScreen(
                                    config = serviceAreasConfig,
                                    strings = strings,
                                    onToggleCity = { city, enable -> viewModel.toggleServiceAreaCity(city, enable) },
                                    onAddCustomArea = { c, s, l -> viewModel.addCustomServiceArea(c, s, l) }
                                )
                                else -> ProfileScreen(
                                    user = user,
                                    userEmail = userEmail,
                                    isAdminUser = isAdminUser,
                                    adminModeEnabled = adminModeEnabled,
                                    language = language,
                                    strings = strings,
                                    onLanguageSelected = { viewModel.setLanguage(it) },
                                    onToggleAvailability = {},
                                    onToggleAdminMode = { viewModel.toggleAdminMode(it) },
                                    onSaveProfile = { n, p, c, a, s, e, w, skills, langs, gender, avail, photo ->
                                        viewModel.updateProfile(n, p, c, a, s, e, w, skills, langs, gender, avail, photo)
                                    },
                                    onLogout = onSignOut,
                                    activeLocations = activeLocations
                                )
                            }
                        } else {
                            when (selectedTab) {
                                0 -> FilmShootingCallsScreen(
                                    artistProfile = artistProfile,
                                    posts = filteredCastingPosts,
                                    myApplications = myCastingApps,
                                    cityFilter = castingCityFilter,
                                    dateFilter = castingDateFilter,
                                    roleQuery = castingRoleQuery,
                                    activeCities = activeCities,
                                    strings = strings,
                                    filmStrings = filmStrings,
                                    onCityFilterChange = { viewModel.setCastingCityFilter(it) },
                                    onDateFilterChange = { viewModel.setCastingDateFilter(it) },
                                    onRoleQueryChange = { viewModel.setCastingRoleQuery(it) },
                                    onOpenArtistProfileTab = { selectedTab = 1 },
                                    onApplyPost = { post, note -> viewModel.applyToCastingPost(post, note) },
                                    onSubmitReport = { target, reason, details ->
                                        viewModel.submitContentReport(target.targetId, target.targetType, target.targetOwnerId, target.targetLabel, reason, details)
                                    },
                                    onBlockEntity = { id, type, label -> viewModel.blockEntity(id, type, label) },
                                    onSpeak = onSpeak
                                )
                                1 -> ArtistProfileAndAppsScreen(
                                    artistProfile = artistProfile,
                                    myApplications = myCastingApps,
                                    blockedEntities = blockedEntities,
                                    activeLocations = activeLocations,
                                    strings = strings,
                                    filmStrings = filmStrings,
                                    onSaveArtistProfile = { name, age, gender, city, area, phone, langs, exp, skills, bio, photos, noBroker, zeroFee ->
                                        viewModel.saveArtistProfile(name, age, gender, city, area, phone, langs, exp, skills, bio, photos, noBroker, zeroFee)
                                    },
                                    onUnblock = { viewModel.unblockEntity(it) }
                                )
                                2 -> CastingStudioScreen(
                                    castingProfile = castingProfile,
                                    myPosts = myCastingPosts,
                                    activeLocations = activeLocations,
                                    strings = strings,
                                    filmStrings = filmStrings,
                                    onSubmitVerification = { type, org, contact, phone, city, area, credits, idType, idRef, notes, noBroker, zeroFee ->
                                        viewModel.submitCastingVerification(type, org, contact, phone, city, area, credits, idType, idRef, notes, noBroker, zeroFee)
                                    },
                                    onPostCasting = { project, role, count, minAge, maxAge, genderPref, langs, date, time, city, area, pay, unit, desc, noBroker, zeroFee ->
                                        viewModel.postCastingRequirement(project, role, count, minAge, maxAge, genderPref, langs, date, time, city, area, pay, unit, desc, noBroker, zeroFee)
                                    },
                                    onTogglePostStatus = { post, status -> viewModel.updateCastingPostStatus(post, status) },
                                    onDeletePost = { viewModel.deleteCastingPost(it) }
                                )
                                3 -> CastingApplicantsScreen(
                                    applications = castingOwnerApps,
                                    strings = strings,
                                    filmStrings = filmStrings,
                                    onUpdateStatus = { app, status -> viewModel.updateCastingApplicationStatus(app, status) },
                                    onSubmitReport = { target, reason, details ->
                                        viewModel.submitContentReport(target.targetId, target.targetType, target.targetOwnerId, target.targetLabel, reason, details)
                                    },
                                    onBlockArtist = { id, type, label -> viewModel.blockEntity(id, type, label) },
                                    onShowMessage = { viewModel.showMessage(it) }
                                )
                                else -> NotificationsScreen(
                                    notifications = notifications,
                                    strings = strings,
                                    onMarkRead = { viewModel.markNotificationRead(it) },
                                    onMarkAllRead = { viewModel.markAllNotificationsRead() },
                                    onSpeak = onSpeak
                                )
                            }
                        }
                    } else {
                        when (activeRole) {
                            UserRole.WORKER -> if (user != null) {
                                when (selectedTab) {
                                    0 -> WorkerJobsScreen(
                                        worker = user,
                                        selectedLocation = selectedLocation,
                                        locationQuery = locationQuery,
                                        categoryFilter = categoryFilter,
                                        minWageFilter = minWageFilter,
                                        jobs = nearbyJobs,
                                        strings = strings,
                                        onToggleAvailability = { viewModel.toggleAvailability() },
                                        onLocationQueryChange = { viewModel.setLocationSearchQuery(it) },
                                        onLocationPicked = { c, a -> viewModel.setLocation(c, a) },
                                        onCategoryFilterChange = { viewModel.setCategoryFilter(it) },
                                        onMinWageFilterChange = { viewModel.setMinWageFilter(it) },
                                        onApplyJob = { job, note -> viewModel.applyForJob(job, note) },
                                        onSpeak = onSpeak,
                                        onShowMessage = { viewModel.showMessage(it) },
                                        activeLocations = activeLocations,
                                        outsideAreaNotice = outsideAreaNotice,
                                        onGpsResult = { viewModel.onGpsLocationResult(it) },
                                        onDismissOutsideNotice = { viewModel.dismissOutsideAreaNotice() }
                                    )
                                    1 -> WorkerApplicationsScreen(
                                        applications = workerApps,
                                        strings = strings,
                                        onSpeak = onSpeak,
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                    2 -> NotificationsScreen(
                                        notifications = notifications,
                                        strings = strings,
                                        onMarkRead = { viewModel.markNotificationRead(it) },
                                        onMarkAllRead = { viewModel.markAllNotificationsRead() },
                                        onSpeak = onSpeak
                                    )
                                    else -> ProfileScreen(
                                        user = user,
                                        userEmail = userEmail,
                                        isAdminUser = isAdminUser,
                                        adminModeEnabled = adminModeEnabled,
                                        language = language,
                                        strings = strings,
                                        onLanguageSelected = { viewModel.setLanguage(it) },
                                        onToggleAvailability = { viewModel.toggleAvailability() },
                                        onToggleAdminMode = { viewModel.toggleAdminMode(it) },
                                        onSaveProfile = { n, p, c, a, s, e, w, skills, langs, gender, avail, photo ->
                                            viewModel.updateProfile(
                                                name = n,
                                                phone = p,
                                                city = c,
                                                area = a,
                                                skill = s,
                                                experienceYears = e,
                                                expectedDailyWage = w,
                                                skills = skills,
                                                spokenLanguages = langs,
                                                gender = gender,
                                                availabilityStatus = avail,
                                                profilePhotoBase64 = photo
                                            )
                                        },
                                        onLogout = onSignOut,
                                        activeLocations = activeLocations
                                    )
                                }
                            }

                            UserRole.EMPLOYER -> if (user != null) {
                                when (selectedTab) {
                                    0 -> EmployerHomeScreen(
                                        employer = user,
                                        postedJobs = employerJobs,
                                        applicationsCount = employerApps.size,
                                        strings = strings,
                                        onPostJob = { t, cat, desc, c, a, w, wn, d, s, m ->
                                            viewModel.postJob(t, cat, desc, c, a, w, wn, d, s, m)
                                        },
                                        onToggleJobStatus = { job, status -> viewModel.updateJobStatus(job, status) },
                                        onDeleteJob = { viewModel.deleteJob(it) },
                                        activeLocations = activeLocations
                                    )
                                    1 -> EmployerWorkersScreen(
                                        workers = filteredWorkers,
                                        searchQuery = workerSearchQuery,
                                        skillFilter = workerSkillFilter,
                                        strings = strings,
                                        onSearchQueryChange = { viewModel.setWorkerSearchQuery(it) },
                                        onSkillFilterChange = { viewModel.setWorkerSkillFilter(it) },
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                    2 -> EmployerApplicationsScreen(
                                        applications = employerApps,
                                        strings = strings,
                                        onUpdateApplicationStatus = { app, st ->
                                            viewModel.updateApplicationStatus(app, st)
                                        },
                                        onShowMessage = { viewModel.showMessage(it) }
                                    )
                                    3 -> NotificationsScreen(
                                        notifications = notifications,
                                        strings = strings,
                                        onMarkRead = { viewModel.markNotificationRead(it) },
                                        onMarkAllRead = { viewModel.markAllNotificationsRead() },
                                        onSpeak = onSpeak
                                    )
                                    else -> ProfileScreen(
                                        user = user,
                                        userEmail = userEmail,
                                        isAdminUser = isAdminUser,
                                        adminModeEnabled = adminModeEnabled,
                                        language = language,
                                        strings = strings,
                                        onLanguageSelected = { viewModel.setLanguage(it) },
                                        onToggleAvailability = {},
                                        onToggleAdminMode = { viewModel.toggleAdminMode(it) },
                                        onSaveProfile = { n, p, c, a, s, e, w, skills, langs, gender, avail, photo ->
                                            viewModel.updateProfile(
                                                name = n,
                                                phone = p,
                                                city = c,
                                                area = a,
                                                skill = s,
                                                experienceYears = e,
                                                expectedDailyWage = w,
                                                skills = skills,
                                                spokenLanguages = langs,
                                                gender = gender,
                                                availabilityStatus = avail,
                                                profilePhotoBase64 = photo
                                            )
                                        },
                                        onLogout = onSignOut,
                                        activeLocations = activeLocations
                                    )
                                }
                            }

                            UserRole.ADMIN -> when (selectedTab) {
                                0 -> AdminOverviewScreen(
                                    stats = adminStats,
                                    strings = strings
                                )
                                1 -> AdminUsersScreen(
                                    users = allUsers,
                                    strings = strings,
                                    onToggleVerify = { viewModel.toggleVerifyUser(it) },
                                    onToggleSuspend = { viewModel.toggleSuspendUser(it) }
                                )
                                2 -> AdminJobsAndBroadcastScreen(
                                    jobs = allJobs,
                                    strings = strings,
                                    onToggleJobStatus = { job, st -> viewModel.updateJobStatus(job, st) },
                                    onDeleteJob = { viewModel.deleteJob(it) },
                                    onSendBroadcast = { t, m, r -> viewModel.sendAdminBroadcast(t, m, r) }
                                )
                                3 -> AdminServiceAreasScreen(
                                    config = serviceAreasConfig,
                                    strings = strings,
                                    onToggleCity = { city, enable -> viewModel.toggleServiceAreaCity(city, enable) },
                                    onAddCustomArea = { c, s, l -> viewModel.addCustomServiceArea(c, s, l) }
                                )
                                else -> ProfileScreen(
                                    user = user,
                                    userEmail = userEmail,
                                    isAdminUser = isAdminUser,
                                    adminModeEnabled = adminModeEnabled,
                                    language = language,
                                    strings = strings,
                                    onLanguageSelected = { viewModel.setLanguage(it) },
                                    onToggleAvailability = {},
                                    onToggleAdminMode = { viewModel.toggleAdminMode(it) },
                                    onSaveProfile = { n, p, c, a, s, e, w, skills, langs, gender, avail, photo ->
                                        viewModel.updateProfile(
                                            name = n,
                                            phone = p,
                                            city = c,
                                            area = a,
                                            skill = s,
                                            experienceYears = e,
                                            expectedDailyWage = w,
                                            skills = skills,
                                            spokenLanguages = langs,
                                            gender = gender,
                                            availabilityStatus = avail,
                                            profilePhotoBase64 = photo
                                        )
                                    },
                                    onLogout = onSignOut,
                                    activeLocations = activeLocations
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
