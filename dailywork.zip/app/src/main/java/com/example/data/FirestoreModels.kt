package com.example.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class FirestoreUser(
    @DocumentId val id: String = "",
    val uid: String = "",
    val name: String = "",
    val phone: String = "",
    val role: String = UserRole.WORKER.name,
    val city: String = "Warangal",
    val area: String = "Chowrasta",
    val latitude: Double = 17.9689,
    val longitude: Double = 79.5941,
    val primarySkill: String = WorkCategory.HELPER.name,
    val skills: List<String> = emptyList(),
    val spokenLanguages: List<String> = emptyList(),
    val gender: String = "",
    val availabilityStatus: String = WorkAvailability.AVAILABLE_TODAY.name,
    val profilePhotoBase64: String = "",
    val experienceYears: Long = 1L,
    val expectedDailyWage: Long = 700L,
    val isAvailable: Boolean = true,
    val isVerified: Boolean = false,
    val isSuspended: Boolean = false,
    val rating: Double = 5.0,
    val completedJobs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun roleEnum(): UserRole =
        runCatching { UserRole.valueOf(role) }.getOrDefault(UserRole.WORKER)

    fun skillEnum(): WorkCategory =
        runCatching { WorkCategory.valueOf(primarySkill) }.getOrDefault(WorkCategory.HELPER)

    fun skillsEnumList(): List<WorkCategory> {
        val parsed = skills.mapNotNull { runCatching { WorkCategory.valueOf(it) }.getOrNull() }.distinct()
        return parsed.ifEmpty { listOf(skillEnum()) }
    }

    fun spokenLanguagesList(): List<String> =
        spokenLanguages.filter { it.isNotBlank() }.distinct()

    fun genderEnum(): WorkerGender? =
        if (gender.isBlank()) null else runCatching { WorkerGender.valueOf(gender) }.getOrNull()

    fun availabilityEnum(): WorkAvailability =
        runCatching { WorkAvailability.valueOf(availabilityStatus) }
            .getOrDefault(if (isAvailable) WorkAvailability.AVAILABLE_TODAY else WorkAvailability.NOT_AVAILABLE)
}

@IgnoreExtraProperties
data class FirestoreJob(
    @DocumentId val id: String = "",
    val employerId: String = "",
    val employerName: String = "",
    val employerPhone: String = "",
    val title: String = "",
    val category: String = WorkCategory.HELPER.name,
    val description: String = "",
    val city: String = "Warangal",
    val area: String = "Chowrasta",
    val latitude: Double = 17.9689,
    val longitude: Double = 79.5941,
    val dailyWage: Long = 700L,
    val workersNeeded: Long = 1L,
    val workDurationDays: Long = 1L,
    val shiftTiming: String = "8:30 AM - 5:30 PM",
    val includesMeals: Boolean = false,
    val status: String = JobStatus.OPEN.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun categoryEnum(): WorkCategory =
        runCatching { WorkCategory.valueOf(category) }.getOrDefault(WorkCategory.HELPER)

    fun statusEnum(): JobStatus =
        runCatching { JobStatus.valueOf(status) }.getOrDefault(JobStatus.OPEN)
}

@IgnoreExtraProperties
data class FirestoreApplication(
    @DocumentId val id: String = "",
    val jobId: String = "",
    val jobTitle: String = "",
    val dailyWage: Long = 0L,
    val employerId: String = "",
    val employerName: String = "",
    val employerPhone: String = "",
    val jobCity: String = "",
    val jobArea: String = "",
    val workerId: String = "",
    val workerName: String = "",
    val workerPhone: String = "",
    val workerSkill: String = WorkCategory.HELPER.name,
    val workerArea: String = "",
    val status: String = ApplicationStatus.PENDING.name,
    val note: String = "",
    @ServerTimestamp val appliedAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun skillEnum(): WorkCategory =
        runCatching { WorkCategory.valueOf(workerSkill) }.getOrDefault(WorkCategory.HELPER)

    fun statusEnum(): ApplicationStatus =
        runCatching { ApplicationStatus.valueOf(status) }.getOrDefault(ApplicationStatus.PENDING)
}

@IgnoreExtraProperties
data class FirestoreNotification(
    @DocumentId val id: String = "",
    val userId: String = "",
    val senderId: String = "",
    val targetRole: String = "ALL",
    val title: String = "",
    val message: String = "",
    val type: String = NotificationType.ADMIN_ALERT.name,
    val isRead: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun typeEnum(): NotificationType =
        runCatching { NotificationType.valueOf(type) }.getOrDefault(NotificationType.ADMIN_ALERT)
}

@IgnoreExtraProperties
data class ServiceAreaLocality(
    val area: String = "",
    val latitude: Double = 17.9689,
    val longitude: Double = 79.5941
)

@IgnoreExtraProperties
data class ServiceAreaCity(
    val city: String = "",
    val state: String = "Telangana",
    val latitude: Double = 17.9689,
    val longitude: Double = 79.5941,
    val localities: List<ServiceAreaLocality> = emptyList()
)

@IgnoreExtraProperties
data class FirestoreServiceAreasConfig(
    @DocumentId val id: String = "service_areas",
    val enabledCities: List<String> = IndianLocations.launchCities,
    val cities: List<ServiceAreaCity> = emptyList(),
    val updatedBy: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun activeCityNames(): List<String> {
        val clean = enabledCities.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        return clean.ifEmpty { IndianLocations.launchCities }
    }

    fun isCityEnabled(city: String): Boolean =
        activeCityNames().any { it.equals(city.trim(), ignoreCase = true) }

    fun toIndianLocations(): List<IndianLocation> {
        val enabled = activeCityNames()
        val result = mutableListOf<IndianLocation>()
        for (cityName in enabled) {
            val customCity = cities.firstOrNull { it.city.equals(cityName, ignoreCase = true) }
            val knownLocalities = IndianLocations.allKnownLocations.filter {
                it.city.equals(cityName, ignoreCase = true)
            }
            val customLocalities = customCity?.localities
                ?.filter { it.area.isNotBlank() }
                ?.map { loc ->
                    IndianLocation(
                        city = customCity.city.ifBlank { cityName },
                        area = loc.area.trim(),
                        state = customCity.state.ifBlank { "Telangana" },
                        latitude = loc.latitude,
                        longitude = loc.longitude
                    )
                }.orEmpty()

            val merged = (knownLocalities + customLocalities)
                .distinctBy { "${it.city.lowercase()}|${it.area.lowercase()}" }

            if (merged.isNotEmpty()) {
                result.addAll(merged)
            } else if (customCity != null) {
                result.add(
                    IndianLocation(
                        city = customCity.city.ifBlank { cityName },
                        area = customCity.city.ifBlank { cityName },
                        state = customCity.state.ifBlank { "Telangana" },
                        latitude = customCity.latitude,
                        longitude = customCity.longitude
                    )
                )
            } else {
                val fallback = IndianLocations.allKnownLocations.firstOrNull {
                    it.city.equals(cityName, ignoreCase = true)
                } ?: IndianLocations.defaultLocation.copy(city = cityName, area = cityName)
                result.add(fallback)
            }
        }
        return result.ifEmpty { IndianLocations.launchPresets }
    }

    companion object {
        fun defaultLaunchConfig(): FirestoreServiceAreasConfig {
            val grouped = IndianLocations.launchPresets.groupBy { it.city }
            val cityEntries = IndianLocations.launchCities.mapNotNull { cityName ->
                val list = grouped[cityName].orEmpty()
                val first = list.firstOrNull() ?: return@mapNotNull null
                ServiceAreaCity(
                    city = cityName,
                    state = first.state,
                    latitude = first.latitude,
                    longitude = first.longitude,
                    localities = list.map { ServiceAreaLocality(it.area, it.latitude, it.longitude) }
                )
            }
            return FirestoreServiceAreasConfig(
                id = "service_areas",
                enabledCities = IndianLocations.launchCities,
                cities = cityEntries
            )
        }
    }
}

// --- MODULE 2: FILM DIRECT CONNECT MODELS ---

@IgnoreExtraProperties
data class FirestoreArtistProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val name: String = "",
    val age: Long = 22L,
    val gender: String = "",
    val city: String = "Hyderabad",
    val area: String = "Film Nagar",
    val phone: String = "",
    val languages: List<String> = emptyList(),
    val experienceYears: Long = 0L,
    val skills: List<String> = listOf(ArtistSkill.JUNIOR_ARTIST.name),
    val bio: String = "",
    val photosBase64: List<String> = emptyList(),
    val noBrokerConfirmed: Boolean = true,
    val zeroFeeAcknowledged: Boolean = true,
    val isAvailable: Boolean = true,
    val isSuspended: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun skillsEnumList(): List<ArtistSkill> {
        val parsed = skills.mapNotNull { runCatching { ArtistSkill.valueOf(it) }.getOrNull() }.distinct()
        return parsed.ifEmpty { listOf(ArtistSkill.JUNIOR_ARTIST) }
    }

    fun genderEnum(): WorkerGender? =
        if (gender.isBlank()) null else runCatching { WorkerGender.valueOf(gender) }.getOrNull()
}

@IgnoreExtraProperties
data class FirestoreCastingProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val accountType: String = CastingAccountType.CASTING_DIRECTOR.name,
    val organizationName: String = "",
    val contactName: String = "",
    val phone: String = "",
    val city: String = "Hyderabad",
    val area: String = "Film Nagar",
    val projectCredits: String = "",
    val idProofType: String = "",
    val idReferenceMasked: String = "",
    val verificationNotes: String = "",
    val noBrokerConfirmed: Boolean = true,
    val zeroFeeConfirmed: Boolean = true,
    val verificationStatus: String = CastingVerificationStatus.PENDING.name,
    val verifiedBy: String = "",
    val rejectionReason: String = "",
    val isSuspended: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun accountTypeEnum(): CastingAccountType =
        runCatching { CastingAccountType.valueOf(accountType) }
            .getOrDefault(CastingAccountType.CASTING_DIRECTOR)

    fun verificationStatusEnum(): CastingVerificationStatus =
        runCatching { CastingVerificationStatus.valueOf(verificationStatus) }
            .getOrDefault(CastingVerificationStatus.PENDING)
}

@IgnoreExtraProperties
data class FirestoreCastingPost(
    @DocumentId val id: String = "",
    val posterId: String = "",
    val posterName: String = "",
    val organizationName: String = "",
    val posterAccountType: String = CastingAccountType.CASTING_DIRECTOR.name,
    val posterVerified: Boolean = true,
    val projectName: String = "",
    val roleTitle: String = "",
    val artistsNeeded: Long = 5L,
    val minAge: Long = 18L,
    val maxAge: Long = 45L,
    val genderPreference: String = GenderPreference.ANY.name,
    val languages: List<String> = emptyList(),
    val shootingDate: String = "",
    val reportingTime: String = "",
    val city: String = "Hyderabad",
    val area: String = "Film Nagar",
    val latitude: Double = 17.4168,
    val longitude: Double = 78.4092,
    val paymentAmount: Long = 1500L,
    val paymentUnit: String = PaymentUnit.PER_DAY.name,
    val description: String = "",
    val noBrokerConfirmed: Boolean = true,
    val zeroFeeConfirmed: Boolean = true,
    val status: String = JobStatus.OPEN.name,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun accountTypeEnum(): CastingAccountType =
        runCatching { CastingAccountType.valueOf(posterAccountType) }
            .getOrDefault(CastingAccountType.CASTING_DIRECTOR)

    fun genderPreferenceEnum(): GenderPreference =
        runCatching { GenderPreference.valueOf(genderPreference) }
            .getOrDefault(GenderPreference.ANY)

    fun paymentUnitEnum(): PaymentUnit =
        runCatching { PaymentUnit.valueOf(paymentUnit) }
            .getOrDefault(PaymentUnit.PER_DAY)

    fun statusEnum(): JobStatus =
        runCatching { JobStatus.valueOf(status) }
            .getOrDefault(JobStatus.OPEN)
}

@IgnoreExtraProperties
data class FirestoreCastingApplication(
    @DocumentId val id: String = "",
    val postId: String = "",
    val projectName: String = "",
    val roleTitle: String = "",
    val castingOwnerId: String = "",
    val organizationName: String = "",
    val posterAccountType: String = CastingAccountType.CASTING_DIRECTOR.name,
    val shootingDate: String = "",
    val reportingTime: String = "",
    val shootingCity: String = "",
    val shootingArea: String = "",
    val paymentAmount: Long = 0L,
    val paymentUnit: String = PaymentUnit.PER_DAY.name,
    val artistId: String = "",
    val artistName: String = "",
    val artistAge: Long = 22L,
    val artistCity: String = "",
    val artistArea: String = "",
    val artistPhone: String = "",
    val artistLanguages: List<String> = emptyList(),
    val artistExperienceYears: Long = 0L,
    val artistSkills: List<String> = emptyList(),
    val artistBio: String = "",
    val artistPhotosBase64: List<String> = emptyList(),
    val note: String = "",
    val noFeeAcknowledged: Boolean = true,
    val status: String = CastingApplicationStatus.PENDING.name,
    @ServerTimestamp val appliedAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun accountTypeEnum(): CastingAccountType =
        runCatching { CastingAccountType.valueOf(posterAccountType) }
            .getOrDefault(CastingAccountType.CASTING_DIRECTOR)

    fun paymentUnitEnum(): PaymentUnit =
        runCatching { PaymentUnit.valueOf(paymentUnit) }
            .getOrDefault(PaymentUnit.PER_DAY)

    fun statusEnum(): CastingApplicationStatus =
        runCatching { CastingApplicationStatus.valueOf(status) }
            .getOrDefault(CastingApplicationStatus.PENDING)
}

@IgnoreExtraProperties
data class FirestoreContentReport(
    @DocumentId val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val targetId: String = "",
    val targetType: String = ReportTargetType.CASTING_POST.name,
    val targetOwnerId: String = "",
    val targetLabel: String = "",
    val reason: String = ReportReason.BROKER_OR_AGENT.name,
    val details: String = "",
    val status: String = ReportStatus.OPEN.name,
    val adminActionNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun targetTypeEnum(): ReportTargetType =
        runCatching { ReportTargetType.valueOf(targetType) }.getOrDefault(ReportTargetType.CASTING_POST)

    fun reasonEnum(): ReportReason =
        runCatching { ReportReason.valueOf(reason) }.getOrDefault(ReportReason.BROKER_OR_AGENT)

    fun statusEnum(): ReportStatus =
        runCatching { ReportStatus.valueOf(status) }.getOrDefault(ReportStatus.OPEN)
}

@IgnoreExtraProperties
data class FirestoreBlockedEntity(
    @DocumentId val id: String = "",
    val targetId: String = "",
    val targetType: String = ReportTargetType.CASTING_PROFILE.name,
    val targetLabel: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    fun targetTypeEnum(): ReportTargetType =
        runCatching { ReportTargetType.valueOf(targetType) }.getOrDefault(ReportTargetType.CASTING_PROFILE)
}

