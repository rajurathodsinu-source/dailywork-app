package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class DailyWorkTypeConverters {
    @TypeConverter fun fromUserRole(value: UserRole): String = value.name
    @TypeConverter fun toUserRole(value: String): UserRole = UserRole.valueOf(value)

    @TypeConverter fun fromWorkCategory(value: WorkCategory): String = value.name
    @TypeConverter fun toWorkCategory(value: String): WorkCategory = WorkCategory.valueOf(value)

    @TypeConverter fun fromJobStatus(value: JobStatus): String = value.name
    @TypeConverter fun toJobStatus(value: String): JobStatus = JobStatus.valueOf(value)

    @TypeConverter fun fromApplicationStatus(value: ApplicationStatus): String = value.name
    @TypeConverter fun toApplicationStatus(value: String): ApplicationStatus = ApplicationStatus.valueOf(value)

    @TypeConverter fun fromNotificationType(value: NotificationType): String = value.name
    @TypeConverter fun toNotificationType(value: String): NotificationType = NotificationType.valueOf(value)
}

@Database(
    entities = [
        UserEntity::class,
        JobEntity::class,
        ApplicationEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(DailyWorkTypeConverters::class)
abstract class DailyWorkDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun jobDao(): JobDao
    abstract fun applicationDao(): ApplicationDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: DailyWorkDatabase? = null

        fun getInstance(context: Context): DailyWorkDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    DailyWorkDatabase::class.java,
                    "dailywork_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
