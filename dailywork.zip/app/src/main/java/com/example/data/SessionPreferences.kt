package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dailywork_prefs")

class SessionPreferences(private val context: Context) {

    private object Keys {
        val USER_ID = longPreferencesKey("current_user_id")
        val LANGUAGE = stringPreferencesKey("app_language")
        val SELECTED_CITY = stringPreferencesKey("selected_city")
        val SELECTED_AREA = stringPreferencesKey("selected_area")
        val READ_BROADCAST_IDS = stringSetPreferencesKey("read_broadcast_ids")
        val MIGRATED_UID = stringPreferencesKey("migrated_uid")
        val ADMIN_MODE_ENABLED = booleanPreferencesKey("admin_mode_enabled")
        val PREFERRED_ROLE = stringPreferencesKey("preferred_role")
        val SELECTED_MODULE = stringPreferencesKey("selected_module")
        val FILM_SUB_ROLE = stringPreferencesKey("film_sub_role")
    }

    val currentUserIdFlow: Flow<Long?> = context.dataStore.data.map { prefs ->
        prefs[Keys.USER_ID]?.takeIf { it > 0L }
    }

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[Keys.LANGUAGE] ?: AppLanguage.ENGLISH.name
        runCatching { AppLanguage.valueOf(code) }.getOrDefault(AppLanguage.ENGLISH)
    }

    val locationFlow: Flow<Pair<String, String>> = context.dataStore.data.map { prefs ->
        val city = prefs[Keys.SELECTED_CITY] ?: "Warangal"
        val area = prefs[Keys.SELECTED_AREA] ?: "Chowrasta"
        city to area
    }

    val readBroadcastIdsFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        prefs[Keys.READ_BROADCAST_IDS] ?: emptySet()
    }

    val migratedUidFlow: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[Keys.MIGRATED_UID]
    }

    val adminModeFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.ADMIN_MODE_ENABLED] ?: false
    }

    val preferredRoleFlow: Flow<UserRole> = context.dataStore.data.map { prefs ->
        val roleName = prefs[Keys.PREFERRED_ROLE] ?: UserRole.WORKER.name
        runCatching { UserRole.valueOf(roleName) }
            .getOrDefault(UserRole.WORKER)
            .let { if (it == UserRole.ADMIN) UserRole.WORKER else it }
    }

    val selectedModuleFlow: Flow<AppModule> = context.dataStore.data.map { prefs ->
        val modName = prefs[Keys.SELECTED_MODULE] ?: AppModule.DAILY_LABOUR.name
        runCatching { AppModule.valueOf(modName) }.getOrDefault(AppModule.DAILY_LABOUR)
    }

    val filmSubRoleFlow: Flow<FilmSubRole> = context.dataStore.data.map { prefs ->
        val roleName = prefs[Keys.FILM_SUB_ROLE] ?: FilmSubRole.ARTIST.name
        runCatching { FilmSubRole.valueOf(roleName) }.getOrDefault(FilmSubRole.ARTIST)
    }

    suspend fun setCurrentUserId(userId: Long?) {
        context.dataStore.edit { prefs ->
            if (userId == null || userId <= 0L) {
                prefs.remove(Keys.USER_ID)
            } else {
                prefs[Keys.USER_ID] = userId
            }
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LANGUAGE] = language.name
        }
    }

    suspend fun setLocation(city: String, area: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_CITY] = city
            prefs[Keys.SELECTED_AREA] = area
        }
    }

    suspend fun markBroadcastRead(id: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.READ_BROADCAST_IDS] ?: emptySet()
            prefs[Keys.READ_BROADCAST_IDS] = current + id
        }
    }

    suspend fun markBroadcastsRead(ids: Collection<String>) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.READ_BROADCAST_IDS] ?: emptySet()
            prefs[Keys.READ_BROADCAST_IDS] = current + ids
        }
    }

    suspend fun setMigratedUid(uid: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.MIGRATED_UID] = uid
        }
    }

    suspend fun setAdminMode(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ADMIN_MODE_ENABLED] = enabled
        }
    }

    suspend fun setPreferredRole(role: UserRole) {
        val safeRole = if (role == UserRole.EMPLOYER) UserRole.EMPLOYER else UserRole.WORKER
        context.dataStore.edit { prefs ->
            prefs[Keys.PREFERRED_ROLE] = safeRole.name
        }
    }

    suspend fun setSelectedModule(module: AppModule) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_MODULE] = module.name
        }
    }

    suspend fun setFilmSubRole(subRole: FilmSubRole) {
        context.dataStore.edit { prefs ->
            prefs[Keys.FILM_SUB_ROLE] = subRole.name
        }
    }
}
