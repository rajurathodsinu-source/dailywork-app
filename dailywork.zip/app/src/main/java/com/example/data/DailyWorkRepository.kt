package com.example.data

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

sealed class AuthResult {
    data class Success(val user: UserEntity) : AuthResult()
    data class Error(val messageKey: String) : AuthResult()
}

class DailyWorkRepository(
    private val db: DailyWorkDatabase,
    private val prefs: SessionPreferences
) {
    constructor(context: Context) : this(
        DailyWorkDatabase.getInstance(context),
        SessionPreferences(context)
    )

    private val userDao = db.userDao()
    private val jobDao = db.jobDao()
    private val applicationDao = db.applicationDao()
    private val notificationDao = db.notificationDao()

    val currentUserIdFlow: Flow<Long?> = prefs.currentUserIdFlow
    val languageFlow: Flow<AppLanguage> = prefs.languageFlow
    val selectedLocationFlow: Flow<Pair<String, String>> = prefs.locationFlow

    val allUsersFlow: Flow<List<UserEntity>> = userDao.observeAllUsers()
    val activeWorkersFlow: Flow<List<UserEntity>> = userDao.observeActiveWorkers()
    val allJobsFlow: Flow<List<JobEntity>> = jobDao.observeAllJobs()
    val allApplicationsFlow: Flow<List<ApplicationEntity>> = applicationDao.observeAllApplications()
    val allNotificationsFlow: Flow<List<NotificationEntity>> = notificationDao.observeAllNotifications()

    fun observeUser(userId: Long): Flow<UserEntity?> = userDao.observeUserById(userId)

    fun observeEmployerJobs(employerId: Long): Flow<List<JobEntity>> =
        jobDao.observeJobsByEmployer(employerId)

    fun observeWorkerApplications(workerId: Long): Flow<List<ApplicationEntity>> =
        applicationDao.observeApplicationsByWorker(workerId)

    fun observeEmployerApplications(employerId: Long): Flow<List<ApplicationEntity>> =
        applicationDao.observeApplicationsByEmployer(employerId)

    fun observeNotifications(userId: Long, role: UserRole): Flow<List<NotificationEntity>> =
        notificationDao.observeNotificationsForUser(userId, role.name)

    suspend fun setLanguage(language: AppLanguage) {
        prefs.setLanguage(language)
    }

    suspend fun setLocation(city: String, area: String) {
        prefs.setLocation(city, area)
    }

    suspend fun ensureSeedData() {
        if (userDao.countUsers() > 0) return

        val now = System.currentTimeMillis()
        val hour = 3_600_000L

        val madhapur = IndianLocations.findLocation("Hyderabad", "Madhapur")
        val kukatpally = IndianLocations.findLocation("Hyderabad", "Kukatpally")
        val lbNagar = IndianLocations.findLocation("Hyderabad", "LB Nagar")
        val gachibowli = IndianLocations.findLocation("Hyderabad", "Gachibowli")
        val benzCircle = IndianLocations.findLocation("Vijayawada", "Benz Circle")
        val hanamkonda = IndianLocations.findLocation("Warangal", "Hanamkonda")
        val mvpColony = IndianLocations.findLocation("Visakhapatnam", "MVP Colony")
        val whitefield = IndianLocations.findLocation("Bengaluru", "Whitefield")
        val dwarka = IndianLocations.findLocation("Delhi", "Dwarka")
        val andheri = IndianLocations.findLocation("Mumbai", "Andheri East")

        // Demo accounts + realistic Indian workers & employers
        val rajuId = userDao.insertUser(
            UserEntity(
                name = "Raju Naidu",
                phone = "9848011111",
                pin = "1234",
                role = UserRole.WORKER,
                city = madhapur.city,
                area = madhapur.area,
                latitude = madhapur.latitude,
                longitude = madhapur.longitude,
                primarySkill = WorkCategory.MASON,
                experienceYears = 6,
                expectedDailyWage = 900,
                isAvailable = true,
                isVerified = true,
                rating = 4.9,
                completedJobs = 34,
                createdAt = now - 30 * hour
            )
        )

        val lakshmiId = userDao.insertUser(
            UserEntity(
                name = "Lakshmi Devi",
                phone = "9848011112",
                pin = "1234",
                role = UserRole.WORKER,
                city = kukatpally.city,
                area = kukatpally.area,
                latitude = kukatpally.latitude,
                longitude = kukatpally.longitude,
                primarySkill = WorkCategory.HELPER,
                experienceYears = 4,
                expectedDailyWage = 650,
                isAvailable = true,
                isVerified = true,
                rating = 4.8,
                completedJobs = 27,
                createdAt = now - 28 * hour
            )
        )

        val sureshId = userDao.insertUser(
            UserEntity(
                name = "Suresh Yadav",
                phone = "9848011113",
                pin = "1234",
                role = UserRole.WORKER,
                city = lbNagar.city,
                area = lbNagar.area,
                latitude = lbNagar.latitude,
                longitude = lbNagar.longitude,
                primarySkill = WorkCategory.ELECTRICIAN,
                experienceYears = 5,
                expectedDailyWage = 1000,
                isAvailable = true,
                isVerified = true,
                rating = 4.7,
                completedJobs = 19,
                createdAt = now - 25 * hour
            )
        )

        userDao.insertUsers(
            listOf(
                UserEntity(
                    name = "Venkatesh Rao",
                    phone = "9848011114",
                    pin = "1234",
                    role = UserRole.WORKER,
                    city = benzCircle.city,
                    area = benzCircle.area,
                    latitude = benzCircle.latitude,
                    longitude = benzCircle.longitude,
                    primarySkill = WorkCategory.PLUMBER,
                    experienceYears = 7,
                    expectedDailyWage = 950,
                    isAvailable = true,
                    isVerified = true,
                    rating = 4.8,
                    completedJobs = 41,
                    createdAt = now - 24 * hour
                ),
                UserEntity(
                    name = "Manoj Kumar",
                    phone = "9848011115",
                    pin = "1234",
                    role = UserRole.WORKER,
                    city = dwarka.city,
                    area = dwarka.area,
                    latitude = dwarka.latitude,
                    longitude = dwarka.longitude,
                    primarySkill = WorkCategory.PAINTER,
                    experienceYears = 3,
                    expectedDailyWage = 850,
                    isAvailable = true,
                    isVerified = false,
                    rating = 4.5,
                    completedJobs = 11,
                    createdAt = now - 20 * hour
                ),
                UserEntity(
                    name = "Anitha Kumari",
                    phone = "9848011116",
                    pin = "1234",
                    role = UserRole.WORKER,
                    city = hanamkonda.city,
                    area = hanamkonda.area,
                    latitude = hanamkonda.latitude,
                    longitude = hanamkonda.longitude,
                    primarySkill = WorkCategory.FARM_WORKER,
                    experienceYears = 8,
                    expectedDailyWage = 600,
                    isAvailable = true,
                    isVerified = true,
                    rating = 4.9,
                    completedJobs = 52,
                    createdAt = now - 18 * hour
                )
            )
        )

        val employer1Id = userDao.insertUser(
            UserEntity(
                name = "Sri Sai Builders (Ramesh)",
                phone = "9848022222",
                pin = "1234",
                role = UserRole.EMPLOYER,
                city = madhapur.city,
                area = madhapur.area,
                latitude = madhapur.latitude,
                longitude = madhapur.longitude,
                isVerified = true,
                rating = 4.8,
                completedJobs = 48,
                createdAt = now - 40 * hour
            )
        )

        val employer2Id = userDao.insertUser(
            UserEntity(
                name = "Metro Infra Works (Kiran)",
                phone = "9848022223",
                pin = "1234",
                role = UserRole.EMPLOYER,
                city = gachibowli.city,
                area = gachibowli.area,
                latitude = gachibowli.latitude,
                longitude = gachibowli.longitude,
                isVerified = true,
                rating = 4.7,
                completedJobs = 22,
                createdAt = now - 35 * hour
            )
        )

        val employer3Id = userDao.insertUser(
            UserEntity(
                name = "Vijayawada Agro & Logistics",
                phone = "9848022224",
                pin = "1234",
                role = UserRole.EMPLOYER,
                city = benzCircle.city,
                area = benzCircle.area,
                latitude = benzCircle.latitude,
                longitude = benzCircle.longitude,
                isVerified = false,
                rating = 4.5,
                completedJobs = 9,
                createdAt = now - 32 * hour
            )
        )

        // Admin user
        userDao.insertUser(
            UserEntity(
                name = "DailyWork Admin",
                phone = "9000099999",
                pin = "0000",
                role = UserRole.ADMIN,
                city = madhapur.city,
                area = madhapur.area,
                latitude = madhapur.latitude,
                longitude = madhapur.longitude,
                isVerified = true,
                createdAt = now - 50 * hour
            )
        )

        val job1Id = jobDao.insertJob(
            JobEntity(
                employerId = employer1Id,
                employerName = "Sri Sai Builders (Ramesh)",
                employerPhone = "9848022222",
                title = "Brick Wall Plastering & Mason Work",
                category = WorkCategory.MASON,
                description = "Need experienced mestri for 2nd floor brick work and smooth cement plastering. Daily cash/UPI payment every evening.",
                city = madhapur.city,
                area = madhapur.area,
                latitude = madhapur.latitude,
                longitude = madhapur.longitude,
                dailyWage = 950,
                workersNeeded = 3,
                workDurationDays = 5,
                shiftTiming = "8:30 AM - 5:30 PM",
                includesMeals = true,
                status = JobStatus.OPEN,
                createdAt = now - 2 * hour
            )
        )

        val job2Id = jobDao.insertJob(
            JobEntity(
                employerId = employer1Id,
                employerName = "Sri Sai Builders (Ramesh)",
                employerPhone = "9848022222",
                title = "Site Material Shifting & Helper",
                category = WorkCategory.HELPER,
                description = "Cement bag shifting and sand mixing support for residential building. Tea and lunch provided.",
                city = kukatpally.city,
                area = kukatpally.area,
                latitude = kukatpally.latitude,
                longitude = kukatpally.longitude,
                dailyWage = 700,
                workersNeeded = 5,
                workDurationDays = 3,
                shiftTiming = "8:00 AM - 5:00 PM",
                includesMeals = true,
                status = JobStatus.OPEN,
                createdAt = now - 3 * hour
            )
        )

        val job3Id = jobDao.insertJob(
            JobEntity(
                employerId = employer2Id,
                employerName = "Metro Infra Works (Kiran)",
                employerPhone = "9848022223",
                title = "Apartment House Wiring & MCB Setup",
                category = WorkCategory.ELECTRICIAN,
                description = "Full 3BHK flat wiring, switchboard fitting, and earthing check. Tools available at site.",
                city = gachibowli.city,
                area = gachibowli.area,
                latitude = gachibowli.latitude,
                longitude = gachibowli.longitude,
                dailyWage = 1100,
                workersNeeded = 2,
                workDurationDays = 4,
                shiftTiming = "9:00 AM - 6:00 PM",
                includesMeals = false,
                status = JobStatus.OPEN,
                createdAt = now - 4 * hour
            )
        )

        jobDao.insertJobs(
            listOf(
                JobEntity(
                    employerId = employer2Id,
                    employerName = "Metro Infra Works (Kiran)",
                    employerPhone = "9848022223",
                    title = "Interior Wall Putty & Emulsion Paint",
                    category = WorkCategory.PAINTER,
                    description = "2 coats putty and Asian Paints roller finish for new showroom.",
                    city = lbNagar.city,
                    area = lbNagar.area,
                    latitude = lbNagar.latitude,
                    longitude = lbNagar.longitude,
                    dailyWage = 850,
                    workersNeeded = 4,
                    workDurationDays = 6,
                    shiftTiming = "8:30 AM - 5:30 PM",
                    includesMeals = true,
                    status = JobStatus.OPEN,
                    createdAt = now - 5 * hour
                ),
                JobEntity(
                    employerId = employer3Id,
                    employerName = "Vijayawada Agro & Logistics",
                    employerPhone = "9848022224",
                    title = "Godown Rice Bag Loading & Unloading",
                    category = WorkCategory.LOADER,
                    description = "Truck loading of 25kg rice bags at Auto Nagar warehouse. Immediate wage settlement.",
                    city = benzCircle.city,
                    area = benzCircle.area,
                    latitude = benzCircle.latitude,
                    longitude = benzCircle.longitude,
                    dailyWage = 750,
                    workersNeeded = 6,
                    workDurationDays = 2,
                    shiftTiming = "7:00 AM - 4:00 PM",
                    includesMeals = true,
                    status = JobStatus.OPEN,
                    createdAt = now - 6 * hour
                ),
                JobEntity(
                    employerId = employer3Id,
                    employerName = "Vijayawada Agro & Logistics",
                    employerPhone = "9848022224",
                    title = "Bathroom Pipe Repair & Tank Fitting",
                    category = WorkCategory.PLUMBER,
                    description = "CPVC pipeline installation and overhead water tank valve fitting.",
                    city = mvpColony.city,
                    area = mvpColony.area,
                    latitude = mvpColony.latitude,
                    longitude = mvpColony.longitude,
                    dailyWage = 950,
                    workersNeeded = 1,
                    workDurationDays = 2,
                    shiftTiming = "9:00 AM - 5:30 PM",
                    includesMeals = false,
                    status = JobStatus.OPEN,
                    createdAt = now - 7 * hour
                ),
                JobEntity(
                    employerId = employer1Id,
                    employerName = "Sri Sai Builders (Ramesh)",
                    employerPhone = "9848022222",
                    title = "Teak Wood Door Frame Carpenter",
                    category = WorkCategory.CARPENTER,
                    description = "Main door and window frame alignment & lock fitting.",
                    city = whitefield.city,
                    area = whitefield.area,
                    latitude = whitefield.latitude,
                    longitude = whitefield.longitude,
                    dailyWage = 1050,
                    workersNeeded = 2,
                    workDurationDays = 3,
                    shiftTiming = "9:00 AM - 6:00 PM",
                    includesMeals = false,
                    status = JobStatus.OPEN,
                    createdAt = now - 8 * hour
                ),
                JobEntity(
                    employerId = employer2Id,
                    employerName = "Metro Infra Works (Kiran)",
                    employerPhone = "9848022223",
                    title = "Paddy & Vegetable Field Harvest",
                    category = WorkCategory.FARM_WORKER,
                    description = "Morning harvest and bundling support. Bus pickup from Hanamkonda junction.",
                    city = hanamkonda.city,
                    area = hanamkonda.area,
                    latitude = hanamkonda.latitude,
                    longitude = hanamkonda.longitude,
                    dailyWage = 620,
                    workersNeeded = 8,
                    workDurationDays = 5,
                    shiftTiming = "6:30 AM - 2:30 PM",
                    includesMeals = true,
                    status = JobStatus.OPEN,
                    createdAt = now - 9 * hour
                ),
                JobEntity(
                    employerId = employer2Id,
                    employerName = "Metro Infra Works (Kiran)",
                    employerPhone = "9848022223",
                    title = "Commercial Complex Deep Cleaning",
                    category = WorkCategory.CLEANER,
                    description = "Floor scrubbing and post-renovation glass & tile cleaning.",
                    city = dwarka.city,
                    area = dwarka.area,
                    latitude = dwarka.latitude,
                    longitude = dwarka.longitude,
                    dailyWage = 650,
                    workersNeeded = 4,
                    workDurationDays = 2,
                    shiftTiming = "8:00 AM - 5:00 PM",
                    includesMeals = true,
                    status = JobStatus.OPEN,
                    createdAt = now - 10 * hour
                ),
                JobEntity(
                    employerId = employer3Id,
                    employerName = "Vijayawada Agro & Logistics",
                    employerPhone = "9848022224",
                    title = "Goods Tempo Delivery Driver",
                    category = WorkCategory.DRIVER,
                    description = "Local hardware delivery within city limits. Valid LMV driving license required.",
                    city = andheri.city,
                    area = andheri.area,
                    latitude = andheri.latitude,
                    longitude = andheri.longitude,
                    dailyWage = 950,
                    workersNeeded = 1,
                    workDurationDays = 7,
                    shiftTiming = "8:30 AM - 6:30 PM",
                    includesMeals = false,
                    status = JobStatus.OPEN,
                    createdAt = now - 11 * hour
                )
            )
        )

        applicationDao.insertApplications(
            listOf(
                ApplicationEntity(
                    jobId = job1Id,
                    workerId = rajuId,
                    workerName = "Raju Naidu",
                    workerPhone = "9848011111",
                    workerSkill = WorkCategory.MASON,
                    workerArea = "Madhapur, Hyderabad",
                    employerId = employer1Id,
                    status = ApplicationStatus.ACCEPTED,
                    note = "6 years mestri experience, ready tomorrow 8 AM.",
                    appliedAt = now - 1 * hour
                ),
                ApplicationEntity(
                    jobId = job2Id,
                    workerId = lakshmiId,
                    workerName = "Lakshmi Devi",
                    workerPhone = "9848011112",
                    workerSkill = WorkCategory.HELPER,
                    workerArea = "Kukatpally, Hyderabad",
                    employerId = employer1Id,
                    status = ApplicationStatus.PENDING,
                    note = "Available nearby, can join immediately.",
                    appliedAt = now - 45 * 60_000L
                ),
                ApplicationEntity(
                    jobId = job3Id,
                    workerId = sureshId,
                    workerName = "Suresh Yadav",
                    workerPhone = "9848011113",
                    workerSkill = WorkCategory.ELECTRICIAN,
                    workerArea = "LB Nagar, Hyderabad",
                    employerId = employer2Id,
                    status = ApplicationStatus.PENDING,
                    note = "Have full multimeter and wiring kit.",
                    appliedAt = now - 30 * 60_000L
                )
            )
        )

        notificationDao.insertNotifications(
            listOf(
                NotificationEntity(
                    userId = rajuId,
                    targetRole = "WORKER",
                    title = "Application Accepted! ₹950/day",
                    message = "Sri Sai Builders accepted you for Brick Wall Plastering & Mason Work in Madhapur.",
                    type = NotificationType.APPLICATION_ACCEPTED,
                    isRead = false,
                    createdAt = now - 55 * 60_000L
                ),
                NotificationEntity(
                    userId = employer1Id,
                    targetRole = "EMPLOYER",
                    title = "New Worker Applied",
                    message = "Lakshmi Devi (Helper, Kukatpally) applied for Site Material Shifting & Helper.",
                    type = NotificationType.APPLICATION_RECEIVED,
                    isRead = false,
                    createdAt = now - 40 * 60_000L
                ),
                NotificationEntity(
                    userId = 0L,
                    targetRole = "ALL",
                    title = "DailyWork Safety & Fair Pay",
                    message = "Always confirm daily wage and shift timings before starting work. Minimum recommended wage: ₹550/day.",
                    type = NotificationType.ADMIN_ALERT,
                    isRead = false,
                    createdAt = now - 120 * 60_000L
                )
            )
        )
    }

    suspend fun login(phone: String, pin: String): AuthResult {
        val cleanPhone = phone.trim()
        val user = userDao.getUserByPhone(cleanPhone)
            ?: return AuthResult.Error("auth_error_not_found")
        if (user.isSuspended) {
            return AuthResult.Error("auth_error_suspended")
        }
        if (user.pin != pin.trim()) {
            return AuthResult.Error("auth_error_wrong_pin")
        }
        prefs.setCurrentUserId(user.id)
        prefs.setLocation(user.city, user.area)
        return AuthResult.Success(user)
    }

    suspend fun quickDemoLogin(phone: String): AuthResult {
        val user = userDao.getUserByPhone(phone)
            ?: return AuthResult.Error("auth_error_not_found")
        if (user.isSuspended) {
            return AuthResult.Error("auth_error_suspended")
        }
        prefs.setCurrentUserId(user.id)
        prefs.setLocation(user.city, user.area)
        return AuthResult.Success(user)
    }

    suspend fun registerUser(
        name: String,
        phone: String,
        pin: String,
        role: UserRole,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int
    ): AuthResult {
        val cleanPhone = phone.trim()
        if (userDao.getUserByPhone(cleanPhone) != null) {
            return AuthResult.Error("auth_error_phone_exists")
        }
        val loc = IndianLocations.findLocation(city, area)
        val userId = userDao.insertUser(
            UserEntity(
                name = name.trim(),
                phone = cleanPhone,
                pin = pin.trim(),
                role = role,
                city = loc.city,
                area = loc.area,
                latitude = loc.latitude,
                longitude = loc.longitude,
                primarySkill = skill,
                experienceYears = experienceYears,
                expectedDailyWage = expectedDailyWage,
                isAvailable = true,
                isVerified = false,
                rating = 5.0,
                completedJobs = 0
            )
        )
        val created = userDao.getUserById(userId)!!
        prefs.setCurrentUserId(userId)
        prefs.setLocation(loc.city, loc.area)

        notificationDao.insertNotification(
            NotificationEntity(
                userId = userId,
                targetRole = role.name,
                title = "Welcome to DailyWork, ${created.name}!",
                message = if (role == UserRole.WORKER) {
                    "Your worker profile in ${loc.displayName} is live. Tap Apply on nearby jobs!"
                } else {
                    "Your employer account is ready. Post a daily wage job to hire workers fast."
                },
                type = NotificationType.ADMIN_ALERT
            )
        )
        return AuthResult.Success(created)
    }

    suspend fun logout() {
        prefs.setCurrentUserId(null)
    }

    suspend fun updateUserProfile(user: UserEntity) {
        val loc = IndianLocations.findLocation(user.city, user.area)
        userDao.updateUser(
            user.copy(
                city = loc.city,
                area = loc.area,
                latitude = loc.latitude,
                longitude = loc.longitude
            )
        )
        prefs.setLocation(loc.city, loc.area)
    }

    suspend fun toggleWorkerAvailability(user: UserEntity) {
        userDao.updateUser(user.copy(isAvailable = !user.isAvailable))
    }

    suspend fun postJob(
        employer: UserEntity,
        title: String,
        category: WorkCategory,
        description: String,
        city: String,
        area: String,
        dailyWage: Int,
        workersNeeded: Int,
        durationDays: Int,
        shiftTiming: String,
        includesMeals: Boolean
    ): Long {
        val loc = IndianLocations.findLocation(city, area)
        val jobId = jobDao.insertJob(
            JobEntity(
                employerId = employer.id,
                employerName = employer.name,
                employerPhone = employer.phone,
                title = title.trim(),
                category = category,
                description = description.trim(),
                city = loc.city,
                area = loc.area,
                latitude = loc.latitude,
                longitude = loc.longitude,
                dailyWage = dailyWage,
                workersNeeded = workersNeeded,
                workDurationDays = durationDays,
                shiftTiming = shiftTiming,
                includesMeals = includesMeals,
                status = JobStatus.OPEN
            )
        )

        // Broadcast notification to workers about new daily job
        notificationDao.insertNotification(
            NotificationEntity(
                userId = 0L,
                targetRole = UserRole.WORKER.name,
                title = "New Job: ${title.trim()} (₹$dailyWage/day)",
                message = "${employer.name} needs $workersNeeded worker(s) in ${loc.displayName}.",
                type = NotificationType.NEW_JOB
            )
        )
        return jobId
    }

    suspend fun updateJobStatus(job: JobEntity, newStatus: JobStatus) {
        jobDao.updateJob(job.copy(status = newStatus))
    }

    suspend fun deleteJob(job: JobEntity) {
        jobDao.deleteJob(job)
    }

    suspend fun applyForJob(worker: UserEntity, job: JobEntity, note: String): Boolean {
        val existing = applicationDao.findApplication(job.id, worker.id)
        if (existing != null) return false

        applicationDao.insertApplication(
            ApplicationEntity(
                jobId = job.id,
                workerId = worker.id,
                workerName = worker.name,
                workerPhone = worker.phone,
                workerSkill = worker.primarySkill,
                workerArea = "${worker.area}, ${worker.city}",
                employerId = job.employerId,
                status = ApplicationStatus.PENDING,
                note = note.ifBlank { "${worker.experienceYears} yrs exp • Expected ₹${worker.expectedDailyWage}/day" }
            )
        )

        notificationDao.insertNotification(
            NotificationEntity(
                userId = job.employerId,
                targetRole = UserRole.EMPLOYER.name,
                title = "New Applicant: ${worker.name}",
                message = "${worker.name} applied for ${job.title} (₹${job.dailyWage}/day). Call ${worker.phone}.",
                type = NotificationType.APPLICATION_RECEIVED
            )
        )
        return true
    }

    suspend fun updateApplicationStatus(
        application: ApplicationEntity,
        newStatus: ApplicationStatus,
        jobTitle: String
    ) {
        applicationDao.updateApplication(application.copy(status = newStatus))

        if (newStatus == ApplicationStatus.COMPLETED) {
            userDao.getUserById(application.workerId)?.let { worker ->
                userDao.updateUser(worker.copy(completedJobs = worker.completedJobs + 1))
            }
        }

        val (notifType, notifTitle, notifMsg) = when (newStatus) {
            ApplicationStatus.ACCEPTED -> Triple(
                NotificationType.APPLICATION_ACCEPTED,
                "Hired! $jobTitle",
                "Your application was accepted! Please call the employer to confirm shift timing."
            )
            ApplicationStatus.REJECTED -> Triple(
                NotificationType.APPLICATION_REJECTED,
                "Application Update: $jobTitle",
                "Employer chose another worker for this slot. Apply to other nearby jobs!"
            )
            ApplicationStatus.COMPLETED -> Triple(
                NotificationType.JOB_COMPLETED,
                "Work Completed: $jobTitle",
                "Great work! This job has been marked completed on your DailyWork profile."
            )
            ApplicationStatus.PENDING -> return
        }

        notificationDao.insertNotification(
            NotificationEntity(
                userId = application.workerId,
                targetRole = UserRole.WORKER.name,
                title = notifTitle,
                message = notifMsg,
                type = notifType
            )
        )
    }

    suspend fun markNotificationRead(id: Long) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead(userId: Long) {
        notificationDao.markAllAsRead(userId)
    }

    // Admin actions
    suspend fun toggleVerifyUser(user: UserEntity) {
        userDao.updateUser(user.copy(isVerified = !user.isVerified))
    }

    suspend fun toggleSuspendUser(user: UserEntity) {
        userDao.updateUser(user.copy(isSuspended = !user.isSuspended))
    }

    suspend fun sendAdminBroadcast(title: String, message: String, targetRole: String) {
        notificationDao.insertNotification(
            NotificationEntity(
                userId = 0L,
                targetRole = targetRole,
                title = title.trim(),
                message = message.trim(),
                type = NotificationType.ADMIN_ALERT
            )
        )
    }
}
