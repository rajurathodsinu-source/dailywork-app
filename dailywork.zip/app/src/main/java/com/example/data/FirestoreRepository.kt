package com.example.data

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        Firebase.auth
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun handleFlowError(error: Throwable, op: OperationType, path: String, expectedUid: String? = null) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && (expectedUid == null || auth.currentUser?.uid == expectedUid)) {
            handleFirestoreError(exceptionToLog, op, path, auth)
        }
    }

    fun observeUserProfile(uid: String): Flow<FirestoreUser?> = flow {
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(FirestoreUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    handleFlowError(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    suspend fun getUserProfile(uid: String): FirestoreUser? {
        val docRef = db.collection("users").document(uid)
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) null
            else snap.toObject(FirestoreUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path, auth)
            throw e
        }
    }

    suspend fun isUserInAdminsCollection(uid: String): Boolean {
        val docRef = db.collection("admins").document(uid)
        return try {
            docRef.get().await().exists()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path, auth)
            false
        }
    }

    fun observeServiceAreasConfig(): Flow<FirestoreServiceAreasConfig> = flow {
        val path = "app_config/service_areas"
        emitAll(
            db.collection("app_config").document("service_areas")
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) {
                        FirestoreServiceAreasConfig.defaultLaunchConfig()
                    } else {
                        snap.toObject(
                            FirestoreServiceAreasConfig::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )?.let { cfg ->
                            if (cfg.enabledCities.isEmpty()) FirestoreServiceAreasConfig.defaultLaunchConfig()
                            else cfg
                        } ?: FirestoreServiceAreasConfig.defaultLaunchConfig()
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    emit(FirestoreServiceAreasConfig.defaultLaunchConfig())
                }
        )
    }

    suspend fun getActiveServiceAreasConfig(): FirestoreServiceAreasConfig {
        val docRef = db.collection("app_config").document("service_areas")
        return try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                FirestoreServiceAreasConfig.defaultLaunchConfig()
            } else {
                snap.toObject(
                    FirestoreServiceAreasConfig::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )?.takeIf { it.enabledCities.isNotEmpty() }
                    ?: FirestoreServiceAreasConfig.defaultLaunchConfig()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            FirestoreServiceAreasConfig.defaultLaunchConfig()
        }
    }

    suspend fun saveServiceAreasConfig(
        enabledCities: List<String>,
        cities: List<ServiceAreaCity>
    ): FirestoreServiceAreasConfig {
        val uid = requireUserId()
        val cleanEnabled = enabledCities.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        require(cleanEnabled.isNotEmpty()) { "At least one service city must remain enabled." }

        val payloadCities = cities.map { city ->
            mapOf(
                "city" to city.city.trim(),
                "state" to city.state.trim().ifBlank { "Telangana" },
                "latitude" to city.latitude,
                "longitude" to city.longitude,
                "localities" to city.localities
                    .filter { it.area.isNotBlank() }
                    .distinctBy { it.area.trim().lowercase() }
                    .map { loc ->
                        mapOf(
                            "area" to loc.area.trim(),
                            "latitude" to loc.latitude,
                            "longitude" to loc.longitude
                        )
                    }
            )
        }

        val docRef = db.collection("app_config").document("service_areas")
        try {
            docRef.set(
                mapOf(
                    "enabledCities" to cleanEnabled,
                    "cities" to payloadCities,
                    "updatedBy" to uid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return docRef.get().await().toObject(
                FirestoreServiceAreasConfig::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: FirestoreServiceAreasConfig(
                id = "service_areas",
                enabledCities = cleanEnabled,
                cities = cities,
                updatedBy = uid
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            throw e
        }
    }

    suspend fun toggleServiceAreaCity(
        current: FirestoreServiceAreasConfig,
        cityName: String,
        enable: Boolean
    ): FirestoreServiceAreasConfig {
        val cleanCity = cityName.trim()
        require(cleanCity.isNotBlank()) { "City name cannot be blank" }
        val currentEnabled = current.activeCityNames().toMutableList()
        if (enable) {
            if (currentEnabled.none { it.equals(cleanCity, ignoreCase = true) }) {
                currentEnabled.add(cleanCity)
            }
        } else {
            val filtered = currentEnabled.filterNot { it.equals(cleanCity, ignoreCase = true) }
            require(filtered.isNotEmpty()) { "At least one service city must stay active." }
            currentEnabled.clear()
            currentEnabled.addAll(filtered)
        }

        val existingCities = current.cities.toMutableList()
        if (enable && existingCities.none { it.city.equals(cleanCity, ignoreCase = true) }) {
            val catalogEntries = IndianLocations.allKnownLocations.filter {
                it.city.equals(cleanCity, ignoreCase = true)
            }
            val first = catalogEntries.firstOrNull() ?: IndianLocations.defaultLocation.copy(
                city = cleanCity,
                area = cleanCity
            )
            existingCities.add(
                ServiceAreaCity(
                    city = first.city,
                    state = first.state,
                    latitude = first.latitude,
                    longitude = first.longitude,
                    localities = catalogEntries.map {
                        ServiceAreaLocality(it.area, it.latitude, it.longitude)
                    }.ifEmpty {
                        listOf(ServiceAreaLocality(cleanCity, first.latitude, first.longitude))
                    }
                )
            )
        }
        return saveServiceAreasConfig(currentEnabled, existingCities)
    }

    suspend fun addCustomServiceArea(
        current: FirestoreServiceAreasConfig,
        cityName: String,
        state: String,
        localityName: String,
        latitude: Double? = null,
        longitude: Double? = null
    ): FirestoreServiceAreasConfig {
        val cleanCity = cityName.trim()
        val cleanLocality = localityName.trim()
        val cleanState = state.trim().ifBlank { "Telangana" }
        require(cleanCity.isNotBlank() && cleanLocality.isNotBlank()) {
            "Both city and locality are required."
        }

        val known = IndianLocations.allKnownLocations.firstOrNull {
            it.city.equals(cleanCity, ignoreCase = true) && it.area.equals(cleanLocality, ignoreCase = true)
        } ?: IndianLocations.allKnownLocations.firstOrNull {
            it.city.equals(cleanCity, ignoreCase = true)
        }
        val lat = latitude ?: known?.latitude ?: IndianLocations.defaultLocation.latitude
        val lng = longitude ?: known?.longitude ?: IndianLocations.defaultLocation.longitude

        val currentEnabled = current.activeCityNames().toMutableList()
        if (currentEnabled.none { it.equals(cleanCity, ignoreCase = true) }) {
            currentEnabled.add(cleanCity)
        }

        val updatedCities = current.cities.toMutableList()
        val idx = updatedCities.indexOfFirst { it.city.equals(cleanCity, ignoreCase = true) }
        val newLocality = ServiceAreaLocality(area = cleanLocality, latitude = lat, longitude = lng)
        if (idx >= 0) {
            val target = updatedCities[idx]
            val mergedLocalities = (target.localities + newLocality)
                .distinctBy { it.area.trim().lowercase() }
            updatedCities[idx] = target.copy(localities = mergedLocalities)
        } else {
            val catalogLocalities = IndianLocations.allKnownLocations
                .filter { it.city.equals(cleanCity, ignoreCase = true) }
                .map { ServiceAreaLocality(it.area, it.latitude, it.longitude) }
            val mergedLocalities = (catalogLocalities + newLocality)
                .distinctBy { it.area.trim().lowercase() }
            updatedCities.add(
                ServiceAreaCity(
                    city = cleanCity,
                    state = known?.state ?: cleanState,
                    latitude = lat,
                    longitude = lng,
                    localities = mergedLocalities
                )
            )
        }
        return saveServiceAreasConfig(currentEnabled, updatedCities)
    }

    suspend fun registerProfile(
        name: String,
        phone: String,
        role: UserRole,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int,
        skills: List<WorkCategory> = listOf(skill),
        spokenLanguages: List<String> = emptyList(),
        gender: WorkerGender? = null,
        availabilityStatus: WorkAvailability = WorkAvailability.AVAILABLE_TODAY,
        profilePhotoBase64: String = "",
        activeLocations: List<IndianLocation>? = null
    ): FirestoreUser {
        val uid = requireUserId()
        require(role == UserRole.WORKER || role == UserRole.EMPLOYER) {
            "Registration role must be WORKER or EMPLOYER"
        }
        val pool = activeLocations ?: getActiveServiceAreasConfig().toIndianLocations()
        val loc = IndianLocations.findActiveLocation(city, area, pool)
            ?: throw IllegalArgumentException(
                "Registration is currently available only in: ${pool.map { it.city }.distinct().joinToString(", ")}"
            )
        val cleanSkills = skills.distinct().ifEmpty { listOf(skill) }
        val primary = cleanSkills.first()
        val cleanLanguages = spokenLanguages.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(10)
        val cleanPhoto = profilePhotoBase64.take(120_000)
        val effectiveAvailable = if (role == UserRole.WORKER) availabilityStatus.isAvailableToday else true

        val userPayload = mapOf(
            "uid" to uid,
            "name" to name.trim(),
            "phone" to phone.trim(),
            "role" to role.name,
            "city" to loc.city,
            "area" to loc.area,
            "latitude" to loc.latitude,
            "longitude" to loc.longitude,
            "primarySkill" to primary.name,
            "skills" to cleanSkills.map { it.name },
            "spokenLanguages" to cleanLanguages,
            "gender" to (gender?.name ?: ""),
            "availabilityStatus" to availabilityStatus.name,
            "profilePhotoBase64" to cleanPhoto,
            "experienceYears" to experienceYears.toLong(),
            "expectedDailyWage" to expectedDailyWage.toLong(),
            "isAvailable" to effectiveAvailable,
            "isVerified" to false,
            "isSuspended" to false,
            "rating" to 5.0,
            "completedJobs" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val userRef = db.collection("users").document(uid)
        try {
            userRef.set(userPayload).await()
            if (role == UserRole.WORKER) {
                val dirRef = db.collection("worker_directory").document(uid)
                dirRef.set(userPayload.filterKeys { it != "role" }).await()
            }
            return userRef.get().await().toObject(
                FirestoreUser::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )!!
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, userRef.path, auth)
            throw e
        }
    }

    suspend fun updateProfile(
        existing: FirestoreUser,
        name: String,
        phone: String,
        city: String,
        area: String,
        skill: WorkCategory,
        experienceYears: Int,
        expectedDailyWage: Int,
        isAvailable: Boolean? = null,
        skills: List<WorkCategory> = existing.skillsEnumList(),
        spokenLanguages: List<String> = existing.spokenLanguagesList(),
        gender: WorkerGender? = existing.genderEnum(),
        availabilityStatus: WorkAvailability? = null,
        profilePhotoBase64: String = existing.profilePhotoBase64,
        activeLocations: List<IndianLocation>? = null
    ) {
        val uid = requireUserId()
        require(existing.uid == uid) { "Cannot update another user's profile" }
        val pool = activeLocations ?: getActiveServiceAreasConfig().toIndianLocations()
        val loc = IndianLocations.findActiveLocation(city, area, pool)
            ?: if (city.trim().equals(existing.city.trim(), ignoreCase = true) && area.isNotBlank()) {
                IndianLocation(existing.city, area.trim(), "Telangana", existing.latitude, existing.longitude)
            } else {
                throw IllegalArgumentException(
                    "Service is currently available only in: ${pool.map { it.city }.distinct().joinToString(", ")}"
                )
            }
        val cleanSkills = skills.distinct().ifEmpty { listOf(skill) }
        val primary = cleanSkills.first()
        val cleanLanguages = spokenLanguages.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(10)
        val cleanPhoto = profilePhotoBase64.take(120_000)
        val effectiveStatus = availabilityStatus ?: if (isAvailable != null) {
            if (isAvailable) WorkAvailability.AVAILABLE_TODAY else WorkAvailability.NOT_AVAILABLE
        } else {
            existing.availabilityEnum()
        }
        val effectiveAvailable = isAvailable ?: effectiveStatus.isAvailableToday

        val updates = mapOf(
            "name" to name.trim(),
            "phone" to phone.trim(),
            "city" to loc.city,
            "area" to loc.area,
            "latitude" to loc.latitude,
            "longitude" to loc.longitude,
            "primarySkill" to primary.name,
            "skills" to cleanSkills.map { it.name },
            "spokenLanguages" to cleanLanguages,
            "gender" to (gender?.name ?: ""),
            "availabilityStatus" to effectiveStatus.name,
            "profilePhotoBase64" to cleanPhoto,
            "experienceYears" to experienceYears.toLong(),
            "expectedDailyWage" to expectedDailyWage.toLong(),
            "isAvailable" to effectiveAvailable,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val userRef = db.collection("users").document(uid)
        try {
            userRef.update(updates).await()
            if (existing.roleEnum() == UserRole.WORKER) {
                val dirRef = db.collection("worker_directory").document(uid)
                val dirSnap = dirRef.get().await()
                if (dirSnap.exists()) {
                    dirRef.update(updates).await()
                } else {
                    val fullDir = mapOf(
                        "uid" to uid,
                        "name" to name.trim(),
                        "phone" to phone.trim(),
                        "city" to loc.city,
                        "area" to loc.area,
                        "latitude" to loc.latitude,
                        "longitude" to loc.longitude,
                        "primarySkill" to primary.name,
                        "skills" to cleanSkills.map { it.name },
                        "spokenLanguages" to cleanLanguages,
                        "gender" to (gender?.name ?: ""),
                        "availabilityStatus" to effectiveStatus.name,
                        "profilePhotoBase64" to cleanPhoto,
                        "experienceYears" to experienceYears.toLong(),
                        "expectedDailyWage" to expectedDailyWage.toLong(),
                        "isAvailable" to effectiveAvailable,
                        "isVerified" to existing.isVerified,
                        "isSuspended" to existing.isSuspended,
                        "rating" to existing.rating,
                        "completedJobs" to existing.completedJobs,
                        "createdAt" to (existing.createdAt ?: FieldValue.serverTimestamp()),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    dirRef.set(fullDir).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path, auth)
            throw e
        }
    }

    suspend fun toggleWorkerAvailability(existing: FirestoreUser) {
        val nextStatus = if (existing.isAvailable) {
            WorkAvailability.NOT_AVAILABLE
        } else {
            WorkAvailability.AVAILABLE_TODAY
        }
        updateProfile(
            existing = existing,
            name = existing.name,
            phone = existing.phone,
            city = existing.city,
            area = existing.area,
            skill = existing.skillEnum(),
            experienceYears = existing.experienceYears.toInt(),
            expectedDailyWage = existing.expectedDailyWage.toInt(),
            isAvailable = nextStatus.isAvailableToday,
            availabilityStatus = nextStatus
        )
    }

    fun observeOpenJobs(): Flow<List<FirestoreJob>> = flow {
        val uid = requireUserId()
        val path = "jobs"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", JobStatus.OPEN.name)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreJob::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeEmployerJobs(employerId: String): Flow<List<FirestoreJob>> = flow {
        val path = "jobs"
        emitAll(
            db.collection(path)
                .whereEqualTo("employerId", employerId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreJob::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, employerId)
                    throw error
                }
        )
    }

    fun observeWorkerDirectory(): Flow<List<FirestoreUser>> = flow {
        val uid = requireUserId()
        val path = "worker_directory"
        emitAll(
            db.collection(path)
                .whereEqualTo("isSuspended", false)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedWith(compareByDescending<FirestoreUser> { it.isVerified }.thenByDescending { it.rating })
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun postJob(
        employer: FirestoreUser,
        title: String,
        category: WorkCategory,
        description: String,
        city: String,
        area: String,
        dailyWage: Int,
        workersNeeded: Int,
        durationDays: Int,
        shiftTiming: String,
        includesMeals: Boolean,
        activeLocations: List<IndianLocation>? = null
    ): String {
        val uid = requireUserId()
        val pool = activeLocations ?: getActiveServiceAreasConfig().toIndianLocations()
        val loc = IndianLocations.findActiveLocation(city, area, pool)
            ?: throw IllegalArgumentException(
                "Jobs can currently be posted only in: ${pool.map { it.city }.distinct().joinToString(", ")}"
            )
        val jobId = "job_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val jobRef = db.collection("jobs").document(jobId)
        val payload = mapOf(
            "employerId" to uid,
            "employerName" to employer.name,
            "employerPhone" to employer.phone,
            "title" to title.trim(),
            "category" to category.name,
            "description" to description.trim(),
            "city" to loc.city,
            "area" to loc.area,
            "latitude" to loc.latitude,
            "longitude" to loc.longitude,
            "dailyWage" to dailyWage.toLong(),
            "workersNeeded" to workersNeeded.toLong(),
            "workDurationDays" to durationDays.toLong(),
            "shiftTiming" to shiftTiming,
            "includesMeals" to includesMeals,
            "status" to JobStatus.OPEN.name,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            jobRef.set(payload).await()
            // Send real-time broadcast notification to workers
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to "BROADCAST",
                    "senderId" to uid,
                    "targetRole" to UserRole.WORKER.name,
                    "title" to "New Job: ${title.trim()} (₹$dailyWage/day)",
                    "message" to "${employer.name} needs $workersNeeded worker(s) in ${loc.displayName}.",
                    "type" to NotificationType.NEW_JOB.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return jobId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, jobRef.path, auth)
            throw e
        }
    }

    suspend fun updateJobStatus(job: FirestoreJob, newStatus: JobStatus) {
        requireUserId()
        require(job.id.isNotBlank()) { "Job ID must not be blank" }
        val jobRef = db.collection("jobs").document(job.id)
        try {
            jobRef.update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, jobRef.path, auth)
            throw e
        }
    }

    suspend fun deleteJob(jobId: String) {
        requireUserId()
        val jobRef = db.collection("jobs").document(jobId)
        try {
            jobRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, jobRef.path, auth)
            throw e
        }
    }

    fun observeWorkerApplications(workerId: String): Flow<List<FirestoreApplication>> = flow {
        val path = "applications"
        emitAll(
            db.collection(path)
                .whereEqualTo("workerId", workerId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.appliedAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, workerId)
                    throw error
                }
        )
    }

    fun observeEmployerApplications(employerId: String): Flow<List<FirestoreApplication>> = flow {
        val path = "applications"
        emitAll(
            db.collection(path)
                .whereEqualTo("employerId", employerId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.appliedAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, employerId)
                    throw error
                }
        )
    }

    suspend fun applyForJob(worker: FirestoreUser, job: FirestoreJob, note: String): Boolean {
        val uid = requireUserId()
        val appId = "${job.id}_${uid}"
        val appRef = db.collection("applications").document(appId)
        try {
            if (appRef.get().await().exists()) return false
            val finalNote = note.trim().ifBlank {
                "${worker.experienceYears} yrs exp • Expected ₹${worker.expectedDailyWage}/day"
            }.take(300)
            appRef.set(
                mapOf(
                    "jobId" to job.id,
                    "jobTitle" to job.title,
                    "dailyWage" to job.dailyWage,
                    "employerId" to job.employerId,
                    "employerName" to job.employerName,
                    "employerPhone" to job.employerPhone,
                    "jobCity" to job.city,
                    "jobArea" to job.area,
                    "workerId" to uid,
                    "workerName" to worker.name,
                    "workerPhone" to worker.phone,
                    "workerSkill" to worker.primarySkill,
                    "workerArea" to "${worker.area}, ${worker.city}",
                    "status" to ApplicationStatus.PENDING.name,
                    "note" to finalNote,
                    "appliedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to job.employerId,
                    "senderId" to uid,
                    "targetRole" to UserRole.EMPLOYER.name,
                    "title" to "New Applicant: ${worker.name}",
                    "message" to "${worker.name} applied for ${job.title} (₹${job.dailyWage}/day). Call ${worker.phone}.",
                    "type" to NotificationType.APPLICATION_RECEIVED.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, appRef.path, auth)
            throw e
        }
    }

    suspend fun updateApplicationStatus(
        application: FirestoreApplication,
        newStatus: ApplicationStatus
    ) {
        val uid = requireUserId()
        val appRef = db.collection("applications").document(application.id)
        try {
            appRef.update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val (notifType, notifTitle, notifMsg) = when (newStatus) {
                ApplicationStatus.ACCEPTED -> Triple(
                    NotificationType.APPLICATION_ACCEPTED,
                    "Hired! ${application.jobTitle}",
                    "Your application was accepted! Call ${application.employerName} (${application.employerPhone})."
                )
                ApplicationStatus.REJECTED -> Triple(
                    NotificationType.APPLICATION_REJECTED,
                    "Application Update: ${application.jobTitle}",
                    "Employer chose another worker for this slot. Apply to other nearby jobs!"
                )
                ApplicationStatus.COMPLETED -> Triple(
                    NotificationType.JOB_COMPLETED,
                    "Work Completed: ${application.jobTitle}",
                    "Great work! Your job has been marked completed."
                )
                ApplicationStatus.PENDING -> return
            }

            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to application.workerId,
                    "senderId" to uid,
                    "targetRole" to UserRole.WORKER.name,
                    "title" to notifTitle,
                    "message" to notifMsg,
                    "type" to notifType.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, appRef.path, auth)
            throw e
        }
    }

    fun observeNotifications(uid: String): Flow<List<FirestoreNotification>> = flow {
        val path = "notifications"
        emitAll(
            db.collection(path)
                .whereIn("userId", listOf(uid, "BROADCAST"))
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun markNotificationRead(notificationId: String) {
        val uid = requireUserId()
        val ref = db.collection("notifications").document(notificationId)
        try {
            val snap = ref.get().await()
            if (snap.exists() && snap.getString("userId") == uid) {
                ref.update("isRead", true).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            throw e
        }
    }

    // --- Admin Streams & Moderation ---

    fun observeAllUsersAdmin(): Flow<List<FirestoreUser>> = flow {
        val uid = requireUserId()
        val path = "users"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllJobsAdmin(): Flow<List<FirestoreJob>> = flow {
        val uid = requireUserId()
        val path = "jobs"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreJob::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllApplicationsAdmin(): Flow<List<FirestoreApplication>> = flow {
        val uid = requireUserId()
        val path = "applications"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllNotificationsAdmin(): Flow<List<FirestoreNotification>> = flow {
        val uid = requireUserId()
        val path = "notifications"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun toggleVerifyUser(user: FirestoreUser) {
        requireUserId()
        val next = !user.isVerified
        val userRef = db.collection("users").document(user.uid)
        try {
            userRef.update(mapOf("isVerified" to next, "updatedAt" to FieldValue.serverTimestamp())).await()
            if (user.roleEnum() == UserRole.WORKER) {
                val dirRef = db.collection("worker_directory").document(user.uid)
                if (dirRef.get().await().exists()) {
                    dirRef.update(mapOf("isVerified" to next, "updatedAt" to FieldValue.serverTimestamp())).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path, auth)
            throw e
        }
    }

    suspend fun toggleSuspendUser(user: FirestoreUser) {
        requireUserId()
        val next = !user.isSuspended
        val userRef = db.collection("users").document(user.uid)
        try {
            userRef.update(mapOf("isSuspended" to next, "updatedAt" to FieldValue.serverTimestamp())).await()
            if (user.roleEnum() == UserRole.WORKER) {
                val dirRef = db.collection("worker_directory").document(user.uid)
                if (dirRef.get().await().exists()) {
                    dirRef.update(mapOf("isSuspended" to next, "updatedAt" to FieldValue.serverTimestamp())).await()
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userRef.path, auth)
            throw e
        }
    }

    suspend fun sendAdminBroadcast(title: String, message: String, targetRole: String) {
        val uid = requireUserId()
        val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val ref = db.collection("notifications").document(notifId)
        try {
            ref.set(
                mapOf(
                    "userId" to "BROADCAST",
                    "senderId" to uid,
                    "targetRole" to targetRole,
                    "title" to title.trim(),
                    "message" to message.trim(),
                    "type" to NotificationType.ADMIN_ALERT.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            throw e
        }
    }

    /**
     * Safely migrates a user's previously stored local Room profile & user-created jobs into Firestore
     * under their authenticated Firebase UID (non-destructive: Room records stay intact locally).
     */
    suspend fun migrateLocalEmployerJobs(
        employer: FirestoreUser,
        localJobs: List<JobEntity>
    ): Int {
        val uid = requireUserId()
        var migrated = 0
        for (localJob in localJobs) {
            val jobId = "mig_job_${uid.take(8)}_${localJob.id}"
            val jobRef = db.collection("jobs").document(jobId)
            try {
                if (!jobRef.get().await().exists()) {
                    jobRef.set(
                        mapOf(
                            "employerId" to uid,
                            "employerName" to employer.name,
                            "employerPhone" to employer.phone,
                            "title" to localJob.title,
                            "category" to localJob.category.name,
                            "description" to localJob.description,
                            "city" to localJob.city,
                            "area" to localJob.area,
                            "latitude" to localJob.latitude,
                            "longitude" to localJob.longitude,
                            "dailyWage" to localJob.dailyWage.toLong(),
                            "workersNeeded" to localJob.workersNeeded.toLong(),
                            "workDurationDays" to localJob.workDurationDays.toLong(),
                            "shiftTiming" to localJob.shiftTiming,
                            "includesMeals" to localJob.includesMeals,
                            "status" to localJob.status.name,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        ),
                        SetOptions.merge()
                    ).await()
                    migrated++
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, jobRef.path, auth)
            }
        }
        return migrated
    }

    // =====================================================================
    // MODULE 2: FILM DIRECT CONNECT
    // =====================================================================

    fun observeArtistProfile(uid: String): Flow<FirestoreArtistProfile?> = flow {
        val path = "artist_profiles/$uid"
        emitAll(
            db.collection("artist_profiles").document(uid)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(FirestoreArtistProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    handleFlowError(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    suspend fun saveArtistProfile(
        existing: FirestoreArtistProfile?,
        name: String,
        age: Int,
        gender: WorkerGender?,
        city: String,
        area: String,
        phone: String,
        languages: List<String>,
        experienceYears: Int,
        skills: List<ArtistSkill>,
        bio: String,
        photosBase64: List<String>,
        noBrokerConfirmed: Boolean,
        zeroFeeAcknowledged: Boolean,
        isAvailable: Boolean = true,
        activeLocations: List<IndianLocation>? = null
    ): FirestoreArtistProfile {
        val uid = requireUserId()
        require(noBrokerConfirmed && zeroFeeAcknowledged) {
            "Direct non-broker & zero-fee policy confirmation is required."
        }
        val pool = activeLocations ?: getActiveServiceAreasConfig().toIndianLocations()
        val loc = IndianLocations.findActiveLocation(city, area, pool)
            ?: throw IllegalArgumentException(
                "Film Connect is currently available only in: ${pool.map { it.city }.distinct().joinToString(", ")}"
            )
        val cleanLangs = languages.map { it.trim() }.filter { it.isNotBlank() }.distinct().ifEmpty { listOf("Telugu") }.take(10)
        val cleanSkills = skills.distinct().ifEmpty { listOf(ArtistSkill.JUNIOR_ARTIST) }.take(10)
        val cleanPhotos = photosBase64.map { it.take(115_000) }.filter { it.isNotBlank() }.take(3)
        val cleanAge = age.coerceIn(1, 100).toLong()
        val cleanExp = experienceYears.coerceIn(0, 60).toLong()
        val docRef = db.collection("artist_profiles").document(uid)

        try {
            if (existing == null) {
                val payload = mapOf(
                    "uid" to uid,
                    "name" to name.trim().take(80),
                    "age" to cleanAge,
                    "gender" to (gender?.name ?: ""),
                    "city" to loc.city,
                    "area" to loc.area,
                    "phone" to phone.trim().take(20),
                    "languages" to cleanLangs,
                    "experienceYears" to cleanExp,
                    "skills" to cleanSkills.map { it.name },
                    "bio" to bio.trim().take(400),
                    "photosBase64" to cleanPhotos,
                    "noBrokerConfirmed" to true,
                    "zeroFeeAcknowledged" to true,
                    "isAvailable" to isAvailable,
                    "isSuspended" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val updates = mapOf(
                    "name" to name.trim().take(80),
                    "age" to cleanAge,
                    "gender" to (gender?.name ?: ""),
                    "city" to loc.city,
                    "area" to loc.area,
                    "phone" to phone.trim().take(20),
                    "languages" to cleanLangs,
                    "experienceYears" to cleanExp,
                    "skills" to cleanSkills.map { it.name },
                    "bio" to bio.trim().take(400),
                    "photosBase64" to cleanPhotos,
                    "noBrokerConfirmed" to true,
                    "zeroFeeAcknowledged" to true,
                    "isAvailable" to isAvailable,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            }
            return docRef.get().await().toObject(
                FirestoreArtistProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )!!
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(
                e,
                if (existing == null) OperationType.CREATE else OperationType.UPDATE,
                docRef.path,
                auth
            )
            throw e
        }
    }

    fun observeCastingProfile(uid: String): Flow<FirestoreCastingProfile?> = flow {
        val path = "casting_profiles/$uid"
        emitAll(
            db.collection("casting_profiles").document(uid)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(FirestoreCastingProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    handleFlowError(error, OperationType.GET, path, uid)
                    throw error
                }
        )
    }

    suspend fun submitCastingVerification(
        existing: FirestoreCastingProfile?,
        accountType: CastingAccountType,
        organizationName: String,
        contactName: String,
        phone: String,
        city: String,
        area: String,
        projectCredits: String,
        idProofType: String,
        idReferenceMasked: String,
        verificationNotes: String,
        noBrokerConfirmed: Boolean,
        zeroFeeConfirmed: Boolean,
        activeLocations: List<IndianLocation>? = null
    ): FirestoreCastingProfile {
        val uid = requireUserId()
        require(noBrokerConfirmed && zeroFeeConfirmed) {
            "Brokers/Agents and commission fees are strictly prohibited on Film Direct Connect."
        }
        val pool = activeLocations ?: getActiveServiceAreasConfig().toIndianLocations()
        val loc = IndianLocations.findActiveLocation(city, area, pool)
            ?: throw IllegalArgumentException(
                "Service is currently available only in: ${pool.map { it.city }.distinct().joinToString(", ")}"
            )
        val docRef = db.collection("casting_profiles").document(uid)
        try {
            if (existing == null) {
                val payload = mapOf(
                    "uid" to uid,
                    "accountType" to accountType.name,
                    "organizationName" to organizationName.trim().take(100),
                    "contactName" to contactName.trim().take(80),
                    "phone" to phone.trim().take(20),
                    "city" to loc.city,
                    "area" to loc.area,
                    "projectCredits" to projectCredits.trim().take(400),
                    "idProofType" to idProofType.trim().take(60),
                    "idReferenceMasked" to idReferenceMasked.trim().take(60),
                    "verificationNotes" to verificationNotes.trim().take(300),
                    "noBrokerConfirmed" to true,
                    "zeroFeeConfirmed" to true,
                    "verificationStatus" to CastingVerificationStatus.PENDING.name,
                    "verifiedBy" to "",
                    "rejectionReason" to "",
                    "isSuspended" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                val updates = mapOf(
                    "accountType" to accountType.name,
                    "organizationName" to organizationName.trim().take(100),
                    "contactName" to contactName.trim().take(80),
                    "phone" to phone.trim().take(20),
                    "city" to loc.city,
                    "area" to loc.area,
                    "projectCredits" to projectCredits.trim().take(400),
                    "idProofType" to idProofType.trim().take(60),
                    "idReferenceMasked" to idReferenceMasked.trim().take(60),
                    "verificationNotes" to verificationNotes.trim().take(300),
                    "noBrokerConfirmed" to true,
                    "zeroFeeConfirmed" to true,
                    "verificationStatus" to CastingVerificationStatus.PENDING.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            }
            return docRef.get().await().toObject(
                FirestoreCastingProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )!!
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(
                e,
                if (existing == null) OperationType.CREATE else OperationType.UPDATE,
                docRef.path,
                auth
            )
            throw e
        }
    }

    fun observeOpenCastingPosts(): Flow<List<FirestoreCastingPost>> = flow {
        val uid = requireUserId()
        val path = "casting_posts"
        emitAll(
            db.collection(path)
                .whereEqualTo("status", JobStatus.OPEN.name)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreCastingPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeMyCastingPosts(posterId: String): Flow<List<FirestoreCastingPost>> = flow {
        val path = "casting_posts"
        emitAll(
            db.collection(path)
                .whereEqualTo("posterId", posterId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreCastingPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, posterId)
                    throw error
                }
        )
    }

    suspend fun postCastingRequirement(
        castingProfile: FirestoreCastingProfile,
        projectName: String,
        roleTitle: String,
        artistsNeeded: Int,
        minAge: Int,
        maxAge: Int,
        genderPreference: GenderPreference,
        languages: List<String>,
        shootingDate: String,
        reportingTime: String,
        city: String,
        area: String,
        paymentAmount: Int,
        paymentUnit: PaymentUnit,
        description: String,
        noBrokerConfirmed: Boolean,
        zeroFeeConfirmed: Boolean,
        activeLocations: List<IndianLocation>? = null
    ): String {
        val uid = requireUserId()
        require(castingProfile.verificationStatusEnum() == CastingVerificationStatus.VERIFIED) {
            "Your casting account must be verified by Admin before publishing casting requirements."
        }
        require(noBrokerConfirmed && zeroFeeConfirmed) {
            "Broker-free and ₹0 artist-fee confirmation is mandatory."
        }
        val pool = activeLocations ?: getActiveServiceAreasConfig().toIndianLocations()
        val loc = IndianLocations.findActiveLocation(city, area, pool)
            ?: throw IllegalArgumentException(
                "Casting shoots can currently be posted only in: ${pool.map { it.city }.distinct().joinToString(", ")}"
            )
        val cleanMinAge = minAge.coerceIn(1, 95)
        val cleanMaxAge = maxAge.coerceIn(cleanMinAge, 100)
        val cleanLangs = languages.map { it.trim() }.filter { it.isNotBlank() }.distinct().ifEmpty { listOf("Telugu") }.take(10)
        val cleanAmount = paymentAmount.coerceIn(100, 500_000).toLong()
        val cleanDate = shootingDate.trim().take(30)
        require(cleanDate.length >= 6) { "Enter a valid shooting date (e.g. 2026-11-28)" }
        val cleanTime = reportingTime.trim().take(40)
        require(cleanTime.length >= 2) { "Enter reporting time (e.g. 6:30 AM)" }

        val postId = "cast_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val postRef = db.collection("casting_posts").document(postId)
        val payload = mapOf(
            "posterId" to uid,
            "posterName" to castingProfile.contactName.trim().take(80),
            "organizationName" to castingProfile.organizationName.trim().take(100),
            "posterAccountType" to castingProfile.accountType,
            "posterVerified" to true,
            "projectName" to projectName.trim().take(120),
            "roleTitle" to roleTitle.trim().take(120),
            "artistsNeeded" to artistsNeeded.coerceIn(1, 500).toLong(),
            "minAge" to cleanMinAge.toLong(),
            "maxAge" to cleanMaxAge.toLong(),
            "genderPreference" to genderPreference.name,
            "languages" to cleanLangs,
            "shootingDate" to cleanDate,
            "reportingTime" to cleanTime,
            "city" to loc.city,
            "area" to loc.area,
            "latitude" to loc.latitude,
            "longitude" to loc.longitude,
            "paymentAmount" to cleanAmount,
            "paymentUnit" to paymentUnit.name,
            "description" to description.trim().take(600),
            "noBrokerConfirmed" to true,
            "zeroFeeConfirmed" to true,
            "status" to JobStatus.OPEN.name,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            postRef.set(payload).await()
            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to "BROADCAST",
                    "senderId" to uid,
                    "targetRole" to "ARTIST",
                    "title" to "Casting Call: ${roleTitle.trim()} (${projectName.trim()})",
                    "message" to "${castingProfile.organizationName} • ${loc.displayName} • $cleanDate • ₹$cleanAmount. Direct booking, zero fee.",
                    "type" to NotificationType.NEW_CASTING.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return postId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, postRef.path, auth)
            throw e
        }
    }

    suspend fun updateCastingPostStatus(post: FirestoreCastingPost, newStatus: JobStatus) {
        requireUserId()
        val ref = db.collection("casting_posts").document(post.id)
        try {
            ref.update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            throw e
        }
    }

    suspend fun deleteCastingPost(postId: String) {
        requireUserId()
        val ref = db.collection("casting_posts").document(postId)
        try {
            ref.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            throw e
        }
    }

    fun observeArtistCastingApplications(artistId: String): Flow<List<FirestoreCastingApplication>> = flow {
        val path = "casting_applications"
        emitAll(
            db.collection(path)
                .whereEqualTo("artistId", artistId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreCastingApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.appliedAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, artistId)
                    throw error
                }
        )
    }

    fun observeCastingOwnerApplications(castingOwnerId: String): Flow<List<FirestoreCastingApplication>> = flow {
        val path = "casting_applications"
        emitAll(
            db.collection(path)
                .whereEqualTo("castingOwnerId", castingOwnerId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreCastingApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.appliedAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, castingOwnerId)
                    throw error
                }
        )
    }

    suspend fun applyToCastingPost(
        artist: FirestoreArtistProfile,
        post: FirestoreCastingPost,
        note: String
    ): Boolean {
        val uid = requireUserId()
        val appId = "${post.id}_${uid}"
        val appRef = db.collection("casting_applications").document(appId)
        try {
            if (appRef.get().await().exists()) return false
            val cleanLangs = artist.languages.filter { it.isNotBlank() }.ifEmpty { listOf("Telugu") }.take(10)
            val cleanSkills = artist.skills.filter { it.isNotBlank() }.ifEmpty { listOf(ArtistSkill.JUNIOR_ARTIST.name) }.take(10)
            val cleanPhotos = artist.photosBase64.filter { it.isNotBlank() }.take(3)
            val finalNote = note.trim().ifBlank {
                "${artist.experienceYears} yrs exp • ${artist.area}, ${artist.city}"
            }.take(300)

            appRef.set(
                mapOf(
                    "postId" to post.id,
                    "projectName" to post.projectName,
                    "roleTitle" to post.roleTitle,
                    "castingOwnerId" to post.posterId,
                    "organizationName" to post.organizationName,
                    "posterAccountType" to post.posterAccountType,
                    "shootingDate" to post.shootingDate,
                    "reportingTime" to post.reportingTime,
                    "shootingCity" to post.city,
                    "shootingArea" to post.area,
                    "paymentAmount" to post.paymentAmount,
                    "paymentUnit" to post.paymentUnit,
                    "artistId" to uid,
                    "artistName" to artist.name,
                    "artistAge" to artist.age,
                    "artistCity" to artist.city,
                    "artistArea" to artist.area,
                    "artistPhone" to artist.phone,
                    "artistLanguages" to cleanLangs,
                    "artistExperienceYears" to artist.experienceYears,
                    "artistSkills" to cleanSkills,
                    "artistBio" to artist.bio.take(400),
                    "artistPhotosBase64" to cleanPhotos,
                    "note" to finalNote,
                    "noFeeAcknowledged" to true,
                    "status" to CastingApplicationStatus.PENDING.name,
                    "appliedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to post.posterId,
                    "senderId" to uid,
                    "targetRole" to "CASTING",
                    "title" to "New Artist Applicant: ${artist.name}",
                    "message" to "Applied for ${post.roleTitle} (${post.projectName}) • Age ${artist.age}, ${artist.area}, ${artist.city}.",
                    "type" to NotificationType.CASTING_APPLIED.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            return true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, appRef.path, auth)
            throw e
        }
    }

    suspend fun updateCastingApplicationStatus(
        application: FirestoreCastingApplication,
        newStatus: CastingApplicationStatus
    ) {
        val uid = requireUserId()
        val appRef = db.collection("casting_applications").document(application.id)
        try {
            appRef.update(
                mapOf(
                    "status" to newStatus.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val (notifType, notifTitle, notifMsg) = when (newStatus) {
                CastingApplicationStatus.SHORTLISTED -> Triple(
                    NotificationType.CASTING_SHORTLISTED,
                    "Shortlisted: ${application.roleTitle}",
                    "${application.organizationName} shortlisted your profile for ${application.projectName}."
                )
                CastingApplicationStatus.SELECTED -> Triple(
                    NotificationType.CASTING_SELECTED,
                    "Selected for Shoot! ${application.projectName}",
                    "Confirmed for ${application.roleTitle} on ${application.shootingDate} (${application.reportingTime}) at ${application.shootingArea}, ${application.shootingCity}. Pay: ₹${application.paymentAmount}."
                )
                CastingApplicationStatus.REJECTED -> Triple(
                    NotificationType.CASTING_APPLICATION_REJECTED,
                    "Casting Update: ${application.projectName}",
                    "Another artist was chosen for ${application.roleTitle}. Browse more direct casting calls!"
                )
                CastingApplicationStatus.PENDING -> return
            }

            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to application.artistId,
                    "senderId" to uid,
                    "targetRole" to "ARTIST",
                    "title" to notifTitle,
                    "message" to notifMsg,
                    "type" to notifType.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, appRef.path, auth)
            throw e
        }
    }

    fun observeBlockedEntities(uid: String): Flow<List<FirestoreBlockedEntity>> = flow {
        val path = "users/$uid/blocked_entities"
        emitAll(
            db.collection("users").document(uid).collection("blocked_entities")
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreBlockedEntity::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun blockEntity(
        targetId: String,
        targetType: ReportTargetType,
        targetLabel: String
    ) {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("blocked_entities").document(targetId)
        try {
            ref.set(
                mapOf(
                    "targetId" to targetId,
                    "targetType" to targetType.name,
                    "targetLabel" to targetLabel.trim().ifBlank { targetId }.take(140),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            throw e
        }
    }

    suspend fun unblockEntity(targetId: String) {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("blocked_entities").document(targetId)
        try {
            ref.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, ref.path, auth)
            throw e
        }
    }

    suspend fun submitContentReport(
        reporterName: String,
        targetId: String,
        targetType: ReportTargetType,
        targetOwnerId: String,
        targetLabel: String,
        reason: ReportReason,
        details: String
    ) {
        val uid = requireUserId()
        val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val ref = db.collection("content_reports").document(reportId)
        try {
            ref.set(
                mapOf(
                    "reporterId" to uid,
                    "reporterName" to reporterName.trim().ifBlank { "Member" }.take(80),
                    "targetId" to targetId.trim().take(128),
                    "targetType" to targetType.name,
                    "targetOwnerId" to targetOwnerId.trim().take(128),
                    "targetLabel" to targetLabel.trim().ifBlank { targetId }.take(140),
                    "reason" to reason.name,
                    "details" to details.trim().take(500),
                    "status" to ReportStatus.OPEN.name,
                    "adminActionNote" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path, auth)
            throw e
        }
    }

    // --- Admin Module 2 Moderation Streams & Actions ---

    fun observeAllCastingProfilesAdmin(): Flow<List<FirestoreCastingProfile>> = flow {
        val uid = requireUserId()
        val path = "casting_profiles"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreCastingProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllCastingPostsAdmin(): Flow<List<FirestoreCastingPost>> = flow {
        val uid = requireUserId()
        val path = "casting_posts"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreCastingPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    fun observeAllReportsAdmin(): Flow<List<FirestoreContentReport>> = flow {
        val uid = requireUserId()
        val path = "content_reports"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FirestoreContentReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    handleFlowError(error, OperationType.LIST, path, uid)
                    throw error
                }
        )
    }

    suspend fun adminVerifyCastingProfile(
        profile: FirestoreCastingProfile,
        approve: Boolean,
        rejectionReason: String = ""
    ) {
        val adminUid = requireUserId()
        val ref = db.collection("casting_profiles").document(profile.uid)
        val newStatus = if (approve) CastingVerificationStatus.VERIFIED else CastingVerificationStatus.REJECTED
        try {
            ref.update(
                mapOf(
                    "verificationStatus" to newStatus.name,
                    "verifiedBy" to adminUid,
                    "rejectionReason" to if (approve) "" else rejectionReason.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            val notifId = "notif_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            db.collection("notifications").document(notifId).set(
                mapOf(
                    "userId" to profile.uid,
                    "senderId" to adminUid,
                    "targetRole" to "CASTING",
                    "title" to if (approve) "Casting Account Verified!" else "Casting Verification Rejected",
                    "message" to if (approve) {
                        "${profile.organizationName} is verified. You can now publish direct casting requirements."
                    } else {
                        "Verification declined: ${rejectionReason.ifBlank { "Please resubmit valid production identity details." }}"
                    },
                    "type" to if (approve) NotificationType.CASTING_VERIFIED.name else NotificationType.CASTING_REJECTED.name,
                    "isRead" to false,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            throw e
        }
    }

    suspend fun adminToggleSuspendCastingProfile(profile: FirestoreCastingProfile) {
        requireUserId()
        val ref = db.collection("casting_profiles").document(profile.uid)
        try {
            ref.update(
                mapOf(
                    "isSuspended" to !profile.isSuspended,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path, auth)
            throw e
        }
    }

    suspend fun adminResolveReport(
        report: FirestoreContentReport,
        newStatus: ReportStatus,
        actionNote: String,
        removeReportedPost: Boolean = false,
        suspendReportedOwner: Boolean = false
    ) {
        requireUserId()
        val reportRef = db.collection("content_reports").document(report.id)
        try {
            if (removeReportedPost && report.targetTypeEnum() == ReportTargetType.CASTING_POST) {
                val postRef = db.collection("casting_posts").document(report.targetId)
                if (postRef.get().await().exists()) {
                    postRef.update(
                        mapOf(
                            "status" to JobStatus.CLOSED.name,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            if (suspendReportedOwner && report.targetOwnerId.isNotBlank()) {
                when (report.targetTypeEnum()) {
                    ReportTargetType.CASTING_POST, ReportTargetType.CASTING_PROFILE -> {
                        val cRef = db.collection("casting_profiles").document(report.targetOwnerId)
                        if (cRef.get().await().exists()) {
                            cRef.update(mapOf("isSuspended" to true, "updatedAt" to FieldValue.serverTimestamp())).await()
                        }
                    }
                    ReportTargetType.ARTIST_PROFILE -> {
                        val aRef = db.collection("artist_profiles").document(report.targetOwnerId)
                        if (aRef.get().await().exists()) {
                            aRef.update(mapOf("isSuspended" to true, "updatedAt" to FieldValue.serverTimestamp())).await()
                        }
                    }
                }
            }
            reportRef.update(
                mapOf(
                    "status" to newStatus.name,
                    "adminActionNote" to actionNote.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reportRef.path, auth)
            throw e
        }
    }
}
