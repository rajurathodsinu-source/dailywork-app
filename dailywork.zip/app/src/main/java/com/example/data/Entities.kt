package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val phone: String,
    val pin: String,
    val role: UserRole,
    val city: String,
    val area: String,
    val latitude: Double,
    val longitude: Double,
    val primarySkill: WorkCategory = WorkCategory.HELPER,
    val experienceYears: Int = 1,
    val expectedDailyWage: Int = 700,
    val isAvailable: Boolean = true,
    val isVerified: Boolean = false,
    val isSuspended: Boolean = false,
    val rating: Double = 4.6,
    val completedJobs: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "jobs")
data class JobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val employerId: Long,
    val employerName: String,
    val employerPhone: String,
    val title: String,
    val category: WorkCategory,
    val description: String,
    val city: String,
    val area: String,
    val latitude: Double,
    val longitude: Double,
    val dailyWage: Int,
    val workersNeeded: Int = 1,
    val workDurationDays: Int = 1,
    val shiftTiming: String = "8:00 AM - 5:00 PM",
    val includesMeals: Boolean = false,
    val status: JobStatus = JobStatus.OPEN,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "applications")
data class ApplicationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val jobId: Long,
    val workerId: Long,
    val workerName: String,
    val workerPhone: String,
    val workerSkill: WorkCategory,
    val workerArea: String,
    val employerId: Long,
    val status: ApplicationStatus = ApplicationStatus.PENDING,
    val note: String = "",
    val appliedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val userId: Long, // 0 means broadcast to all users
    val targetRole: String = "ALL", // "ALL", "WORKER", "EMPLOYER"
    val title: String,
    val message: String,
    val type: NotificationType,
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
