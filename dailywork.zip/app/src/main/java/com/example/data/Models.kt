package com.example.data

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

enum class AppLanguage(val code: String, val nativeLabel: String, val speechTag: String) {
    ENGLISH("en", "English", "en-IN"),
    TELUGU("te", "తెలుగు", "te-IN"),
    HINDI("hi", "हिन्दी", "hi-IN")
}

enum class UserRole {
    WORKER,
    EMPLOYER,
    ADMIN
}

enum class WorkCategory(val defaultDailyWage: Int) {
    MASON(900),
    HELPER(650),
    ELECTRICIAN(1000),
    PLUMBER(950),
    PAINTER(850),
    CARPENTER(950),
    LOADER(700),
    FARM_WORKER(600),
    CLEANER(600),
    DRIVER(900)
}

enum class JobStatus {
    OPEN,
    FILLED,
    CLOSED
}

enum class ApplicationStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    COMPLETED
}

enum class NotificationType {
    NEW_JOB,
    APPLICATION_RECEIVED,
    APPLICATION_ACCEPTED,
    APPLICATION_REJECTED,
    JOB_COMPLETED,
    ADMIN_ALERT,
    NEW_CASTING,
    CASTING_APPLIED,
    CASTING_SHORTLISTED,
    CASTING_SELECTED,
    CASTING_APPLICATION_REJECTED,
    CASTING_VERIFIED,
    CASTING_REJECTED
}

enum class AppModule {
    DAILY_LABOUR,
    FILM_CONNECT
}

enum class FilmSubRole {
    ARTIST,
    CASTING
}

enum class CastingAccountType {
    FILM_PRODUCER,
    FILM_DIRECTOR,
    PRODUCTION_HOUSE,
    CASTING_DIRECTOR,
    ASSISTANT_DIRECTOR,
    PRODUCTION_MANAGER,
    SHORT_FILM_PRODUCER,
    WEB_SERIES_PRODUCER,
    AD_FILM_MAKER
}

enum class CastingVerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED
}

enum class ArtistSkill {
    JUNIOR_ARTIST,
    SUPPORTING_ROLE,
    CROWD_ARTIST,
    DANCER,
    STUNT_ACTION,
    AD_MODEL,
    VOICE_DUBBING,
    FEATURED_EXTRA
}

enum class GenderPreference {
    ANY,
    MALE,
    FEMALE,
    OTHER
}

enum class PaymentUnit {
    PER_DAY,
    PER_PROJECT,
    PER_SHIFT
}

enum class CastingApplicationStatus {
    PENDING,
    SHORTLISTED,
    SELECTED,
    REJECTED
}

enum class ReportTargetType {
    CASTING_POST,
    CASTING_PROFILE,
    ARTIST_PROFILE
}

enum class ReportReason {
    BROKER_OR_AGENT,
    MONEY_OR_FEE_DEMAND,
    FAKE_CASTING,
    HARASSMENT,
    PRIVACY_VIOLATION
}

enum class ReportStatus {
    OPEN,
    RESOLVED,
    DISMISSED
}

enum class WorkerGender {
    MALE,
    FEMALE,
    OTHER
}

enum class WorkAvailability(val isAvailableToday: Boolean) {
    AVAILABLE_TODAY(true),
    AVAILABLE_THIS_WEEK(true),
    NOT_AVAILABLE(false)
}

object SpokenLanguages {
    val options: List<String> = listOf(
        "Telugu",
        "Hindi",
        "English",
        "Urdu",
        "Marathi",
        "Kannada",
        "Tamil"
    )
}

object IndianMobileValidator {
    private val MOBILE_REGEX = Regex("^[6-9][0-9]{9}$")

    fun sanitizeInput(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return when {
            digits.length > 10 && digits.startsWith("91") -> digits.drop(2).take(10)
            digits.length > 10 && digits.startsWith("0") -> digits.drop(1).take(10)
            else -> digits.take(10)
        }
    }

    fun isValid(phone: String): Boolean = MOBILE_REGEX.matches(sanitizeInput(phone))
}

data class IndianLocation(
    val city: String,
    val area: String,
    val state: String,
    val latitude: Double,
    val longitude: Double
) {
    val displayName: String get() = "$area, $city"
}

object IndianLocations {
    const val SERVICE_AREA_RADIUS_KM = 45.0

    val launchCities: List<String> = listOf("Hyderabad", "Warangal", "Hanamkonda", "Kazipet")

    val defaultLocation = IndianLocation("Warangal", "Chowrasta", "Telangana", 17.9689, 79.5941)

    val launchPresets: List<IndianLocation> = listOf(
        // Telangana: Hyderabad (Film & Commercial Hub)
        IndianLocation("Hyderabad", "Film Nagar", "Telangana", 17.4168, 78.4092),
        IndianLocation("Hyderabad", "Jubilee Hills", "Telangana", 17.4326, 78.4071),
        IndianLocation("Hyderabad", "Madhapur", "Telangana", 17.4483, 78.3915),
        IndianLocation("Hyderabad", "Ameerpet", "Telangana", 17.4375, 78.4482),
        IndianLocation("Hyderabad", "Secunderabad", "Telangana", 17.4399, 78.4983),
        IndianLocation("Hyderabad", "Kukatpally", "Telangana", 17.4948, 78.3996),
        IndianLocation("Hyderabad", "Gachibowli", "Telangana", 17.4401, 78.3489),
        IndianLocation("Hyderabad", "LB Nagar", "Telangana", 17.3457, 78.5522),
        IndianLocation("Hyderabad", "Uppal", "Telangana", 17.4058, 78.5591),
        IndianLocation("Hyderabad", "Miyapur", "Telangana", 17.4968, 78.3614),
        IndianLocation("Hyderabad", "Dilsukhnagar", "Telangana", 17.3688, 78.5247),
        // Telangana: Warangal
        IndianLocation("Warangal", "Chowrasta", "Telangana", 17.9689, 79.5941),
        IndianLocation("Warangal", "Enumamula", "Telangana", 17.9896, 79.6227),
        IndianLocation("Warangal", "Hunter Road", "Telangana", 17.9844, 79.5869),
        IndianLocation("Warangal", "Deshaipet", "Telangana", 17.9776, 79.6079),
        IndianLocation("Warangal", "Station Road", "Telangana", 17.9598, 79.6033),
        IndianLocation("Warangal", "Fort Warangal", "Telangana", 17.9565, 79.6152),
        IndianLocation("Warangal", "Mattewada", "Telangana", 17.9735, 79.5978),
        IndianLocation("Warangal", "Ursu", "Telangana", 17.9518, 79.6067),
        IndianLocation("Warangal", "Girmajipet", "Telangana", 17.9642, 79.5920),
        IndianLocation("Warangal", "Kashibugga", "Telangana", 17.9792, 79.6165),
        // Telangana: Hanamkonda
        IndianLocation("Hanamkonda", "Nakkalagutta", "Telangana", 18.0072, 79.5584),
        IndianLocation("Hanamkonda", "Subedari", "Telangana", 18.0005, 79.5530),
        IndianLocation("Hanamkonda", "Balasamudram", "Telangana", 18.0091, 79.5632),
        IndianLocation("Hanamkonda", "Lashkar Singaram", "Telangana", 18.0156, 79.5471),
        IndianLocation("Hanamkonda", "Kakatiya University", "Telangana", 18.0273, 79.5526),
        IndianLocation("Hanamkonda", "Adalat Circle", "Telangana", 18.0048, 79.5664),
        IndianLocation("Hanamkonda", "Kumarpally", "Telangana", 18.0121, 79.5562),
        IndianLocation("Hanamkonda", "Gopalpur", "Telangana", 18.0225, 79.5458),
        IndianLocation("Hanamkonda", "Waddepally", "Telangana", 17.9949, 79.5398),
        // Telangana: Kazipet
        IndianLocation("Kazipet", "Kazipet Junction", "Telangana", 17.9736, 79.5061),
        IndianLocation("Kazipet", "Madikonda", "Telangana", 17.9612, 79.4832),
        IndianLocation("Kazipet", "Fatimanagar", "Telangana", 17.9822, 79.5245),
        IndianLocation("Kazipet", "Somidi", "Telangana", 17.9790, 79.5120),
        IndianLocation("Kazipet", "Shayampet", "Telangana", 17.9681, 79.5184),
        IndianLocation("Kazipet", "Bapuji Nagar", "Telangana", 17.9774, 79.5015),
        IndianLocation("Kazipet", "Diesel Colony", "Telangana", 17.9708, 79.5112),
        IndianLocation("Kazipet", "Vishnupuri", "Telangana", 17.9851, 79.5175)
    )

    // Future expansion cities — NOT enabled on launch; Admin can enable centrally in Firebase
    val expansionCatalog: List<IndianLocation> = listOf(
        // Telangana: Karimnagar
        IndianLocation("Karimnagar", "Tower Circle", "Telangana", 18.4386, 79.1288),
        IndianLocation("Karimnagar", "Mankamma Thota", "Telangana", 18.4325, 79.1342),
        IndianLocation("Karimnagar", "Mukarampura", "Telangana", 18.4422, 79.1265),
        IndianLocation("Karimnagar", "Bhagatnagar", "Telangana", 18.4465, 79.1396),
        IndianLocation("Karimnagar", "Kothirampur", "Telangana", 18.4290, 79.1210),
        // Telangana: Other Districts
        IndianLocation("Nizamabad", "Subhash Nagar", "Telangana", 18.6725, 78.0941),
        IndianLocation("Nizamabad", "Vinayak Nagar", "Telangana", 18.6658, 78.1053),
        IndianLocation("Khammam", "Wyra Road", "Telangana", 17.2473, 80.1514),
        IndianLocation("Khammam", "Mamillagudem", "Telangana", 17.2412, 80.1419),
        IndianLocation("Nalgonda", "Clock Tower", "Telangana", 17.0575, 79.2684),
        // Andhra Pradesh & Other Major Hubs
        IndianLocation("Vijayawada", "Benz Circle", "Andhra Pradesh", 16.4971, 80.6537),
        IndianLocation("Vijayawada", "Auto Nagar", "Andhra Pradesh", 16.4856, 80.6806),
        IndianLocation("Visakhapatnam", "MVP Colony", "Andhra Pradesh", 17.7413, 83.3347),
        IndianLocation("Bengaluru", "Whitefield", "Karnataka", 12.9698, 77.7500),
        IndianLocation("Bengaluru", "Yelahanka", "Karnataka", 13.1007, 77.5963),
        IndianLocation("Delhi", "Dwarka", "Delhi", 28.5921, 77.0460),
        IndianLocation("Delhi", "Noida Sec 62", "UP/NCR", 28.6279, 77.3649),
        IndianLocation("Mumbai", "Andheri East", "Maharashtra", 19.1136, 72.8697),
        IndianLocation("Mumbai", "Thane West", "Maharashtra", 19.2183, 72.9781),
        IndianLocation("Patna", "Kankarbagh", "Bihar", 25.6012, 85.1583),
        IndianLocation("Lucknow", "Gomti Nagar", "Uttar Pradesh", 26.8496, 81.0005),
        IndianLocation("Jaipur", "Mansarovar", "Rajasthan", 26.8505, 75.7628)
    )

    val allKnownLocations: List<IndianLocation> = launchPresets + expansionCatalog

    val presets: List<IndianLocation> get() = launchPresets

    val cities: List<String> = launchPresets.map { it.city }.distinct()

    val expansionCityNames: List<String> = expansionCatalog.map { it.city }.distinct()

    fun areasForCity(
        city: String,
        locations: List<IndianLocation> = launchPresets
    ): List<IndianLocation> =
        locations.filter { it.city.equals(city.trim(), ignoreCase = true) }

    fun searchLocations(
        query: String,
        locations: List<IndianLocation> = launchPresets
    ): List<IndianLocation> {
        val clean = query.trim().lowercase()
        if (clean.isEmpty()) return locations
        val tokens = clean.split(Regex("\\s+")).filter { it.isNotEmpty() }
        return locations.filter { loc ->
            val haystack = "${loc.area} ${loc.city} ${loc.state}".lowercase()
            tokens.all { token -> haystack.contains(token) }
        }
    }

    /**
     * Checks if the search query matches a location outside the currently enabled service cities
     * (either in the future expansion catalog or by explicit non-active city lookup).
     */
    fun findOutsideCatalogMatch(
        query: String,
        activeLocations: List<IndianLocation> = launchPresets
    ): IndianLocation? {
        val clean = query.trim().lowercase()
        if (clean.length < 3) return null
        val tokens = clean.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val activeCities = activeLocations.map { it.city.lowercase() }.toSet()
        return expansionCatalog.firstOrNull { loc ->
            !activeCities.contains(loc.city.lowercase()) &&
                tokens.all { token ->
                    "${loc.area} ${loc.city} ${loc.state}".lowercase().contains(token)
                }
        }
    }

    /**
     * Strictly resolves a city and locality within [locations]. Returns null if the city is not enabled
     * or if city/area are blank.
     */
    fun findActiveLocation(
        city: String,
        area: String,
        locations: List<IndianLocation> = launchPresets
    ): IndianLocation? {
        val trimmedCity = city.trim()
        val trimmedArea = area.trim()
        if (trimmedCity.isBlank() || trimmedArea.isBlank()) return null

        val exact = locations.firstOrNull {
            it.city.equals(trimmedCity, ignoreCase = true) &&
                it.area.equals(trimmedArea, ignoreCase = true)
        }
        if (exact != null) return exact

        val cityMatch = locations.firstOrNull { it.city.equals(trimmedCity, ignoreCase = true) }
        return cityMatch?.copy(area = trimmedArea)
    }

    fun isWithinServiceArea(
        city: String,
        locations: List<IndianLocation> = launchPresets
    ): Boolean = locations.any { it.city.equals(city.trim(), ignoreCase = true) }

    fun findLocation(city: String, area: String): IndianLocation {
        val trimmedCity = city.trim()
        val trimmedArea = area.trim()
        val exact = allKnownLocations.firstOrNull {
            it.city.equals(trimmedCity, ignoreCase = true) &&
                it.area.equals(trimmedArea, ignoreCase = true)
        }
        if (exact != null) return exact

        val cityMatch = allKnownLocations.firstOrNull { it.city.equals(trimmedCity, ignoreCase = true) }
        if (cityMatch != null) {
            return if (trimmedArea.isNotBlank()) {
                cityMatch.copy(area = trimmedArea)
            } else {
                cityMatch
            }
        }
        return defaultLocation
    }

    fun nearestLocation(
        lat: Double,
        lng: Double,
        locations: List<IndianLocation> = launchPresets
    ): IndianLocation {
        return locations.minByOrNull { haversineKm(lat, lng, it.latitude, it.longitude) }
            ?: defaultLocation
    }

    fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadiusKm = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return earthRadiusKm * c
    }
}

