package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.AppLanguage
import com.example.data.IndianLocation
import com.example.data.IndianLocations
import java.util.Locale

class VoiceAssistant(
    context: Context,
    private val onFallbackSpeak: ((String) -> Unit)? = null
) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = runCatching {
        TextToSpeech(context.applicationContext, this)
    }.getOrNull()
    private var isInitComplete = false
    private var isReady = false
    private var pendingSpeech: Pair<String, AppLanguage>? = null

    override fun onInit(status: Int) {
        isInitComplete = true
        isReady = status == TextToSpeech.SUCCESS
        val pending = pendingSpeech
        pendingSpeech = null
        if (pending != null && isReady) {
            speakInternal(pending.first, pending.second)
        }
    }

    fun speak(text: String, language: AppLanguage) {
        val engine = tts
        if (engine == null) {
            onFallbackSpeak?.invoke(text)
            return
        }
        if (!isInitComplete) {
            pendingSpeech = text to language
            onFallbackSpeak?.invoke(text)
            return
        }
        if (!isReady) {
            onFallbackSpeak?.invoke(text)
            return
        }
        speakInternal(text, language)
    }

    private fun speakInternal(text: String, language: AppLanguage) {
        val engine = tts ?: run {
            onFallbackSpeak?.invoke(text)
            return
        }
        val locale = Locale.forLanguageTag(language.speechTag)
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.forLanguageTag("en-IN"))
        }
        engine.setSpeechRate(0.92f)
        val speakStatus = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "dailywork_tts")
        if (speakStatus != TextToSpeech.SUCCESS) {
            onFallbackSpeak?.invoke(text)
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

object ContactHelper {
    fun dialPhone(context: Context, phone: String): Boolean {
        val clean = phone.filter { it.isDigit() || it == '+' }
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$clean"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    fun openWhatsApp(context: Context, phone: String, message: String): Boolean {
        val digits = phone.filter { it.isDigit() }
        val intl = if (digits.length == 10) "91$digits" else digits
        val encoded = Uri.encode(message)
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl?text=$encoded"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    fun sendSms(context: Context, phone: String, message: String): Boolean {
        val clean = phone.filter { it.isDigit() || it == '+' }
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$clean")).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching { context.startActivity(intent) }.isSuccess
    }
}

sealed interface GpsDetectionResult {
    data class InsideServiceArea(
        val location: IndianLocation,
        val gpsLat: Double,
        val gpsLng: Double
    ) : GpsDetectionResult

    data class OutsideServiceArea(
        val gpsLat: Double,
        val gpsLng: Double,
        val nearestKnownLabel: String,
        val distanceToServiceKm: Double
    ) : GpsDetectionResult

    data object Unavailable : GpsDetectionResult
}

object LocationHelper {
    fun evaluateCoordinates(
        lat: Double,
        lng: Double,
        activeLocations: List<IndianLocation> = IndianLocations.launchPresets,
        catalogLocations: List<IndianLocation> = IndianLocations.allKnownLocations,
        serviceRadiusKm: Double = IndianLocations.SERVICE_AREA_RADIUS_KM
    ): GpsDetectionResult {
        val pool = activeLocations.ifEmpty { IndianLocations.launchPresets }
        val nearestActive = pool.minByOrNull { IndianLocations.haversineKm(lat, lng, it.latitude, it.longitude) }
            ?: return GpsDetectionResult.Unavailable
        val distToActive = IndianLocations.haversineKm(lat, lng, nearestActive.latitude, nearestActive.longitude)
        return if (distToActive <= serviceRadiusKm) {
            GpsDetectionResult.InsideServiceArea(
                location = nearestActive,
                gpsLat = lat,
                gpsLng = lng
            )
        } else {
            val allPool = (pool + catalogLocations).distinctBy { "${it.city}|${it.area}" }
            val nearestKnown = allPool.minByOrNull { IndianLocations.haversineKm(lat, lng, it.latitude, it.longitude) }
            val distKnown = nearestKnown?.let { IndianLocations.haversineKm(lat, lng, it.latitude, it.longitude) } ?: Double.MAX_VALUE
            val label = if (nearestKnown != null && distKnown <= 65.0) {
                nearestKnown.city
            } else {
                "Your location"
            }
            GpsDetectionResult.OutsideServiceArea(
                gpsLat = lat,
                gpsLng = lng,
                nearestKnownLabel = label,
                distanceToServiceKm = distToActive
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun readLastKnownCoordinates(context: Context): Pair<Double, Double>? {
        val hasCoarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!hasCoarse) return null

        val manager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return null

        val providers = listOf(
            LocationManager.NETWORK_PROVIDER,
            LocationManager.GPS_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        var best: Location? = null
        for (provider in providers) {
            val loc = runCatching { manager.getLastKnownLocation(provider) }.getOrNull()
            if (loc != null && (best == null || loc.time > best.time)) {
                best = loc
            }
        }
        return best?.let { it.latitude to it.longitude }
    }

    fun detectServiceLocation(
        context: Context,
        activeLocations: List<IndianLocation> = IndianLocations.launchPresets
    ): GpsDetectionResult {
        val coords = readLastKnownCoordinates(context) ?: return GpsDetectionResult.Unavailable
        return evaluateCoordinates(coords.first, coords.second, activeLocations)
    }

    @SuppressLint("MissingPermission")
    fun detectNearestLocation(
        context: Context,
        activeLocations: List<IndianLocation> = IndianLocations.launchPresets
    ): IndianLocation? {
        return when (val res = detectServiceLocation(context, activeLocations)) {
            is GpsDetectionResult.InsideServiceArea -> res.location
            else -> null
        }
    }
}


object LocalNotificationHelper {
    private const val CHANNEL_ID = "dailywork_alerts"

    fun showNotification(context: Context, title: String, message: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DailyWork Job Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()

        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }
}

object ProfilePhotoHelper {
    private const val MAX_DIMENSION_PX = 160
    private const val MAX_BASE64_LENGTH = 110_000

    fun encodeUriToBase64(context: Context, uri: Uri): String? {
        return runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                input.readBytes()
            } ?: return null
            val original = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: return null
            val scale = minOf(
                MAX_DIMENSION_PX.toFloat() / original.width.coerceAtLeast(1),
                MAX_DIMENSION_PX.toFloat() / original.height.coerceAtLeast(1),
                1f
            )
            val targetWidth = (original.width * scale).toInt().coerceAtLeast(1)
            val targetHeight = (original.height * scale).toInt().coerceAtLeast(1)
            val scaled = if (targetWidth != original.width || targetHeight != original.height) {
                android.graphics.Bitmap.createScaledBitmap(original, targetWidth, targetHeight, true)
            } else {
                original
            }
            var quality = 75
            var encoded = ""
            while (quality >= 35) {
                val out = java.io.ByteArrayOutputStream()
                scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, out)
                encoded = android.util.Base64.encodeToString(out.toByteArray(), android.util.Base64.NO_WRAP)
                if (encoded.length <= MAX_BASE64_LENGTH) break
                quality -= 20
            }
            if (scaled !== original) scaled.recycle()
            original.recycle()
            encoded.takeIf { it.isNotBlank() && it.length <= MAX_BASE64_LENGTH }
        }.getOrNull()
    }

    fun decodeBase64ToBitmap(base64: String): android.graphics.Bitmap? {
        if (base64.isBlank()) return null
        return runCatching {
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }.getOrNull()
    }
}
